-- V452: إصلاح حالة العمال/المشرفين + توليد كود TS تلقائي
-- آمن: لا يحذف أي بيانات

CREATE EXTENSION IF NOT EXISTS pgcrypto;

ALTER TABLE IF EXISTS public.employees_master_v386
  ADD COLUMN IF NOT EXISTS employee_code text,
  ADD COLUMN IF NOT EXISTS app_name text,
  ADD COLUMN IF NOT EXISTS job_title text,
  ADD COLUMN IF NOT EXISTS iqama_number text,
  ADD COLUMN IF NOT EXISTS status text DEFAULT 'active',
  ADD COLUMN IF NOT EXISTS work_start_date date,
  ADD COLUMN IF NOT EXISTS work_end_date date,
  ADD COLUMN IF NOT EXISTS basic_salary numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS allowances numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS total_salary numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS updated_at timestamptz DEFAULT now();

CREATE UNIQUE INDEX IF NOT EXISTS ux_employees_master_v386_employee_code
  ON public.employees_master_v386 (employee_code)
  WHERE employee_code IS NOT NULL AND employee_code <> '';

CREATE INDEX IF NOT EXISTS idx_employees_master_v386_status
  ON public.employees_master_v386 (status);

CREATE INDEX IF NOT EXISTS idx_monthly_distribution_month_status_worker
  ON public.monthly_distribution (month_key, status, worker_employee_code);

CREATE INDEX IF NOT EXISTS idx_monthly_distribution_month_status_supervisor
  ON public.monthly_distribution (month_key, status, supervisor_employee_code);

CREATE INDEX IF NOT EXISTS idx_projects_status
  ON public.projects (status);

CREATE OR REPLACE FUNCTION public.tasneef_next_employee_code(p_prefix text DEFAULT 'TS')
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_prefix text := COALESCE(NULLIF(trim(p_prefix),''),'TS');
  v_max int := 0;
BEGIN
  SELECT COALESCE(MAX((regexp_match(code, '[0-9]+'))[1]::int),0)
  INTO v_max
  FROM (
    SELECT to_jsonb(e)->>'employee_code' AS code FROM public.employees_master_v386 e
    UNION ALL SELECT to_jsonb(e)->>'employee_ts_id' FROM public.employees_master_v386 e
    UNION ALL SELECT to_jsonb(e)->>'code' FROM public.employees_master_v386 e
    UNION ALL SELECT to_jsonb(w)->>'employee_code' FROM public.workers w
    UNION ALL SELECT to_jsonb(w)->>'employee_ts_id' FROM public.workers w
    UNION ALL SELECT to_jsonb(w)->>'worker_code' FROM public.workers w
    UNION ALL SELECT to_jsonb(w)->>'code' FROM public.workers w
    UNION ALL SELECT CASE WHEN (to_jsonb(w)->>'id') ~ '^TS[-_ ]?[0-9]+$' THEN to_jsonb(w)->>'id' ELSE NULL END FROM public.workers w
  ) s
  WHERE code ~* ('^' || v_prefix || '[-_ ]?[0-9]+$');

  RETURN v_prefix || '-' || lpad((v_max + 1)::text, 2, '0');
END;
$$;

GRANT EXECUTE ON FUNCTION public.tasneef_next_employee_code(text) TO anon, authenticated;

-- ملاحظة تشغيلية:
-- الإيقاف يكون بوضع status = 'inactive' أو 'موقوف' في العامل/المشروع/المشرف.
-- النظام سيخفيه من التوزيع والرواتب والحضور بدون حذف السجلات التاريخية.
