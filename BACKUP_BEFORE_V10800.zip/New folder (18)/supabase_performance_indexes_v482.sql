-- Tasneef V482 targeted performance indexes. Safe: no data deletion.
BEGIN;
CREATE INDEX IF NOT EXISTS idx_attendance_worker_date_v482 ON public.attendance (worker_id, attendance_date DESC);
CREATE INDEX IF NOT EXISTS idx_attendance_project_date_v482 ON public.attendance (project_id, attendance_date DESC);
CREATE INDEX IF NOT EXISTS idx_time_logs_project_checkin_v482 ON public.time_logs (project_id, check_in DESC);
CREATE INDEX IF NOT EXISTS idx_time_logs_supervisor_checkin_v482 ON public.time_logs (supervisor_id, check_in DESC);
CREATE INDEX IF NOT EXISTS idx_monthly_distribution_month_supervisor_v482 ON public.monthly_distribution (month_key, supervisor_employee_code);
CREATE INDEX IF NOT EXISTS idx_monthly_distribution_month_project_v482 ON public.monthly_distribution (month_key, project_id);
CREATE INDEX IF NOT EXISTS idx_monthly_distribution_month_worker_v482 ON public.monthly_distribution (month_key, worker_employee_code);
CREATE INDEX IF NOT EXISTS idx_workers_active_v482 ON public.workers (is_active) WHERE is_active = true;
CREATE INDEX IF NOT EXISTS idx_projects_active_v482 ON public.projects (is_active) WHERE is_active = true;
CREATE INDEX IF NOT EXISTS idx_crm_customers_status_updated_v482 ON public.crm_customers (status, updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_crm_tasks_customer_due_v482 ON public.crm_tasks (customer_id, due_date, status);
CREATE INDEX IF NOT EXISTS idx_crm_communications_customer_at_v482 ON public.crm_communications (customer_id, communication_at DESC);
COMMIT;
NOTIFY pgrst, 'reload schema';
