-- Tasneef CRM V10606
-- Complete quote summary fields on crm_customers and refresh PostgREST schema cache.
begin;

alter table if exists public.crm_customers
  add column if not exists last_quote_id uuid,
  add column if not exists last_quote_value numeric(14,2);

-- Backfill the customer's latest quote without deleting or replacing existing values.
with latest_quote as (
  select distinct on (q.customer_id)
         q.customer_id,
         q.id as quote_id,
         q.total_with_tax as quote_value
  from public.crm_quotes q
  where q.customer_id is not null
  order by q.customer_id, coalesce(q.created_at, now()) desc, q.id desc
)
update public.crm_customers c
set last_quote_id = coalesce(c.last_quote_id, l.quote_id),
    last_quote_value = coalesce(c.last_quote_value, l.quote_value)
from latest_quote l
where c.id = l.customer_id
  and (c.last_quote_id is null or c.last_quote_value is null);

create index if not exists crm_customers_last_quote_id_idx
  on public.crm_customers(last_quote_id);

-- Add the FK only when it is not already present. Existing orphan values remain untouched.
do $$
begin
  if to_regclass('public.crm_quotes') is not null
     and not exists (
       select 1
       from pg_constraint
       where conrelid = 'public.crm_customers'::regclass
         and conname = 'crm_customers_last_quote_id_fkey'
     )
     and not exists (
       select 1
       from public.crm_customers c
       where c.last_quote_id is not null
         and not exists (select 1 from public.crm_quotes q where q.id = c.last_quote_id)
     ) then
    alter table public.crm_customers
      add constraint crm_customers_last_quote_id_fkey
      foreign key (last_quote_id) references public.crm_quotes(id)
      on delete set null;
  end if;
end $$;

commit;

notify pgrst, 'reload schema';
