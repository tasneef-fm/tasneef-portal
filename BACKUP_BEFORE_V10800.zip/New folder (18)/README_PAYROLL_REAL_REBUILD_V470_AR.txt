إعادة بناء الرواتب V470

الملف التنفيذي الوحيد:
- tasneef_salaries_unified_source_v440.js

دالة البناء الوحيدة:
- buildUnifiedPayroll(period)

الملفات القديمة المعطلة نهائيًا ونُقلت إلى disabled_legacy_payroll:
- tasneef_salaries_v10363_original_user_reference.js.disabled.txt
- supabase_salaries_rebuild_v450.sql.disabled.txt
- supabase_salaries_speed_v451.sql.disabled.txt

مصادر النظام الفعلية التي يحاول المحرك قراءتها:
- employees_master_v386 (المصدر الأساسي)
- employees / workers / app_users (مصادر استكمال غير تجريبية)
- monthly_distribution / worker_project_assignments / monthly_distribution_view
- projects
- attendance
- time_logs / daily_records / daily_registrations
- payroll_adjustments / salary_adjustments

قواعد الربط:
- لا يوجد ربط بالاسم.
- الربط بمعرف الموظف أو كوده الفعلي فقط.
- صف واحد نهائي لكل موظف.
- التوزيعات المتعددة تحفظ في نافذة التفاصيل.
- المشرف الأساسي هو صاحب أكبر عدد أيام في الشهر.
- يوليو 2026 = 2026-07-01 إلى 2026-07-31.

التشخيص بعد التشغيل:
window.__tasneefPayrollDiagnostics
