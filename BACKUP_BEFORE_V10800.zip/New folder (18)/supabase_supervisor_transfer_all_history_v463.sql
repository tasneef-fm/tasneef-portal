-- V464 حل عام لنقل أي مشرف إلى مشرف بديل بدون أخطاء أعمدة ناقصة
-- يشغّل مرة واحدة في Supabase. بعده من شاشة النظام الموحد عند إيقاف أي مشرف تختار المشرف البديل وينقل كل شيء له.
-- لا تحذف بيانات. فقط تحديث ربط المشرف القديم بالبديل وإيقاف القديم.

create or replace function public.tasneef_transfer_supervisor_any_v464(
  p_old_code text default null,
  p_new_code text default null,
  p_old_name text default null,
  p_new_name text default null,
  p_old_user_id text default null,
  p_new_user_id text default null,
  p_from_month text default null,
  p_from_date date default current_date,
  p_transfer_all_history boolean default true
)
returns table(
  project_rows integer,
  distribution_rows integer,
  time_log_rows integer,
  attendance_rows integer,
  daily_rows integer,
  ticket_rows integer,
  old_hidden_rows integer,
  resolved_old text,
  resolved_new text,
  affected_projects integer
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_old_code text := nullif(trim(coalesce(p_old_code,'')),'');
  v_new_code text := nullif(trim(coalesce(p_new_code,'')),'');
  v_old_name text := nullif(trim(coalesce(p_old_name,'')),'');
  v_new_name text := nullif(trim(coalesce(p_new_name,'')),'');
  v_old_user text := nullif(trim(coalesce(p_old_user_id,'')),'');
  v_new_user text := nullif(trim(coalesce(p_new_user_id,'')),'');
  v_month text := coalesce(nullif(p_from_month,''),to_char(current_date,'YYYY-MM'));
  v_date date := coalesce(p_from_date,current_date);
  v_project_ids text[] := array[]::text[];
  v_more_ids text[] := array[]::text[];
  v_set text;
  v_where text;
  v_sql text;
  r jsonb;
  rc int;
  t text;
  has_updated boolean;
  has_project boolean;
  date_col text;

  -- كل أسماء الأعمدة المحتملة للمشرف في الجداول
  code_cols text[] := array['supervisor_employee_code','supervisor_code','current_supervisor_code','app_supervisor_code'];
  name_cols text[] := array['supervisor_name','current_supervisor_name','app_supervisor_name'];
  user_cols text[] := array['supervisor_id','current_supervisor_id','app_supervisor_id'];
  ccol text;
  ncol text;
  ucol text;
begin
  project_rows := 0; distribution_rows := 0; time_log_rows := 0; attendance_rows := 0; daily_rows := 0; ticket_rows := 0; old_hidden_rows := 0; affected_projects := 0;

  -- حل الكود والاسم من جدول الموظفين الموحد
  if to_regclass('public.employees_master_v386') is not null then
    for r in execute 'select to_jsonb(x) from public.employees_master_v386 x' loop
      if v_old_code is null and (r->>'app_name'=v_old_name or r->>'employee_name'=v_old_name or r->>'name'=v_old_name) then
        v_old_code := nullif(coalesce(r->>'employee_code',r->>'code',r->>'id'),'');
      end if;
      if v_new_code is null and (r->>'app_name'=v_new_name or r->>'employee_name'=v_new_name or r->>'name'=v_new_name) then
        v_new_code := nullif(coalesce(r->>'employee_code',r->>'code',r->>'id'),'');
      end if;
      if v_old_name is null and v_old_code is not null and lower(coalesce(r->>'employee_code',r->>'code',r->>'id',''))=lower(v_old_code) then
        v_old_name := coalesce(nullif(r->>'app_name',''),nullif(r->>'employee_name',''),nullif(r->>'name',''),v_old_code);
      end if;
      if v_new_name is null and v_new_code is not null and lower(coalesce(r->>'employee_code',r->>'code',r->>'id',''))=lower(v_new_code) then
        v_new_name := coalesce(nullif(r->>'app_name',''),nullif(r->>'employee_name',''),nullif(r->>'name',''),v_new_code);
      end if;
    end loop;
  end if;

  -- حل الكود والاسم من workers
  if to_regclass('public.workers') is not null then
    for r in execute 'select to_jsonb(x) from public.workers x' loop
      if v_old_code is null and (r->>'name'=v_old_name or r->>'full_name'=v_old_name or r->>'app_name'=v_old_name) then
        v_old_code := nullif(coalesce(r->>'employee_code',r->>'worker_code',r->>'code',r->>'id'),'');
      end if;
      if v_new_code is null and (r->>'name'=v_new_name or r->>'full_name'=v_new_name or r->>'app_name'=v_new_name) then
        v_new_code := nullif(coalesce(r->>'employee_code',r->>'worker_code',r->>'code',r->>'id'),'');
      end if;
      if v_old_name is null and v_old_code is not null and lower(coalesce(r->>'employee_code',r->>'worker_code',r->>'code',r->>'id',''))=lower(v_old_code) then
        v_old_name := coalesce(nullif(r->>'name',''),nullif(r->>'full_name',''),nullif(r->>'app_name',''),v_old_code);
      end if;
      if v_new_name is null and v_new_code is not null and lower(coalesce(r->>'employee_code',r->>'worker_code',r->>'code',r->>'id',''))=lower(v_new_code) then
        v_new_name := coalesce(nullif(r->>'name',''),nullif(r->>'full_name',''),nullif(r->>'app_name',''),v_new_code);
      end if;
    end loop;
  end if;

  -- حل حساب المشرف من app_users لأن صفحة المشرف تعتمد على id غالباً
  if to_regclass('public.app_users') is not null then
    for r in execute 'select to_jsonb(x) from public.app_users x' loop
      if v_old_user is null and (
        lower(coalesce(r->>'id',''))=lower(coalesce(v_old_code,'')) or
        lower(coalesce(r->>'employee_code',''))=lower(coalesce(v_old_code,'')) or
        lower(coalesce(r->>'worker_code',''))=lower(coalesce(v_old_code,'')) or
        lower(coalesce(r->>'username',''))=lower(coalesce(v_old_code,'')) or
        coalesce(r->>'full_name','')=coalesce(v_old_name,'') or coalesce(r->>'name','')=coalesce(v_old_name,'')
      ) then v_old_user := r->>'id'; end if;
      if v_new_user is null and (
        lower(coalesce(r->>'id',''))=lower(coalesce(v_new_code,'')) or
        lower(coalesce(r->>'employee_code',''))=lower(coalesce(v_new_code,'')) or
        lower(coalesce(r->>'worker_code',''))=lower(coalesce(v_new_code,'')) or
        lower(coalesce(r->>'username',''))=lower(coalesce(v_new_code,'')) or
        coalesce(r->>'full_name','')=coalesce(v_new_name,'') or coalesce(r->>'name','')=coalesce(v_new_name,'')
      ) then v_new_user := r->>'id'; end if;
    end loop;
  end if;

  if coalesce(v_old_code,v_old_name,v_old_user) is null then
    raise exception 'لم يتم التعرف على المشرف القديم. أرسل الكود أو الاسم أو user_id.';
  end if;
  if coalesce(v_new_code,v_new_name,v_new_user) is null then
    raise exception 'لم يتم التعرف على المشرف البديل. أرسل الكود أو الاسم أو user_id.';
  end if;

  resolved_old := concat_ws(' | ',v_old_code,v_old_name,v_old_user);
  resolved_new := concat_ws(' | ',v_new_code,v_new_name,v_new_user);

  -- اجمع المشاريع المرتبطة بالقديم من projects
  if to_regclass('public.projects') is not null then
    v_where := 'false';
    if v_old_code is not null then
      foreach ccol in array code_cols loop
        v_where := v_where || format(' or to_jsonb(x)->>%L=%L',ccol,v_old_code);
      end loop;
    end if;
    if v_old_name is not null then
      foreach ncol in array name_cols loop
        v_where := v_where || format(' or to_jsonb(x)->>%L=%L',ncol,v_old_name);
      end loop;
    end if;
    if v_old_user is not null then
      foreach ucol in array user_cols loop
        v_where := v_where || format(' or to_jsonb(x)->>%L=%L',ucol,v_old_user);
      end loop;
    end if;
    execute format('select coalesce(array_agg(distinct to_jsonb(x)->>''id''),array[]::text[]) from public.projects x where %s',v_where) into v_project_ids;
  end if;

  -- اجمع المشاريع المرتبطة بالقديم من التوزيع أيضاً
  if to_regclass('public.monthly_distribution') is not null then
    v_where := 'false';
    if v_old_code is not null then
      foreach ccol in array code_cols loop
        v_where := v_where || format(' or to_jsonb(x)->>%L=%L',ccol,v_old_code);
      end loop;
    end if;
    if v_old_name is not null then
      foreach ncol in array name_cols loop
        v_where := v_where || format(' or to_jsonb(x)->>%L=%L',ncol,v_old_name);
      end loop;
    end if;
    if v_old_user is not null then
      foreach ucol in array user_cols loop
        v_where := v_where || format(' or to_jsonb(x)->>%L=%L',ucol,v_old_user);
      end loop;
    end if;
    execute format('select coalesce(array_agg(distinct to_jsonb(x)->>''project_id''),array[]::text[]) from public.monthly_distribution x where %s',v_where) into v_more_ids;
    v_project_ids := array(select distinct x from unnest(coalesce(v_project_ids,array[]::text[]) || coalesce(v_more_ids,array[]::text[])) as x where x is not null and x <> '');
  end if;

  affected_projects := coalesce(array_length(v_project_ids,1),0);

  -- تحديث projects
  if to_regclass('public.projects') is not null then
    v_set := '';
    select exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='updated_at') into has_updated;
    foreach ccol in array code_cols loop
      if exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name=ccol) then
        v_set := v_set || format('%I=%L,',ccol,v_new_code);
      end if;
    end loop;
    foreach ncol in array name_cols loop
      if exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name=ncol) then
        v_set := v_set || format('%I=%L,',ncol,v_new_name);
      end if;
    end loop;
    if v_new_user is not null then
      foreach ucol in array user_cols loop
        if exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name=ucol) then
          v_set := v_set || format('%I=%L,',ucol,v_new_user);
        end if;
      end loop;
    end if;
    if has_updated then v_set := v_set || 'updated_at=now(),'; end if;
    v_set := trim(trailing ',' from v_set);
    if v_set <> '' and affected_projects > 0 then
      execute format('update public.projects x set %s where to_jsonb(x)->>''id'' = any($1)',v_set) using v_project_ids;
      get diagnostics project_rows = row_count;
    end if;
  end if;

  -- تحديث monthly_distribution كامل التاريخ
  if to_regclass('public.monthly_distribution') is not null then
    v_set := '';
    select exists(select 1 from information_schema.columns where table_schema='public' and table_name='monthly_distribution' and column_name='updated_at') into has_updated;
    foreach ccol in array code_cols loop
      if exists(select 1 from information_schema.columns where table_schema='public' and table_name='monthly_distribution' and column_name=ccol) then
        v_set := v_set || format('%I=%L,',ccol,v_new_code);
      end if;
    end loop;
    foreach ncol in array name_cols loop
      if exists(select 1 from information_schema.columns where table_schema='public' and table_name='monthly_distribution' and column_name=ncol) then
        v_set := v_set || format('%I=%L,',ncol,v_new_name);
      end if;
    end loop;
    if v_new_user is not null then
      foreach ucol in array user_cols loop
        if exists(select 1 from information_schema.columns where table_schema='public' and table_name='monthly_distribution' and column_name=ucol) then
          v_set := v_set || format('%I=%L,',ucol,v_new_user);
        end if;
      end loop;
    end if;
    if has_updated then v_set := v_set || 'updated_at=now(),'; end if;
    v_set := trim(trailing ',' from v_set);
    if v_set <> '' then
      v_where := 'false';
      if affected_projects > 0 then v_where := v_where || ' or to_jsonb(x)->>''project_id'' = any($1)'; end if;
      if v_old_code is not null then foreach ccol in array code_cols loop v_where := v_where || format(' or to_jsonb(x)->>%L=%L',ccol,v_old_code); end loop; end if;
      if v_old_name is not null then foreach ncol in array name_cols loop v_where := v_where || format(' or to_jsonb(x)->>%L=%L',ncol,v_old_name); end loop; end if;
      if v_old_user is not null then foreach ucol in array user_cols loop v_where := v_where || format(' or to_jsonb(x)->>%L=%L',ucol,v_old_user); end loop; end if;
      if affected_projects > 0 then
        execute format('update public.monthly_distribution x set %s where %s',v_set,v_where) using v_project_ids;
      else
        execute format('update public.monthly_distribution x set %s where %s',v_set,v_where);
      end if;
      get diagnostics distribution_rows = row_count;
    end if;
  end if;

  -- تحديث السجلات: time_logs / attendance / daily_records / tickets
  foreach t in array array['time_logs','attendance','daily_records','tickets'] loop
    if to_regclass('public.'||t) is not null then
      v_set := '';
      select exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name='updated_at') into has_updated;
      select exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name='project_id') into has_project;

      if v_new_user is not null then
        foreach ucol in array user_cols loop
          if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name=ucol) then
            v_set := v_set || format('%I=%L,',ucol,v_new_user);
          end if;
        end loop;
      end if;
      foreach ccol in array code_cols loop
        if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name=ccol) then
          v_set := v_set || format('%I=%L,',ccol,v_new_code);
        end if;
      end loop;
      foreach ncol in array name_cols loop
        if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name=ncol) then
          v_set := v_set || format('%I=%L,',ncol,v_new_name);
        end if;
      end loop;
      if has_updated then v_set := v_set || 'updated_at=now(),'; end if;
      v_set := trim(trailing ',' from v_set);

      if v_set <> '' then
        v_where := 'false';
        if has_project and affected_projects > 0 then v_where := v_where || ' or to_jsonb(x)->>''project_id'' = any($1)'; end if;
        if v_old_code is not null then foreach ccol in array code_cols loop v_where := v_where || format(' or to_jsonb(x)->>%L=%L',ccol,v_old_code); end loop; end if;
        if v_old_name is not null then foreach ncol in array name_cols loop v_where := v_where || format(' or to_jsonb(x)->>%L=%L',ncol,v_old_name); end loop; end if;
        if v_old_user is not null then foreach ucol in array user_cols loop v_where := v_where || format(' or to_jsonb(x)->>%L=%L',ucol,v_old_user); end loop; end if;

        -- لو اخترت عدم نقل التاريخ كله، نضيف فلتر التاريخ إذا وجد عمود تاريخ معروف
        date_col := null;
        if not p_transfer_all_history then
          foreach date_col in array array['log_date','attendance_date','record_date','created_at','date'] loop
            if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name=date_col) then exit; end if;
          end loop;
          if date_col is not null then
            v_where := '('||v_where||') and (to_jsonb(x)->>'||quote_literal(date_col)||')::date >= '||quote_literal(v_date);
          end if;
        end if;

        if has_project and affected_projects > 0 then
          execute format('update public.%I x set %s where %s',t,v_set,v_where) using v_project_ids;
        else
          execute format('update public.%I x set %s where %s',t,v_set,v_where);
        end if;
        get diagnostics rc = row_count;
        if t='time_logs' then time_log_rows := rc; end if;
        if t='attendance' then attendance_rows := rc; end if;
        if t='daily_records' then daily_rows := rc; end if;
        if t='tickets' then ticket_rows := rc; end if;
      end if;
    end if;
  end loop;

  -- إخفاء/إيقاف المشرف القديم من الفلاتر
  if to_regclass('public.app_users') is not null then
    v_set := '';
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='app_users' and column_name='is_active') then v_set := v_set || 'is_active=false,'; end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='app_users' and column_name='active') then v_set := v_set || 'active=false,'; end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='app_users' and column_name='status') then v_set := v_set || 'status=''inactive'','; end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='app_users' and column_name='active_status') then v_set := v_set || 'active_status=''inactive'','; end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='app_users' and column_name='updated_at') then v_set := v_set || 'updated_at=now(),'; end if;
    v_set := trim(trailing ',' from v_set);
    if v_set <> '' then
      v_where := 'false';
      if v_old_user is not null then v_where := v_where || format(' or to_jsonb(x)->>''id''=%L',v_old_user); end if;
      if v_old_code is not null then v_where := v_where || format(' or to_jsonb(x)->>''employee_code''=%L or to_jsonb(x)->>''username''=%L',v_old_code,v_old_code); end if;
      if v_old_name is not null then v_where := v_where || format(' or to_jsonb(x)->>''full_name''=%L or to_jsonb(x)->>''name''=%L',v_old_name,v_old_name); end if;
      execute format('update public.app_users x set %s where %s',v_set,v_where);
      get diagnostics rc = row_count; old_hidden_rows := old_hidden_rows + rc;
    end if;
  end if;

  -- إيقافه في جداول العمال/الموظفين، مع تاريخ نهاية الخدمة اليوم
  foreach t in array array['employees_master_v386','workers'] loop
    if to_regclass('public.'||t) is not null then
      v_set := '';
      if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name='status') then v_set := v_set || 'status=''inactive'','; end if;
      if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name='state') then v_set := v_set || 'state=''inactive'','; end if;
      if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name='is_active') then v_set := v_set || 'is_active=false,'; end if;
      if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name='active') then v_set := v_set || 'active=false,'; end if;
      if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name='end_date') then v_set := v_set || format('end_date=%L,',current_date); end if;
      if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name='work_end_date') then v_set := v_set || format('work_end_date=%L,',current_date); end if;
      if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name='service_end_date') then v_set := v_set || format('service_end_date=%L,',current_date); end if;
      if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name='termination_date') then v_set := v_set || format('termination_date=%L,',current_date); end if;
      if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name='updated_at') then v_set := v_set || 'updated_at=now(),'; end if;
      v_set := trim(trailing ',' from v_set);
      if v_set <> '' then
        v_where := 'false';
        if v_old_code is not null then v_where := v_where || format(' or to_jsonb(x)->>''employee_code''=%L or to_jsonb(x)->>''worker_code''=%L or to_jsonb(x)->>''code''=%L',v_old_code,v_old_code,v_old_code); end if;
        if v_old_name is not null then v_where := v_where || format(' or to_jsonb(x)->>''name''=%L or to_jsonb(x)->>''full_name''=%L or to_jsonb(x)->>''app_name''=%L or to_jsonb(x)->>''employee_name''=%L',v_old_name,v_old_name,v_old_name,v_old_name); end if;
        execute format('update public.%I x set %s where %s',t,v_set,v_where);
        get diagnostics rc = row_count; old_hidden_rows := old_hidden_rows + rc;
      end if;
    end if;
  end loop;

  return next;
end;
$$;

grant execute on function public.tasneef_transfer_supervisor_any_v464(text,text,text,text,text,text,text,date,boolean) to anon, authenticated;

-- فهارس مساعدة، كلها آمنة
create index if not exists idx_projects_id_text_v464 on public.projects((id::text));
create index if not exists idx_monthly_distribution_project_v464 on public.monthly_distribution((project_id::text));
create index if not exists idx_monthly_distribution_supervisor_emp_v464 on public.monthly_distribution(supervisor_employee_code) where supervisor_employee_code is not null;
create index if not exists idx_monthly_distribution_supervisor_name_v464 on public.monthly_distribution(supervisor_name) where supervisor_name is not null;
create index if not exists idx_time_logs_project_v464 on public.time_logs(project_id) where project_id is not null;
create index if not exists idx_attendance_project_v464 on public.attendance(project_id) where project_id is not null;

-- تجربة يدوية اختيارية بعد تشغيل SQL، غيّر الأسماء حسب الحاجة ثم شغّلها وحدها:
-- select * from public.tasneef_transfer_supervisor_any_v464(null,null,'محمود','وضاح',null,null,null,current_date,true);
