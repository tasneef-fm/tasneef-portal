إصلاح الرواتب V474 — مصدر السيرفر فقط

الدالة الوحيدة المستخدمة في الواجهة:
public.get_unified_payroll_from_server(p_month)
ويتم استدعاؤها من buildUnifiedPayroll(period) عبر Supabase RPC فقط.

الجداول الفعلية المستخدمة على السيرفر:
- employees_master_v386: المصدر الأساسي الوحيد للموظفين.
- monthly_distribution: التوزيعات الفعلية المستخدمة في قسم التوزيع.
- projects: أسماء المشاريع وحالة التشغيل.
- attendance: الحضور والغياب.
- payroll_adjustments: البدلات والحوافز والسلف والخصومات المعتمدة.

تم إلغاء استخدام أي fallback داخل الرواتب إلى:
- localStorage
- sessionStorage
- IndexedDB
- بيانات window.data
- employees / workers / app_users كمصادر مدمجة داخل الواجهة
- monthly_distribution_view أو worker_project_assignments كمصادر إضافية
- أي Cache أو مصفوفة قديمة للرواتب

الدمج وإزالة التكرار يتمان داخل PostgreSQL قبل إرسال النتيجة، على canonical_employee_id.
الواجهة تستقبل صفًا نهائيًا واحدًا لكل موظف ولا تنفذ دمجًا للموظفين أو الحضور أو التوزيعات.

التحقق الإجباري على السيرفر:
- duplicate_ids_found = 0
- final_payroll_rows = canonical_employee_ids
عند فشل أي شرط يرجع السيرفر خطأ ولا يعرض كشفًا مضللًا.

التشخيص بعد تشغيل يوليو 2026 متاح في:
window.__tasneefPayrollDiagnostics
ويشمل الأعداد الخام، المعرفات الفريدة، الموقوفين المستبعدين، الصفوف النهائية، وأعداد عمال كل مشرف.

الملفات المعدلة:
- tasneef_salaries_unified_source_v440.js
- supabase_canonical_v10519.sql
- admin.html

مهم: يجب تنفيذ الجزء V474 المضاف في نهاية supabase_canonical_v10519.sql على قاعدة Supabase قبل فتح قسم الرواتب.
