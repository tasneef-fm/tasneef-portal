إصلاح ربط الرواتب بالتوزيع والحضور V473

تم التعديل على نفس قسم الرواتب والتصميم الحالي دون إعادة بناء الواجهة.

المصدر الفعلي للتوزيع:
- الجدول الأساسي: monthly_distribution
- المصدر الاحتياطي: monthly_distribution_view
- المصدر المساند: worker_project_assignments
- دالة قسم التوزيع المرجعية: tasneefDistributionV404.loadDistribution
- فلتر الشهر: month_key = YYYY-MM

مصدر الحضور:
- الجدول: attendance
- الربط عبر المعرف الموحد canonical_employee_id بعد حل employee_id / worker_id / employee_code.

الإصلاحات:
1. ربط سجلات التوزيع والحضور بالموظف قبل إنشاء صف الراتب.
2. استخدام monthly_distribution بنفس منطق قسم التوزيع الحالي.
3. تطبيق تقاطع التوزيع مع الشهر وعدم الاعتماد على is_active الحالي وحده.
4. اختيار المشرف صاحب أكبر عدد أيام، ثم الأحدث عند التعادل.
5. عدم وضع الموظف في دون مشرف قبل استكمال جميع محاولات الربط.
6. إظهار تعذر ربط التوزيع بدل دون توزيع عندما يكون السجل موجودًا لكن مرجعه غير مربوط.
7. عدم تصفير أيام العمل عند غياب الحضور إذا كان التوزيع موجودًا؛ تستخدم بداية التوزيع/الخدمة كبديل مع حالة مراجعة.
8. إنشاء صف واحد فقط لكل canonical_employee_id.
9. إضافة مقارنة تشخيصية بين عمال التوزيع الأساسيين وموظفي الرواتب لكل مشرف.

التشخيص:
window.__tasneefPayrollDiagnostics

يشمل:
- distributionTable
- distributionFunction
- attendanceTable
- supervisorCoverage
- missingWorkersBySupervisor
- extraWorkersBySupervisor
- unlinkedAssignments
- employeesRelinkedFromWithoutSupervisor
- duplicateRowsRemoved
