-- V460 - إصلاح نقل مشاريع المشرف عند إيقافه
-- الهدف: المشاريع تنتقل لحساب المشرف البديل في صفحة المشرف، مع عدم تعديل السجلات القديمة.

alter table public.projects add column if not exists supervisor_employee_code text;
alter table public.projects add column if not exists supervisor_name text;
alter table public.projects add column if not exists current_supervisor_code text;
alter table public.projects add column if not exists current_supervisor_name text;
alter table public.projects add column if not exists app_supervisor_code text;
alter table public.projects add column if not exists app_supervisor_name text;
alter table public.projects add column if not exists current_supervisor_id bigint;
alter table public.projects add column if not exists app_supervisor_id bigint;

create index if not exists idx_projects_supervisor_id_v460 on public.projects(supervisor_id);
create index if not exists idx_projects_current_supervisor_id_v460 on public.projects(current_supervisor_id);
create index if not exists idx_projects_app_supervisor_id_v460 on public.projects(app_supervisor_id);
create index if not exists idx_projects_supervisor_code_v460 on public.projects(supervisor_employee_code);
create index if not exists idx_projects_current_supervisor_code_v460 on public.projects(current_supervisor_code);
create index if not exists idx_monthly_distribution_supervisor_code_v460 on public.monthly_distribution(supervisor_employee_code, month_key);

-- لا نحدث time_logs أو attendance أو monthly_timesheets حتى تبقى سجلات محمود القديمة باسم محمود.
