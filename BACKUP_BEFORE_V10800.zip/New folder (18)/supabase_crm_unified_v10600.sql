-- Tasneef CRM canonical schema - run once in Supabase SQL editor
create extension if not exists pgcrypto;
create table if not exists public.crm_customers (
 id uuid primary key default gen_random_uuid(), customer_number text unique, project_name text not null, project_type text not null,
 apartments_count integer default 0, shops_count integer default 0, city text not null, district text not null,
 contact_person text not null, mobile text not null, secondary_mobile text, email text, source_id uuid, source_name text,
 sales_employee_id uuid, sales_employee_name text, status text not null default 'prospect', notes text,
 created_by uuid, created_by_name text, created_at timestamptz default now(), updated_at timestamptz default now(),
 status_changed_at timestamptz default now(), last_contact_at timestamptz, next_followup_at timestamptz,
 contracted_at date, rejected_at timestamptz, rejection_reason text, rejection_notes text, can_reopen boolean default true,
 contract_id uuid, contract_start date, contract_end date, contract_value numeric(14,2), operations_manager text,
 converted_customer_id uuid, operation_project_id uuid, converted_to_operations_at timestamptz
);
create unique index if not exists crm_customers_mobile_idx on public.crm_customers(mobile) where mobile is not null;
create index if not exists crm_customers_status_idx on public.crm_customers(status);
create index if not exists crm_customers_sales_idx on public.crm_customers(sales_employee_id);
create table if not exists public.crm_customer_status_history (id uuid primary key default gen_random_uuid(),customer_id uuid references public.crm_customers(id) on delete cascade,from_status text,to_status text not null,changed_by uuid,changed_by_name text,changed_at timestamptz default now(),notes text,days_in_previous_status integer);
create table if not exists public.crm_communications (id uuid primary key default gen_random_uuid(),customer_id uuid references public.crm_customers(id) on delete cascade,communication_type text not null,result text,other_result text,notes text,employee_id uuid,employee_name text,communication_date date,communication_time time,communication_at timestamptz default now(),next_followup_date date,next_followup_time time,followup_employee_name text,created_at timestamptz default now());
create table if not exists public.crm_tasks (id uuid primary key default gen_random_uuid(),customer_id uuid references public.crm_customers(id) on delete cascade,title text not null,task_type text,assigned_to uuid,assigned_to_name text,due_date date,due_time time,priority text default 'عادية',status text default 'new',description text,created_at timestamptz default now(),completed_at timestamptz,cancelled_at timestamptz);
create table if not exists public.crm_quotes (id uuid primary key default gen_random_uuid(),customer_id uuid references public.crm_customers(id) on delete cascade,quote_number text,sent_date date,subtotal numeric(14,2),tax_value numeric(14,2),total_with_tax numeric(14,2),send_method text,expiry_date date,followup_date date,status text,notes text,created_by_name text,created_at timestamptz default now());
create table if not exists public.crm_quote_versions (id uuid primary key default gen_random_uuid(),quote_id uuid,customer_id uuid references public.crm_customers(id) on delete cascade,version_number integer,original_value numeric(14,2),current_value numeric(14,2),subtotal numeric(14,2),tax_value numeric(14,2),total_with_tax numeric(14,2),discount_percent numeric(7,2),discount_reason text,customer_requests text,scope_changes text,created_by_name text,created_at timestamptz default now());
create table if not exists public.crm_contracts (id uuid primary key default gen_random_uuid(),customer_id uuid references public.crm_customers(id) on delete cascade,contract_number text,contracted_at date,subtotal numeric(14,2),tax_value numeric(14,2),total_with_tax numeric(14,2),start_date date,end_date date,payment_method text,installments_count integer,services text,operations_manager text,handover_notes text,closed_by_name text,created_at timestamptz default now());
create table if not exists public.crm_rejection_reasons (id uuid primary key default gen_random_uuid(),customer_id uuid references public.crm_customers(id) on delete cascade,reason text not null,other_reason text,notes text,competitor_name text,last_offer_value numeric(14,2),recontact_date date,can_reopen boolean default true,rejected_at timestamptz default now(),employee_name text);
create table if not exists public.crm_customer_assignments (id uuid primary key default gen_random_uuid(),customer_id uuid references public.crm_customers(id) on delete cascade,previous_employee_id uuid,new_employee_id uuid,previous_employee_name text,new_employee_name text,assigned_by uuid,assigned_by_name text,assigned_at timestamptz default now());
create table if not exists public.crm_notifications (id uuid primary key default gen_random_uuid(),customer_id uuid references public.crm_customers(id) on delete cascade,user_id uuid,title text,body text,status text default 'new',snoozed_until timestamptz,created_at timestamptz default now());
create table if not exists public.crm_files (id uuid primary key default gen_random_uuid(),customer_id uuid references public.crm_customers(id) on delete cascade,file_name text,file_type text,file_url text,category text,version_number integer default 1,uploaded_by_name text,created_at timestamptz default now());
create table if not exists public.crm_audit_logs (id uuid primary key default gen_random_uuid(),entity_type text,entity_id uuid,action text,user_id uuid,user_name text,old_data jsonb,new_data jsonb,reason text,created_at timestamptz default now());
create table if not exists public.crm_sources (id uuid primary key default gen_random_uuid(),name text unique not null,is_active boolean default true);
create table if not exists public.crm_settings (id uuid primary key default gen_random_uuid(),setting_key text unique not null,setting_value jsonb,updated_at timestamptz default now());
create table if not exists public.crm_operation_handover (id uuid primary key default gen_random_uuid(),customer_id uuid references public.crm_customers(id) on delete cascade,project_id uuid,status text,handover_at timestamptz,sales_employee_name text,operations_manager text,created_by_name text,created_at timestamptz default now());
-- RLS should be enabled and policies adapted to the existing authenticated roles before production use.

-- V10603 RLS compatibility for the current custom-login frontend.
-- For existing installations, run supabase_crm_rls_cards_fix_v10603.sql.

-- V10604 compatibility: old crm_tasks tables may exist without customer_id.
alter table if exists public.crm_tasks add column if not exists customer_id uuid;
create index if not exists crm_tasks_customer_id_idx on public.crm_tasks(customer_id);
notify pgrst, 'reload schema';


-- V10605 compatibility: complete crm_communications schema and reload PostgREST cache.
alter table if exists public.crm_communications add column if not exists communication_date date;
alter table if exists public.crm_communications add column if not exists communication_time time;
notify pgrst, 'reload schema';

-- V10606 compatibility: customer quote summary fields.
alter table if exists public.crm_customers add column if not exists last_quote_id uuid;
alter table if exists public.crm_customers add column if not exists last_quote_value numeric(14,2);
create index if not exists crm_customers_last_quote_id_idx on public.crm_customers(last_quote_id);
notify pgrst, 'reload schema';

-- V10610: schema-compatible CRM audit using existing canonical columns.
-- Customer name is stored in contact_person and phone in mobile.
-- Actor names are stored in sales_employee_name, changed_by_name, employee_name,
-- assigned_to_name, created_by_name where those canonical columns already exist.

create or replace function public.crm_prevent_status_history_change()
returns trigger
language plpgsql
as $$
begin
  raise exception 'سجل تغيير الحالة معتمد وغير قابل للتعديل أو الحذف';
end;
$$;

drop trigger if exists crm_status_history_immutable on public.crm_customer_status_history;
create trigger crm_status_history_immutable
before update or delete on public.crm_customer_status_history
for each row execute function public.crm_prevent_status_history_change();

notify pgrst, 'reload schema';
