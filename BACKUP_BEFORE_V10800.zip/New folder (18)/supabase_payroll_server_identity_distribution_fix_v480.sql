-- V480 جذري: توحيد هوية الموظف، ربط التوزيع والحضور من السيرفر، ومنع الصفوف التقنية والمكررة.
create index if not exists idx_monthly_distribution_worker_month_v480
  on public.monthly_distribution (month_key, worker_employee_code);
create index if not exists idx_monthly_distribution_supervisor_month_v480
  on public.monthly_distribution (month_key, supervisor_employee_code);
create index if not exists idx_attendance_worker_date_v480
  on public.attendance (worker_id, attendance_date);

create or replace function public.get_unified_payroll_from_server(p_month text)
returns jsonb
language plpgsql
security invoker
set search_path = public
set statement_timeout = '120s'
as $$
#variable_conflict use_column
declare
  v_start date;
  v_end date;
  v_result jsonb;
  v_duplicates integer;
begin
  if p_month is null or p_month !~ '^\d{4}-\d{2}$' then
    raise exception 'Invalid payroll month: %', p_month;
  end if;

  v_start := (p_month || '-01')::date;
  v_end := (v_start + interval '1 month - 1 day')::date;

  with
  employee_source as (
    select 1::int source_priority, 'employees_master_v386'::text source_table, to_jsonb(e) j
      from public.employees_master_v386 e
    union all
    select 2::int, 'workers'::text, to_jsonb(w)
      from public.workers w
    union all
    select 3::int, 'app_users'::text, to_jsonb(u)
      from public.app_users u
     where coalesce(nullif(to_jsonb(u)->>'employee_code',''),nullif(to_jsonb(u)->>'worker_code',''),nullif(to_jsonb(u)->>'employee_ts_id','')) is not null
       and lower(coalesce(to_jsonb(u)->>'role',to_jsonb(u)->>'job_title',to_jsonb(u)->>'position','')) ~ '(supervisor|technician|guard|مشرف|فني|حارس|امن|صيانة)'
  ),
  employee_normalized as (
    select
      es.*,
      lower(coalesce(nullif(es.j->>'employee_code',''),nullif(es.j->>'worker_code',''),nullif(es.j->>'employee_ts_id',''),nullif(es.j->>'code',''))) code_key,
      regexp_replace(coalesce(es.j->>'iqama_number',es.j->>'residency_number',es.j->>'national_id',''),'\D','','g') iqama_key,
      lower(regexp_replace(translate(coalesce(es.j->>'app_name',es.j->>'display_name',es.j->>'name',es.j->>'full_name',es.j->>'worker_name',es.j->>'iqama_name',''),'أإآىة','ااايه'),'[^[:alnum:]ء-ي]+','','g')) name_key,
      array_remove(array[
        nullif(es.j->>'id',''),nullif(es.j->>'employee_id',''),nullif(es.j->>'worker_id',''),nullif(es.j->>'staff_id',''),nullif(es.j->>'person_id',''),
        nullif(es.j->>'employee_code',''),nullif(es.j->>'worker_code',''),nullif(es.j->>'employee_ts_id',''),nullif(es.j->>'code',''),nullif(es.j->>'username','')
      ],null) aliases,
      case
        when lower(coalesce(es.j->>'is_active',''))='true' then true
        when lower(coalesce(es.j->>'is_active',''))='false' then false
        when lower(coalesce(es.j->>'status',es.j->>'employee_status',es.j->>'work_status','active')) in ('inactive','stopped','terminated','disabled','موقوف','متوقف','منتهي','خارج العمل') then false
        else true
      end active_now
    from employee_source es
  ),
  employee_keyed as (
    select en.*,
      coalesce(
        case when en.code_key is not null and en.code_key<>'' then 'code:'||en.code_key end,
        case when length(en.iqama_key)>=6 then 'iqama:'||en.iqama_key end,
        case when en.name_key<>'' then 'legacy-name:'||en.name_key||':'||lower(coalesce(en.j->>'job_title',en.j->>'position',en.j->>'role','عامل')) end,
        'row:'||en.source_table||':'||coalesce(en.j->>'id',en.j->>'employee_id',en.j->>'worker_id')
      ) canonical_employee_id
    from employee_normalized en
    where coalesce(en.j->>'id',en.j->>'employee_id',en.j->>'worker_id',en.j->>'employee_code',en.j->>'worker_code',en.j->>'employee_ts_id') is not null
  ),
  employees_all as (
    select
      ek.canonical_employee_id,
      array_agg(distinct a.alias) filter(where a.alias is not null) aliases,
      (array_agg(ek.j order by ek.source_priority))[1] j,
      bool_or(ek.active_now) active_now,
      count(*)::int merged_profile_count
    from employee_keyed ek
    left join lateral unnest(ek.aliases) a(alias) on true
    group by ek.canonical_employee_id
  ),
  employees as (
    select * from employees_all
     where active_now=true
       and coalesce(lower(j->>'is_deleted'),'false')<>'true'
  ),
  projects as (
    select
      coalesce(nullif(to_jsonb(p)->>'id',''),nullif(to_jsonb(p)->>'project_id','')) project_id,
      coalesce(nullif(to_jsonb(p)->>'name',''),nullif(to_jsonb(p)->>'project_name',''),nullif(to_jsonb(p)->>'title',''),'مشروع') project_name,
      coalesce(nullif(to_jsonb(p)->>'operation_type',''),nullif(to_jsonb(p)->>'project_type',''),'') operation_type,
      coalesce(nullif(to_jsonb(p)->>'required_daily_minutes','')::numeric,540) required_daily_minutes,
      coalesce(nullif(to_jsonb(p)->>'friday_minutes','')::numeric,0) friday_minutes
    from public.projects p
    where (
      lower(coalesce(to_jsonb(p)->>'is_active',''))='true'
      or (to_jsonb(p)->>'is_active' is null and lower(coalesce(to_jsonb(p)->>'status','active')) not in ('inactive','stopped','terminated','disabled','موقوف','متوقف','منتهي'))
    )
  ),
  distribution_source as (
    select to_jsonb(d) j
    from public.monthly_distribution d
    where d.month_key=p_month
  ),
  assignments_raw as (
    select
      coalesce(nullif(j->>'worker_employee_code',''),nullif(j->>'employee_code',''),nullif(j->>'employee_id',''),nullif(j->>'worker_id','')) worker_ref,
      coalesce(nullif(j->>'supervisor_employee_code',''),nullif(j->>'supervisor_code',''),nullif(j->>'supervisor_id','')) supervisor_ref,
      nullif(j->>'supervisor_name','') supervisor_name_raw,
      coalesce(nullif(j->>'project_id',''),nullif(j->>'project_code','')) project_ref,
      nullif(j->>'project_name','') project_name_raw,
      greatest(coalesce(nullif(j->>'start_date','')::date,v_start),v_start) assignment_start,
      least(coalesce(nullif(j->>'end_date','')::date,v_end),v_end) assignment_end,
      coalesce(nullif(j->>'role_type',''),nullif(j->>'job_title','')) role_type,
      j
    from distribution_source
    where coalesce(lower(j->>'status'),'active') not in ('deleted','cancelled','inactive','stopped','ملغي','محذوف','موقوف')
  ),
  assignments_linked as (
    select distinct on (e.canonical_employee_id,ar.project_ref,ar.supervisor_ref,ar.assignment_start,ar.assignment_end)
      e.canonical_employee_id, ar.supervisor_ref, ar.supervisor_name_raw,
      ar.project_ref, ar.project_name_raw, ar.assignment_start, ar.assignment_end,
      greatest((ar.assignment_end-ar.assignment_start)+1,0)::int overlap_days, ar.role_type
    from assignments_raw ar
    join employees e on lower(ar.worker_ref)=any(select lower(x) from unnest(e.aliases) x)
    where ar.assignment_start<=ar.assignment_end
    order by e.canonical_employee_id,ar.project_ref,ar.supervisor_ref,ar.assignment_start,ar.assignment_end
  ),
  supervisor_profiles as (
    select distinct on (ar.supervisor_ref)
      ar.supervisor_ref,
      e.canonical_employee_id supervisor_id,
      coalesce(nullif(e.j->>'app_name',''),nullif(e.j->>'display_name',''),nullif(e.j->>'name',''),nullif(e.j->>'full_name',''),ar.supervisor_name_raw,'مشرف') supervisor_name
    from assignments_raw ar
    left join employees e on lower(ar.supervisor_ref)=any(select lower(x) from unnest(e.aliases) x)
    where ar.supervisor_ref is not null
    order by ar.supervisor_ref,e.canonical_employee_id
  ),
  assignments_enriched as (
    select
      a.canonical_employee_id,
      coalesce(sp.supervisor_id,'distribution-supervisor:'||a.supervisor_ref) supervisor_id,
      coalesce(sp.supervisor_name,a.supervisor_name_raw,'دون مشرف') supervisor_name,
      coalesce(p.project_id,a.project_ref) project_id,
      coalesce(p.project_name,a.project_name_raw,'تعذر ربط المشروع') project_name,
      coalesce(p.operation_type,'') operation_type,
      coalesce(p.required_daily_minutes,540) required_daily_minutes,
      coalesce(p.friday_minutes,0) friday_minutes,
      a.assignment_start,a.assignment_end,a.overlap_days,a.role_type
    from assignments_linked a
    left join supervisor_profiles sp on sp.supervisor_ref=a.supervisor_ref
    left join projects p on p.project_id=a.project_ref
  ),
  supervisor_days as (
    select canonical_employee_id,supervisor_id,max(supervisor_name) supervisor_name,
           sum(overlap_days)::int supervisor_days,max(assignment_start) latest_start
    from assignments_enriched
    group by canonical_employee_id,supervisor_id
  ),
  primary_supervisor as (
    select canonical_employee_id,supervisor_id,supervisor_name,supervisor_days
    from (
      select sd.*,row_number() over(partition by canonical_employee_id order by supervisor_days desc,latest_start desc,supervisor_id) rn
      from supervisor_days sd
    ) x where rn=1
  ),
  attendance_raw as (
    select
      coalesce(nullif(to_jsonb(a)->>'employee_id',''),nullif(to_jsonb(a)->>'worker_id',''),nullif(to_jsonb(a)->>'staff_id',''),nullif(to_jsonb(a)->>'person_id',''),nullif(to_jsonb(a)->>'user_id','')) employee_ref,
      coalesce(nullif(to_jsonb(a)->>'attendance_date','')::date,nullif(to_jsonb(a)->>'date','')::date,(nullif(to_jsonb(a)->>'created_at',''))::timestamptz::date) attendance_date,
      lower(coalesce(to_jsonb(a)->>'status',to_jsonb(a)->>'attendance_status','')) attendance_status,
      coalesce(nullif(to_jsonb(a)->>'check_in',''),nullif(to_jsonb(a)->>'in_time',''),nullif(to_jsonb(a)->>'start_time','')) check_in,
      coalesce(nullif(to_jsonb(a)->>'check_out',''),nullif(to_jsonb(a)->>'out_time',''),nullif(to_jsonb(a)->>'end_time','')) check_out,
      to_jsonb(a) j
    from public.attendance a
    where a.attendance_date>=v_start and a.attendance_date<(v_end+1)
  ),
  attendance_linked as (
    select e.canonical_employee_id,ar.attendance_date,
      bool_or(ar.attendance_status in ('present','حاضر','late','متأخر') or ar.check_in is not null) present,
      bool_or(ar.attendance_status in ('absent','غائب')) absent,
      min(ar.check_in) check_in,max(ar.check_out) check_out
    from attendance_raw ar
    join employees e on lower(ar.employee_ref)=any(select lower(x) from unnest(e.aliases) x)
    where ar.attendance_date between v_start and v_end
      and coalesce(lower(ar.j->>'is_deleted'),'false')<>'true'
      and coalesce(lower(ar.j->>'is_cancelled'),'false')<>'true'
      and coalesce(lower(ar.j->>'status'),'') not in ('cancelled','rejected','failed','ملغي','مرفوض','غير معتمد')
    group by e.canonical_employee_id,ar.attendance_date
  ),
  attendance_agg as (
    select canonical_employee_id,
      min(attendance_date) filter(where present) first_attendance_date,
      count(*) filter(where present)::int present_days,
      count(*) filter(where absent)::int explicit_absent_days,
      count(*)::int attendance_rows,
      jsonb_agg(jsonb_build_object('date',attendance_date,'present',present,'absent',absent,'check_in',check_in,'check_out',check_out) order by attendance_date) attendance_days
    from attendance_linked group by canonical_employee_id
  ),
  service_dates as (
    select e.canonical_employee_id,
      greatest(v_start,
        coalesce(nullif(e.j->>'work_start_date','')::date,nullif(e.j->>'hire_date','')::date,nullif(e.j->>'joining_date','')::date,v_start),
        coalesce((select min(a.assignment_start) from assignments_enriched a where a.canonical_employee_id=e.canonical_employee_id),v_start),
        coalesce(at.first_attendance_date,v_start)
      ) service_start,
      least(v_end,coalesce(nullif(e.j->>'work_end_date','')::date,nullif(e.j->>'termination_date','')::date,nullif(e.j->>'stop_date','')::date,v_end)) service_end
    from employees e left join attendance_agg at using(canonical_employee_id)
  ),
  assignment_json as (
    select canonical_employee_id,
      jsonb_agg(jsonb_build_object('project_id',project_id,'project_name',project_name,'supervisor_id',supervisor_id,'supervisor_name',supervisor_name,'start',assignment_start,'end',assignment_end,'days',overlap_days,'operation_type',operation_type) order by assignment_start) assignment_details,
      array_agg(distinct project_id) filter(where project_id is not null) project_ids,
      array_agg(distinct project_name) filter(where project_name is not null and project_name<>'تعذر ربط المشروع') project_names,
      count(distinct supervisor_id)>1 multiple_supervisors
    from assignments_enriched group by canonical_employee_id
  ),
  adjustments as (
    select e.canonical_employee_id,
      coalesce(sum(pa.amount) filter(where lower(pa.adjustment_type) in ('allowance','بدل','بدلات')),0) allowances,
      coalesce(sum(pa.amount) filter(where lower(pa.adjustment_type) in ('commission','bonus','حافز','عمولة')),0) commissions,
      coalesce(sum(pa.amount) filter(where lower(pa.adjustment_type) in ('advance','سلفة')),0) advances,
      coalesce(sum(pa.amount) filter(where lower(pa.adjustment_type) in ('deduction','خصم','جزاء')),0) deductions
    from public.payroll_adjustments pa
    join employees e on lower(coalesce(pa.employee_id::text,pa.worker_id::text))=any(select lower(x) from unnest(e.aliases) x)
    where pa.effective_date between v_start and v_end and coalesce(pa.is_deleted,false)=false
      and lower(coalesce(pa.status,'approved')) in ('approved','معتمد')
    group by e.canonical_employee_id
  ),
  payroll_rows as (
    select
      e.canonical_employee_id,e.canonical_employee_id worker_id,
      coalesce(nullif(e.j->>'employee_code',''),nullif(e.j->>'worker_code',''),nullif(e.j->>'employee_ts_id',''),nullif(e.j->>'code',''),'') employee_code,
      p_month "month",
      coalesce(nullif(e.j->>'iqama_name',''),nullif(e.j->>'residency_name',''),nullif(e.j->>'official_name',''),nullif(e.j->>'full_name',''),nullif(e.j->>'name',''),'موظف') residency_name,
      coalesce(nullif(e.j->>'app_name',''),nullif(e.j->>'display_name',''),nullif(e.j->>'name',''),nullif(e.j->>'full_name',''),'موظف') worker_name,
      coalesce(nullif(e.j->>'iqama_number',''),nullif(e.j->>'residency_number',''),nullif(e.j->>'national_id',''),'') iqama_number,
      case
        when lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'employee_type',e.j->>'job_type',e.j->>'role','')) ~ '(supervisor|مشرف)' then 'مشرف'
        when lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'employee_type',e.j->>'job_type',e.j->>'role','')) ~ '(technician|فني|صيانة)' then 'فني'
        when lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'employee_type',e.j->>'job_type',e.j->>'role','')) ~ '(guard|حارس|امن)' then 'حارس'
        else coalesce(nullif(e.j->>'job_title',''),nullif(e.j->>'position',''),nullif(e.j->>'employee_type',''),nullif(e.j->>'job_type',''),'عامل') end job_title,
      ps.supervisor_id,coalesce(ps.supervisor_name,'دون مشرف') supervisor_name,
      case
        when coalesce(array_length(aj.project_names,1),0)>1 then 'متعدد'
        when coalesce(array_length(aj.project_names,1),0)=1 then
          case when exists(select 1 from assignments_enriched ae where ae.canonical_employee_id=e.canonical_employee_id and lower(ae.operation_type) in ('daily_visit','زيارة يومية'))
               then coalesce(ps.supervisor_name,'دون مشرف') else aj.project_names[1] end
        when lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'role','')) ~ '(فني|technician|صيانة)' then 'فريق الصيانة'
        when lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'role','')) ~ '(مشرف|supervisor)' then 'إدارة التشغيل'
        when lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'role','')) ~ '(حارس|guard|امن)' then 'دون توزيع حراسة'
        else 'دون توزيع' end work_location,
      coalesce(to_jsonb(aj.project_ids),'[]'::jsonb) project_ids,
      coalesce(to_jsonb(aj.project_names),'[]'::jsonb) project_names,
      coalesce(aj.assignment_details,'[]'::jsonb) assignment_details,
      coalesce(aj.multiple_supervisors,false) multiple_supervisors,
      sd.service_start,at.first_attendance_date,sd.service_end,
      least(greatest((sd.service_end-sd.service_start)+1,0),30)::int month_days,
      coalesce(at.present_days,0)::int work_days,
      coalesce(at.present_days,0)::int present_days,
      case when coalesce(at.attendance_rows,0)=0 then null else coalesce(at.explicit_absent_days,0)::int end absent_days,
      least(greatest((sd.service_end-sd.service_start)+1,0),30)::int due_days,
      0::numeric required_minutes,0::numeric actual_minutes,
      coalesce(nullif(e.j->>'basic_salary','')::numeric,nullif(e.j->>'base_salary','')::numeric,nullif(e.j->>'salary','')::numeric,0) base_salary,
      coalesce(nullif(e.j->>'allowances','')::numeric,nullif(e.j->>'allowance','')::numeric,0)+coalesce(ad.allowances,0) allowances,
      coalesce(ad.commissions,0) commissions,coalesce(ad.advances,0) advances,coalesce(ad.deductions,0) other_deductions,
      0::numeric rounding,coalesce(at.attendance_days,'[]'::jsonb) details,
      e.merged_profile_count
    from employees e
    left join primary_supervisor ps using(canonical_employee_id)
    left join assignment_json aj using(canonical_employee_id)
    left join attendance_agg at using(canonical_employee_id)
    left join service_dates sd using(canonical_employee_id)
    left join adjustments ad using(canonical_employee_id)
  ),
  final_rows as (
    select pr.*,
      (pr.base_salary+pr.allowances) gross_salary,
      ((pr.base_salary+pr.allowances)/30.0*pr.due_days) period_salary,
      case when pr.absent_days is null then 0 else (pr.base_salary/30.0*pr.absent_days) end absence_deduction,
      (pr.other_deductions+case when pr.absent_days is null then 0 else (pr.base_salary/30.0*pr.absent_days) end) deductions,
      (((pr.base_salary+pr.allowances)/30.0*pr.due_days)+pr.commissions+pr.rounding-pr.other_deductions-pr.advances-
        case when pr.absent_days is null then 0 else (pr.base_salary/30.0*pr.absent_days) end) net_salary,
      case when pr.absent_days is null then 'يحتاج مراجعة' when pr.base_salary=0 then 'يحتاج مراجعة' else 'مسودة' end status,
      case when pr.absent_days is null then jsonb_build_array('تعذر احتساب الغياب: لا توجد بيانات حضور')
           when pr.base_salary=0 then jsonb_build_array('الراتب الأساسي غير مسجل') else '[]'::jsonb end issues,
      ''::text notes
    from payroll_rows pr
  ),
  duplicate_check as (
    select canonical_employee_id,count(*) n from final_rows group by canonical_employee_id having count(*)>1
  ),
  supervisor_counts as (
    select coalesce(supervisor_id,'none') supervisor_id,max(supervisor_name) supervisor_name,count(distinct canonical_employee_id)::int payroll_workers
    from final_rows group by coalesce(supervisor_id,'none')
  ),
  diagnostics as (
    select jsonb_build_object(
      'period_start',v_start,'period_end',v_end,
      'raw_employee_records',(select count(*) from employee_source),
      'raw_assignments',(select count(*) from assignments_raw),
      'raw_attendance_records',(select count(*) from attendance_raw),
      'canonical_employee_ids',(select count(*) from employees),
      'duplicateRowsRemoved',(select coalesce(sum(greatest(merged_profile_count-1,0)),0)::int from employees_all),
      'merged_duplicate_profiles',(select coalesce(sum(greatest(merged_profile_count-1,0)),0)::int from employees_all),
      'duplicate_ids_found',(select count(*) from duplicate_check),
      'final_payroll_rows',(select count(*) from final_rows),
      'workers_count',(select count(*) from final_rows where job_title not in ('مشرف','فني','حارس')),
      'guards_count',(select count(*) from final_rows where job_title='حارس'),
      'technicians_count',(select count(*) from final_rows where job_title='فني'),
      'supervisors_count',(select count(*) from final_rows where job_title='مشرف'),
      'without_supervisor_count',(select count(*) from final_rows where supervisor_id is null),
      'supervisor_counts',coalesce((select jsonb_agg(to_jsonb(sc)) from supervisor_counts sc),'[]'::jsonb)
    ) j
  )
  select jsonb_build_object(
    'rows',coalesce((select jsonb_agg(to_jsonb(fr) order by fr.supervisor_name,fr.job_title,fr.employee_code,fr.worker_name) from final_rows fr),'[]'::jsonb),
    'projects',coalesce((select jsonb_agg(jsonb_build_object('id',project_id,'name',project_name,'operation_type',operation_type)) from projects),'[]'::jsonb),
    'diagnostics',(select j from diagnostics),
    'incomplete',false
  ) into v_result;

  v_duplicates:=coalesce((v_result->'diagnostics'->>'duplicate_ids_found')::int,0);
  if v_duplicates<>0 then
    raise exception 'Duplicate payroll employees detected';
  end if;
  if coalesce((v_result->'diagnostics'->>'final_payroll_rows')::int,0)<>coalesce((v_result->'diagnostics'->>'canonical_employee_ids')::int,0) then
    raise exception 'Payroll row count does not match canonical employees';
  end if;
  return v_result;
end;
$$;

grant execute on function public.get_unified_payroll_from_server(text) to anon,authenticated;
