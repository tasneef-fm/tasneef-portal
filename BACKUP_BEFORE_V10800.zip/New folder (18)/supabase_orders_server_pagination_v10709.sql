-- Tasneef Orders Server Pagination v10709
-- شغّل هذا الملف مرة واحدة داخل Supabase SQL Editor قبل نشر النسخة.
-- لا يحذف ولا يعدّل أي أوردر قائم.

begin;

create or replace function public.normalize_order_number_v10709(p_value text)
returns text
language sql
immutable
as $$
  select regexp_replace(
    translate(coalesce(p_value,''), '٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹', '01234567890123456789'),
    '\\s+', '', 'g'
  );
$$;

create or replace function public.get_unified_orders_v10709(
  p_page integer default 1,
  p_page_size integer default 50,
  p_search text default null,
  p_project text default null,
  p_executor text default null,
  p_sender text default null,
  p_execution_status text default null,
  p_payment_status text default null,
  p_invoice_status text default null,
  p_order_type text default null,
  p_date_from date default null,
  p_date_to date default null,
  p_allowed_projects text[] default null,
  p_export boolean default false
)
returns table(rows jsonb,total bigint,page integer,page_size integer,total_pages integer)
language sql
security invoker
set search_path = public
as $$
with source as (
  select
    o.order_no,
    o.data,
    o.flow,
    o.updated_at,
    coalesce(nullif(o.order_no,''), nullif(o.data->>'order_number',''), nullif(o.data->>'external_order_number',''), nullif(o.data->>'legacy_order_number',''), nullif(o.data->>'excel_order_number',''), nullif(o.data->>'رقم الطلب','')) as canonical_order_number,
    coalesce(nullif(o.data->>'project_name',''), nullif(o.data->>'المشروع',''), nullif(o.data->>'اسم المشروع',''), nullif(o.flow->>'project_name',''), nullif(o.flow->>'المشروع','')) as project_name,
    coalesce(nullif(o.data->>'customer_name',''), nullif(o.data->>'اسم العميل','')) as customer_name,
    coalesce(nullif(o.data->>'customer_phone',''), nullif(o.data->>'رقم العميل',''), nullif(o.data->>'mobile','')) as customer_phone,
    coalesce(nullif(o.data->>'executor_name',''), nullif(o.data->>'المنفذ','')) as executor_name,
    coalesce(nullif(o.data->>'created_by_name',''), nullif(o.data->>'منشئ الطلب',''), nullif(o.data->>'مرسل الطلب','')) as sender_name,
    coalesce(nullif(o.data->>'status',''), nullif(o.data->>'حالة التنفيذ','')) as execution_status,
    coalesce(nullif(o.data->>'payment_status',''), nullif(o.data->>'حالة السداد','')) as payment_status,
    coalesce(nullif(o.data->>'billing_status',''), nullif(o.data->>'حالة الفوترة',''), 'لم تتم') as invoice_status,
    coalesce(nullif(o.data->>'order_type',''), nullif(o.data->>'نوع الطلب','')) as order_type,
    case
      when coalesce(o.data->>'order_date',o.data->>'تاريخ الطلب','') ~ '^\\d{4}-\\d{2}-\\d{2}$'
        then coalesce(o.data->>'order_date',o.data->>'تاريخ الطلب')::date
      else (o.updated_at at time zone 'Asia/Riyadh')::date
    end as order_date
  from public.orders_shared o
), filtered as (
  select * from source s
  where
    (p_allowed_projects is null or s.project_name = any(p_allowed_projects))
    and (nullif(trim(p_project),'') is null or s.project_name = p_project)
    and (nullif(trim(p_executor),'') is null or s.executor_name = p_executor)
    and (nullif(trim(p_sender),'') is null or s.sender_name = p_sender)
    and (nullif(trim(p_execution_status),'') is null or s.execution_status = p_execution_status)
    and (nullif(trim(p_payment_status),'') is null or s.payment_status = p_payment_status)
    and (nullif(trim(p_invoice_status),'') is null or s.invoice_status = p_invoice_status)
    and (nullif(trim(p_order_type),'') is null or s.order_type = p_order_type)
    and (p_date_from is null or s.order_date >= p_date_from)
    and (p_date_to is null or s.order_date <= p_date_to)
    and (
      nullif(trim(p_search),'') is null
      or public.normalize_order_number_v10709(s.canonical_order_number) like '%' || public.normalize_order_number_v10709(p_search) || '%'
      or coalesce(s.customer_name,'') ilike '%' || trim(p_search) || '%'
      or coalesce(s.customer_phone,'') ilike '%' || trim(p_search) || '%'
      or coalesce(s.project_name,'') ilike '%' || trim(p_search) || '%'
      or coalesce(s.executor_name,'') ilike '%' || trim(p_search) || '%'
      or coalesce(s.order_type,'') ilike '%' || trim(p_search) || '%'
    )
), counted as (
  select count(*)::bigint as total from filtered
), paged as (
  select f.*
  from filtered f
  order by f.updated_at desc nulls last, f.canonical_order_number desc nulls last
  limit case when p_export then 100000 else greatest(1,least(coalesce(p_page_size,50),100)) end
  offset case when p_export then 0 else (greatest(coalesce(p_page,1),1)-1) * greatest(1,least(coalesce(p_page_size,50),100)) end
)
select
  coalesce(jsonb_agg(jsonb_build_object(
    'order_no', p.order_no,
    'data', p.data
      - '__tasneef_order_receipt_v10140'
      - 'بيانات الإيصال'
      - 'receipt_meta'
      - 'receipt_data'
      - 'الإيصال'
      - 'receipt'
      - 'receipt_url'
      - 'receiptUrl'
      - 'attachment'
      - 'attachment_url'
      - 'file_url',
    'flow', p.flow,
    'updated_at', p.updated_at,
    '__light', true,
    '__has_receipt', (
      p.data ? '__tasneef_order_receipt_v10140' or p.data ? 'بيانات الإيصال' or p.data ? 'الإيصال' or
      p.data ? 'receipt' or p.data ? 'receipt_url' or p.data ? 'attachment' or p.data ? 'attachment_url' or p.data ? 'file_url'
    )
  ) order by p.updated_at desc nulls last, p.canonical_order_number desc nulls last), '[]'::jsonb) as rows,
  c.total,
  greatest(coalesce(p_page,1),1) as page,
  greatest(1,least(coalesce(p_page_size,50),100)) as page_size,
  greatest(1,ceil(c.total::numeric / greatest(1,least(coalesce(p_page_size,50),100)))::integer) as total_pages
from counted c
left join paged p on true
group by c.total;
$$;

create or replace function public.get_unified_orders_summary_v10709(
  p_search text default null,
  p_project text default null,
  p_executor text default null,
  p_sender text default null,
  p_execution_status text default null,
  p_payment_status text default null,
  p_invoice_status text default null,
  p_order_type text default null,
  p_date_from date default null,
  p_date_to date default null,
  p_allowed_projects text[] default null
)
returns jsonb
language sql
security invoker
set search_path = public
as $$
with x as (
  select * from public.get_unified_orders_v10709(1,100,p_search,p_project,p_executor,p_sender,p_execution_status,p_payment_status,p_invoice_status,p_order_type,p_date_from,p_date_to,p_allowed_projects,true)
), items as (
  select jsonb_array_elements(x.rows) as r from x
)
select jsonb_build_object(
  'total_orders', (select total from x),
  'completed_orders', count(*) filter (where coalesce(r->'data'->>'status',r->'data'->>'حالة التنفيذ','') ilike '%تم التنفيذ%'),
  'unpaid_orders', count(*) filter (where coalesce(r->'data'->>'payment_status',r->'data'->>'حالة السداد','') ~ '(آجل|جزئي|غير مسدد|لم يتم)'),
  'total_net_profit', coalesce(sum(nullif(regexp_replace(coalesce(r->'data'->>'net_profit',r->'data'->>'الربح','0'),'[^0-9.\\-]','','g'),'')::numeric),0)
) from items;
$$;

create index if not exists idx_orders_shared_updated_at_v10709 on public.orders_shared(updated_at desc);
create index if not exists idx_orders_shared_order_no_v10709 on public.orders_shared(order_no);
create index if not exists idx_orders_shared_data_gin_v10709 on public.orders_shared using gin(data jsonb_path_ops);
create index if not exists idx_orders_shared_project_v10709 on public.orders_shared((coalesce(data->>'project_name',data->>'المشروع',data->>'اسم المشروع')));
create index if not exists idx_orders_shared_executor_v10709 on public.orders_shared((coalesce(data->>'executor_name',data->>'المنفذ')));
create index if not exists idx_orders_shared_status_v10709 on public.orders_shared((coalesce(data->>'status',data->>'حالة التنفيذ')));
create index if not exists idx_orders_shared_payment_v10709 on public.orders_shared((coalesce(data->>'payment_status',data->>'حالة السداد')));
create index if not exists idx_orders_shared_billing_v10709 on public.orders_shared((coalesce(data->>'billing_status',data->>'حالة الفوترة')));

commit;
notify pgrst, 'reload schema';
