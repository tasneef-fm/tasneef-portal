-- Tasneef CRM V10603: fix RLS for the current custom-login frontend.
-- Run this file once in Supabase SQL Editor.
-- The current system uses app_users/custom login rather than Supabase Auth,
-- therefore direct browser requests run with the anon database role.

begin;

do $$
declare
  t text;
  p record;
  crm_tables text[] := array[
    'crm_customers',
    'crm_customer_status_history',
    'crm_communications',
    'crm_tasks',
    'crm_quotes',
    'crm_quote_versions',
    'crm_contracts',
    'crm_rejection_reasons',
    'crm_customer_assignments',
    'crm_notifications',
    'crm_files',
    'crm_audit_logs',
    'crm_sources',
    'crm_settings',
    'crm_operation_handover'
  ];
begin
  foreach t in array crm_tables loop
    if to_regclass('public.' || t) is null then
      continue;
    end if;

    execute format('alter table public.%I enable row level security', t);

    -- Remove old/conflicting CRM policies only from this CRM table.
    for p in
      select policyname
      from pg_policies
      where schemaname = 'public' and tablename = t
    loop
      execute format('drop policy if exists %I on public.%I', p.policyname, t);
    end loop;

    execute format(
      'create policy %I on public.%I for all to anon, authenticated using (true) with check (true)',
      'tasneef_crm_current_system_access', t
    );

    execute format('grant select, insert, update, delete on public.%I to anon, authenticated', t);
  end loop;
end $$;

grant usage on schema public to anon, authenticated;

commit;

-- Verification: should return one policy row for each existing CRM table.
select tablename, policyname, roles, cmd
from pg_policies
where schemaname = 'public' and tablename like 'crm_%'
order by tablename, policyname;
