-- V459 - Smart supervisor stop/reassign hardening
-- Adds safe fields used by the UI. No data is deleted.

ALTER TABLE public.employees_master_v386
  ADD COLUMN IF NOT EXISTS work_end_date date,
  ADD COLUMN IF NOT EXISTS service_end_date date,
  ADD COLUMN IF NOT EXISTS termination_date date,
  ADD COLUMN IF NOT EXISTS end_date date,
  ADD COLUMN IF NOT EXISTS is_active boolean,
  ADD COLUMN IF NOT EXISTS active boolean,
  ADD COLUMN IF NOT EXISTS state text;

ALTER TABLE public.workers
  ADD COLUMN IF NOT EXISTS employee_code text,
  ADD COLUMN IF NOT EXISTS work_end_date date,
  ADD COLUMN IF NOT EXISTS service_end_date date,
  ADD COLUMN IF NOT EXISTS termination_date date,
  ADD COLUMN IF NOT EXISTS end_date date,
  ADD COLUMN IF NOT EXISTS is_active boolean,
  ADD COLUMN IF NOT EXISTS active boolean,
  ADD COLUMN IF NOT EXISTS state text,
  ADD COLUMN IF NOT EXISTS allowances numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS total_salary numeric DEFAULT 0;

ALTER TABLE public.projects
  ADD COLUMN IF NOT EXISTS supervisor_employee_code text,
  ADD COLUMN IF NOT EXISTS supervisor_name text,
  ADD COLUMN IF NOT EXISTS current_supervisor_code text,
  ADD COLUMN IF NOT EXISTS current_supervisor_name text,
  ADD COLUMN IF NOT EXISTS supervisor_code text,
  ADD COLUMN IF NOT EXISTS app_supervisor_code text,
  ADD COLUMN IF NOT EXISTS app_supervisor_name text,
  ADD COLUMN IF NOT EXISTS updated_at timestamptz DEFAULT now();

ALTER TABLE public.monthly_distribution
  ADD COLUMN IF NOT EXISTS supervisor_employee_code text,
  ADD COLUMN IF NOT EXISTS supervisor_name text,
  ADD COLUMN IF NOT EXISTS end_date date,
  ADD COLUMN IF NOT EXISTS updated_at timestamptz DEFAULT now();

CREATE INDEX IF NOT EXISTS idx_projects_supervisor_employee_code_v459 ON public.projects(supervisor_employee_code);
CREATE INDEX IF NOT EXISTS idx_projects_current_supervisor_code_v459 ON public.projects(current_supervisor_code);
CREATE INDEX IF NOT EXISTS idx_monthly_distribution_supervisor_month_v459 ON public.monthly_distribution(supervisor_employee_code, month_key);
CREATE INDEX IF NOT EXISTS idx_monthly_distribution_worker_month_v459 ON public.monthly_distribution(worker_employee_code, month_key);
