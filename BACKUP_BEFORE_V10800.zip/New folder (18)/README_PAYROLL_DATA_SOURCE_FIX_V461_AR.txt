إصلاح مصدر بيانات الرواتب V461
================================

تم تعديل نفس الملف التنفيذي:
- tasneef_salaries_unified_source_v440.js
- admin.html (تحديث رقم الكاش إلى v=461)

سبب ظهور صفر عامل في الكود السابق:
1) جلب العمال كان مقيدًا بـ is_active=true، مما أسقط العامل التاريخي الموقوف بعد عمله في الشهر.
2) قائمة الاستحقاق بُنيت من العمال النشطين ثم اشترطت توزيعًا أو حضورًا فقط.
3) التوزيع التاريخي الذي يحمل is_active=false كان يُستبعد حتى لو تقاطع مع الشهر.
4) المصدر كان يختار worker_project_assignments حتى لو كان موجودًا لكنه فارغ، ولا ينتقل إلى monthly_distribution.
5) monthly_distribution يستخدم غالبًا worker_employee_code وsupervisor_employee_code وmonth_key، وهي حقول لم تكن داخلة في الربط.
6) أخطاء الجداول وRLS كانت تتحول إلى مصفوفات فارغة دون إظهار السبب الحقيقي.
7) التسجيلات الفعلية في النظام تستخدم time_logs في بعض المسارات، ولم تكن ضمن مصادر الرواتب.

الإصلاح:
- بناء eligible worker IDs من اتحاد: التوزيعات + الحضور + التسجيلات اليومية + مسيرات الشهر المحفوظة.
- إزالة التكرار باستخدام معرف العامل.
- عدم اشتراط النشاط الحالي للعامل أو المشروع في التقرير التاريخي.
- تطبيق شرط تقاطع التوزيع مع الفترة، ودعم month_key.
- دعم مصادر التوزيع بالترتيب الفعلي:
  worker_project_assignments ثم monthly_distribution ثم monthly_distribution_view.
- دعم التسجيلات:
  daily_records ثم daily_registrations ثم time_logs.
- دعم معرفات الربط:
  worker_id, employee_id, worker_code, employee_code, worker_employee_code, employee_ts_id.
- دعم معرفات المشرف:
  supervisor_id, app_supervisor_id, assigned_supervisor_id, supervisor_employee_code, supervisor_code.
- استخدام أول مصدر موجود وبه بيانات، وليس أول جدول موجود فقط.
- إظهار أخطاء RLS أو relation/column بوضوح بدل اعتبارها صفر بيانات.
- إنشاء تفاصيل أيام التوزيع حتى يظهر العامل دون حضور كـ "لا يوجد حضور" بدل اختفائه.
- زر إعادة الاحتساب يمسح كاش كشف الشهر فقط ويعيد الجلب دون تصفير الفلاتر.

التشخيص وقت التشغيل:
افتح Console ثم ابحث عن جدول [payroll]. كما تتوفر القيم في:
window.__tasneefPayrollDiagnostics

وتشمل:
periodStart, periodEnd, workersTable, assignmentsTable, attendanceTable, dailyTable,
workersCount, assignmentsCount, attendanceCount, dailyRecordsCount,
eligibleWorkerIdsCount, missingWorkerIdsCount, finalPayrollWorkersCount, sourceErrors.

ملاحظة:
الأعداد الفعلية لشهر يوليو 2026 لا يمكن إثباتها داخل حزمة الملفات دون اتصال قاعدة Supabase.
بعد رفع النسخة واختيار 2026-07 ستظهر الأعداد الفعلية في Console ورسالة الصفحة، وأي خطأ RLS أو اسم جدول/عمود سيظهر صراحة.
