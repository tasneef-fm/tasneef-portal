-- Tasneef V476: Supervisor report approval workflow
-- Run once in Supabase SQL Editor. Safe to run more than once.

-- Normalize incomplete supervisor submissions only; published history is untouched.
update public.client_reports
set status = 'draft',
    public_token = null,
    published_at = null
where report_type ilike '%المشرف%'
  and coalesce(status, '') not in ('published', 'draft');

create index if not exists client_reports_supervisor_approval_idx
on public.client_reports (status, created_at desc)
where report_type ilike '%المشرف%';

create index if not exists client_report_services_report_id_idx
on public.client_report_services (report_id, sort_order);

-- Verification query:
-- select id, report_no, project_name, report_type, status, public_token, published_at
-- from public.client_reports
-- where report_type ilike '%المشرف%'
-- order by created_at desc;
