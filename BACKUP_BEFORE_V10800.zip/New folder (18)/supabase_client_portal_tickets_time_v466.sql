-- V467 - بوابة العميل: إصلاح ظهور التسجيلات اليومية والتذاكر + حفظ التذكرة
-- شغّل هذا الملف مرة واحدة في Supabase SQL Editor

alter table if exists public.projects add column if not exists client_portal_token text;
alter table if exists public.projects add column if not exists client_portal_url text;
alter table if exists public.projects add column if not exists client_portal_short_url text;
alter table if exists public.projects add column if not exists client_portal_updated_at timestamptz;

create index if not exists idx_time_logs_client_project_date_v467 on public.time_logs(project_id, log_date);
create index if not exists idx_time_logs_client_checkin_v467 on public.time_logs(project_id, check_in);
create index if not exists idx_tickets_client_project_created_v467 on public.tickets(project_id, created_at);

create or replace function public.tasneef_client_portal_records_v467(
  p_project_id text,
  p_from date default null,
  p_to date default null
) returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_from date := coalesce(p_from, date_trunc('month', now())::date);
  v_to date := coalesce(p_to, current_date);
  v_logs jsonb := '[]'::jsonb;
  v_tickets jsonb := '[]'::jsonb;
begin
  if v_to < v_from then
    select v_to, v_from into v_from, v_to;
  end if;

  if to_regclass('public.time_logs') is not null then
    select coalesce(jsonb_agg(to_jsonb(x) order by coalesce(x.check_in, x.created_at) desc), '[]'::jsonb)
      into v_logs
    from (
      select *
      from public.time_logs
      where project_id::text = p_project_id
        and coalesce(log_date::date, check_in::date, created_at::date) between v_from and v_to
      order by coalesce(check_in, created_at) desc
      limit 5000
    ) x;
  end if;

  if to_regclass('public.tickets') is not null then
    select coalesce(jsonb_agg(to_jsonb(t) order by t.created_at desc), '[]'::jsonb)
      into v_tickets
    from (
      select *
      from public.tickets
      where project_id::text = p_project_id
        and created_at::date between v_from and v_to
      order by created_at desc
      limit 1000
    ) t;
  end if;

  return jsonb_build_object('logs', v_logs, 'tickets', v_tickets);
end;
$$;

grant execute on function public.tasneef_client_portal_records_v467(text,date,date) to anon, authenticated;

create or replace function public.tasneef_client_create_ticket_v466(
  p_project_id text,
  p_title text,
  p_description text default '',
  p_type text default 'أخرى',
  p_location text default '',
  p_client_name text default 'عميل المشروع',
  p_client_contact text default ''
) returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id bigint;
  v_project_id bigint;
  v_has_project_name boolean;
  v_has_ticket_no boolean;
  v_has_type boolean;
  v_has_source boolean;
  v_has_location boolean;
  v_has_client_name boolean;
  v_sql text;
  v_cols text := 'project_id,title,description,status,created_at';
  v_vals text := '$1,$2,$3,''open'',now()';
  v_project_name text;
begin
  if nullif(trim(coalesce(p_title,'')),'') is null then
    raise exception 'عنوان التذكرة مطلوب';
  end if;
  begin
    v_project_id := p_project_id::bigint;
  exception when others then
    v_project_id := null;
  end;
  select name into v_project_name from public.projects where id::text = p_project_id limit 1;
  select exists(select 1 from information_schema.columns where table_schema='public' and table_name='tickets' and column_name='project_name') into v_has_project_name;
  select exists(select 1 from information_schema.columns where table_schema='public' and table_name='tickets' and column_name='ticket_number') into v_has_ticket_no;
  select exists(select 1 from information_schema.columns where table_schema='public' and table_name='tickets' and column_name='type') into v_has_type;
  select exists(select 1 from information_schema.columns where table_schema='public' and table_name='tickets' and column_name='source') into v_has_source;
  select exists(select 1 from information_schema.columns where table_schema='public' and table_name='tickets' and column_name='location') into v_has_location;
  select exists(select 1 from information_schema.columns where table_schema='public' and table_name='tickets' and column_name='client_name') into v_has_client_name;
  if v_has_project_name then v_cols := v_cols||',project_name'; v_vals := v_vals||',$4'; end if;
  if v_has_type then v_cols := v_cols||',type'; v_vals := v_vals||',$5'; end if;
  if v_has_source then v_cols := v_cols||',source'; v_vals := v_vals||',''client_portal'''; end if;
  if v_has_location then v_cols := v_cols||',location'; v_vals := v_vals||',$6'; end if;
  if v_has_client_name then v_cols := v_cols||',client_name'; v_vals := v_vals||',$7'; end if;
  if v_has_ticket_no then v_cols := v_cols||',ticket_number'; v_vals := v_vals||',''T-''||to_char(extract(epoch from now())::bigint,''FM999999999999'')'; end if;
  v_sql := format('insert into public.tickets(%s) values(%s) returning id', v_cols, v_vals);
  execute v_sql using coalesce(v_project_id,0), p_title, concat_ws(E'\n', p_description, case when nullif(p_location,'') is not null then 'الموقع: '||p_location end, case when nullif(p_type,'') is not null then 'النوع: '||p_type end), coalesce(v_project_name,''), p_type, p_location, p_client_name into v_id;
  return jsonb_build_object('id',v_id,'project_id',coalesce(v_project_id,0),'project_name',v_project_name,'title',p_title,'description',p_description,'status','open','created_at',now(),'type',p_type,'location',p_location);
end;
$$;

grant execute on function public.tasneef_client_create_ticket_v466(text,text,text,text,text,text,text) to anon, authenticated;
