إصلاح CRM V10605
=================

المشكلة:
Could not find the communication_date column of crm_communications in the schema cache.

الإصلاح:
1) إضافة حقول communication_date و communication_time وبقية الحقول الناقصة للجدول القديم.
2) تحديث Schema Cache في PostgREST.
3) تعديل الواجهة بحيث تحفظ communication_at فقط ولا ترسل حقولًا زائدة إلى النسخ القديمة من الجدول.
4) تحديث كاش ملفات CRM إلى V10605.

التنفيذ:
شغّل supabase_crm_communications_schema_fix_v10605.sql في Supabase SQL Editor ثم حدّث الصفحة تحديثًا قويًا.
