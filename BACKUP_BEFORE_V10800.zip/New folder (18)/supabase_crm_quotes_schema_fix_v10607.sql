-- Tasneef CRM V10607
-- Complete crm_quotes / crm_quote_versions compatibility before updating crm_customers.
-- Safe for old installations; no data is deleted.
begin;

-- Ensure the current quote fields exist even when crm_quotes came from an older CRM version.
alter table if exists public.crm_quotes
  add column if not exists customer_id uuid,
  add column if not exists quote_number text,
  add column if not exists sent_date date,
  add column if not exists subtotal numeric(14,2),
  add column if not exists tax_value numeric(14,2),
  add column if not exists total_with_tax numeric(14,2),
  add column if not exists send_method text,
  add column if not exists expiry_date date,
  add column if not exists followup_date date,
  add column if not exists status text,
  add column if not exists notes text,
  add column if not exists created_by_name text,
  add column if not exists created_at timestamptz default now();

alter table if exists public.crm_quote_versions
  add column if not exists quote_id uuid,
  add column if not exists customer_id uuid,
  add column if not exists version_number integer,
  add column if not exists subtotal numeric(14,2),
  add column if not exists tax_value numeric(14,2),
  add column if not exists total_with_tax numeric(14,2),
  add column if not exists created_by_name text,
  add column if not exists created_at timestamptz default now();

-- If the old quotes table links through opportunity_id, translate it to customer_id
-- only when the matching columns/tables actually exist.
do $$
begin
  if to_regclass('public.crm_quotes') is not null
     and to_regclass('public.crm_opportunities') is not null
     and exists (
       select 1 from information_schema.columns
       where table_schema='public' and table_name='crm_quotes' and column_name='opportunity_id'
     )
     and exists (
       select 1 from information_schema.columns
       where table_schema='public' and table_name='crm_opportunities' and column_name='customer_id'
     ) then
    execute $sql$
      update public.crm_quotes q
         set customer_id = o.customer_id
        from public.crm_opportunities o
       where q.customer_id is null
         and q.opportunity_id = o.id
         and o.customer_id is not null
    $sql$;
  end if;
end $$;

-- A version row can inherit the customer from its quote.
update public.crm_quote_versions v
   set customer_id = q.customer_id
  from public.crm_quotes q
 where v.customer_id is null
   and v.quote_id = q.id
   and q.customer_id is not null;

-- Customer summary fields used by the current frontend.
alter table if exists public.crm_customers
  add column if not exists last_quote_id uuid,
  add column if not exists last_quote_value numeric(14,2);

-- Backfill safely now that customer_id exists.
with latest_quote as (
  select distinct on (q.customer_id)
         q.customer_id,
         q.id as quote_id,
         q.total_with_tax as quote_value
    from public.crm_quotes q
   where q.customer_id is not null
   order by q.customer_id, q.created_at desc nulls last, q.id desc
)
update public.crm_customers c
   set last_quote_id = coalesce(c.last_quote_id, l.quote_id),
       last_quote_value = coalesce(c.last_quote_value, l.quote_value)
  from latest_quote l
 where c.id = l.customer_id
   and (c.last_quote_id is null or c.last_quote_value is null);

create index if not exists crm_quotes_customer_id_idx
  on public.crm_quotes(customer_id);
create index if not exists crm_quotes_customer_created_idx
  on public.crm_quotes(customer_id, created_at desc);
create index if not exists crm_quote_versions_quote_id_idx
  on public.crm_quote_versions(quote_id);
create index if not exists crm_quote_versions_customer_id_idx
  on public.crm_quote_versions(customer_id);
create index if not exists crm_customers_last_quote_id_idx
  on public.crm_customers(last_quote_id);

-- Add foreign keys only when they are safe for the existing data.
do $$
begin
  if to_regclass('public.crm_quotes') is not null
     and not exists (
       select 1 from pg_constraint
       where conrelid='public.crm_quotes'::regclass
         and conname='crm_quotes_customer_id_fkey'
     )
     and not exists (
       select 1 from public.crm_quotes q
       where q.customer_id is not null
         and not exists (select 1 from public.crm_customers c where c.id=q.customer_id)
     ) then
    alter table public.crm_quotes
      add constraint crm_quotes_customer_id_fkey
      foreign key (customer_id) references public.crm_customers(id)
      on delete cascade;
  end if;

  if to_regclass('public.crm_quote_versions') is not null
     and not exists (
       select 1 from pg_constraint
       where conrelid='public.crm_quote_versions'::regclass
         and conname='crm_quote_versions_quote_id_fkey'
     )
     and not exists (
       select 1 from public.crm_quote_versions v
       where v.quote_id is not null
         and not exists (select 1 from public.crm_quotes q where q.id=v.quote_id)
     ) then
    alter table public.crm_quote_versions
      add constraint crm_quote_versions_quote_id_fkey
      foreign key (quote_id) references public.crm_quotes(id)
      on delete cascade;
  end if;

  if not exists (
       select 1 from pg_constraint
       where conrelid='public.crm_customers'::regclass
         and conname='crm_customers_last_quote_id_fkey'
     )
     and not exists (
       select 1 from public.crm_customers c
       where c.last_quote_id is not null
         and not exists (select 1 from public.crm_quotes q where q.id=c.last_quote_id)
     ) then
    alter table public.crm_customers
      add constraint crm_customers_last_quote_id_fkey
      foreign key (last_quote_id) references public.crm_quotes(id)
      on delete set null;
  end if;
end $$;

commit;
notify pgrst, 'reload schema';
