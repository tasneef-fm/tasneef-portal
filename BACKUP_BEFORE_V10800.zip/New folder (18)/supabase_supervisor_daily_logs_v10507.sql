-- Tasneef V10507: reliable supervisor project check-in for daily administration logs
-- Safe migration: keeps all historical records and only closes duplicate open rows.

begin;

-- Normalize malformed/missing log dates from check-in time.
update public.time_logs
set log_date = ((check_in at time zone 'Asia/Riyadh')::date)
where check_in is not null
  and (log_date is null or log_date::text !~ '^\\d{4}-\\d{2}-\\d{2}$');

-- Keep the newest open row and close older duplicate open rows.
with ranked as (
  select id, check_in,
         row_number() over (
           partition by supervisor_id, project_id
           order by check_in desc nulls last, id desc
         ) as rn
  from public.time_logs
  where check_out is null
    and supervisor_id is not null
    and project_id is not null
)
update public.time_logs t
set check_out = coalesce(r.check_in, now()),
    duration_minutes = 0,
    time_status = 'duplicate_closed',
    updated_at = now()
from ranked r
where t.id = r.id and r.rn > 1;

create unique index if not exists ux_time_logs_one_open_supervisor_project
on public.time_logs(supervisor_id, project_id)
where check_out is null;

create index if not exists ix_time_logs_log_date_checkin
on public.time_logs(log_date, check_in desc);

create or replace function public.tasneef_supervisor_project_checkin_v10507(
  p_supervisor_id bigint,
  p_project_id bigint,
  p_check_in timestamptz default now(),
  p_log_date date default null,
  p_visit_type text default 'surface',
  p_travel_minutes integer default 0,
  p_required_minutes integer default 0,
  p_notes text default null
)
returns setof public.time_logs
language plpgsql
security definer
set search_path = public
as $$
declare
  v_row public.time_logs%rowtype;
  v_date date := coalesce(p_log_date, (p_check_in at time zone 'Asia/Riyadh')::date);
begin
  if p_supervisor_id is null or p_supervisor_id <= 0 then
    raise exception 'Invalid supervisor id';
  end if;
  if p_project_id is null or p_project_id <= 0 then
    raise exception 'Invalid project id';
  end if;

  select * into v_row
  from public.time_logs
  where supervisor_id = p_supervisor_id
    and project_id = p_project_id
    and check_out is null
  order by check_in desc, id desc
  limit 1;

  if found then
    return next v_row;
    return;
  end if;

  insert into public.time_logs(
    user_id, supervisor_id, project_id, check_in, check_out, log_date,
    duration_minutes, travel_minutes, visit_type, required_minutes,
    time_difference_minutes, time_status, notes
  ) values (
    p_supervisor_id, p_supervisor_id, p_project_id, p_check_in, null, v_date,
    0, coalesce(p_travel_minutes,0), coalesce(p_visit_type,'surface'),
    coalesce(p_required_minutes,0), -coalesce(p_required_minutes,0),
    'open', coalesce(p_notes,'تسجيل دخول المشروع من صفحة المشرف')
  ) returning * into v_row;

  return next v_row;
exception
  when unique_violation then
    select * into v_row
    from public.time_logs
    where supervisor_id = p_supervisor_id
      and project_id = p_project_id
      and check_out is null
    order by check_in desc, id desc
    limit 1;
    return next v_row;
end;
$$;

grant execute on function public.tasneef_supervisor_project_checkin_v10507(bigint,bigint,timestamptz,date,text,integer,integer,text) to anon, authenticated;

commit;
