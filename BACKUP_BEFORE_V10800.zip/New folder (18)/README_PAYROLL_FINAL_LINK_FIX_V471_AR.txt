إصلاح الربط النهائي للرواتب V471

الملفات المعدلة:
- tasneef_salaries_unified_source_v440.js
- admin.html

التغييرات:
1. توحيد جميع معرفات employee_id وworker_id والمعرفات المرتبطة إلى canonical_employee_id واحد قبل إنشاء صفوف الرواتب.
2. استخدام تجميع Union-Find لدمج سجلات الموظف المتفرقة بين employees_master_v386 وemployees وworkers وapp_users دون الاعتماد على الاسم أو الإقامة.
3. الاحتفاظ بجميع aliases الخاصة بالموظف بعد الدمج حتى ترتبط به التوزيعات والحضور والتسجيلات من كل الجداول.
4. إزالة تكرار التوزيعات المتطابقة قبل الحساب.
5. إزالة تكرار الحضور حسب الموظف والتاريخ والفترة ووقت الدخول والخروج، ودمج الساعات داخل صف الموظف الواحد.
6. اختيار المشرف الأساسي حسب عدد الأيام الفريدة خلال الشهر، مع كسر التعادل بأحدث توزيع، وإظهار حالة تعدد المشرفين في التفاصيل.
7. إنشاء الصفوف النهائية بعد اكتمال الدمج فقط، مع تحقق أن عدد الصفوف النهائية يساوي عدد معرفات الموظفين الفريدة.
8. إضافة تشخيص duplicateProfileIds وduplicateRowIds وsupervisorCoverage وmissingWorkersBySupervisor.
9. تحديث كاش ملف الرواتب إلى v=471.

يمكن فتح Console ثم قراءة:
window.__tasneefPayrollDiagnostics

الحقول المهمة:
- rawSourceRecords
- canonicalEmployeeProfiles
- uniqueEmployeeIds
- finalPayrollRows
- duplicateProfileIds
- duplicateRowIds
- supervisorCoverage
- missingWorkersBySupervisor
