-- Tasneef CRM V10604
-- إصلاح جذري لتوافق جدول crm_tasks مع الواجهة الحالية وإعادة تحميل مخطط PostgREST.
-- نفّذ هذا الملف مرة واحدة في Supabase SQL Editor.

begin;

-- الجدول قد يكون موجوداً من نسخة قديمة بحقل opportunity_id فقط.
create table if not exists public.crm_tasks (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid,
  title text not null,
  task_type text,
  assigned_to uuid,
  assigned_to_name text,
  due_date date,
  due_time time,
  priority text default 'عادية',
  status text default 'new',
  description text,
  created_at timestamptz default now(),
  completed_at timestamptz,
  cancelled_at timestamptz
);

alter table public.crm_tasks add column if not exists customer_id uuid;
alter table public.crm_tasks add column if not exists title text;
alter table public.crm_tasks add column if not exists task_type text;
alter table public.crm_tasks add column if not exists assigned_to uuid;
alter table public.crm_tasks add column if not exists assigned_to_name text;
alter table public.crm_tasks add column if not exists due_date date;
alter table public.crm_tasks add column if not exists due_time time;
alter table public.crm_tasks add column if not exists priority text default 'عادية';
alter table public.crm_tasks add column if not exists status text default 'new';
alter table public.crm_tasks add column if not exists description text;
alter table public.crm_tasks add column if not exists created_at timestamptz default now();
alter table public.crm_tasks add column if not exists completed_at timestamptz;
alter table public.crm_tasks add column if not exists cancelled_at timestamptz;

-- نقل الربط من بنية CRM القديمة إذا كان opportunity_id موجوداً.
do $$
begin
  if exists (
    select 1
    from information_schema.columns
    where table_schema='public' and table_name='crm_tasks' and column_name='opportunity_id'
  ) then
    execute $q$
      update public.crm_tasks
      set customer_id = opportunity_id::text::uuid
      where customer_id is null
        and opportunity_id is not null
        and opportunity_id::text ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'
    $q$;
  end if;
end $$;

-- إضافة المفتاح الخارجي دون تعطيل التنفيذ إذا كانت بيانات قديمة غير متوافقة.
do $$
begin
  if to_regclass('public.crm_customers') is not null
     and not exists (
       select 1 from pg_constraint
       where conrelid='public.crm_tasks'::regclass
         and conname='crm_tasks_customer_id_fkey'
     ) then
    begin
      alter table public.crm_tasks
        add constraint crm_tasks_customer_id_fkey
        foreign key (customer_id) references public.crm_customers(id)
        on delete cascade not valid;
    exception when others then
      raise notice 'تعذر إضافة FK الآن: %', sqlerrm;
    end;
  end if;
end $$;

create index if not exists crm_tasks_customer_id_idx on public.crm_tasks(customer_id);
create index if not exists crm_tasks_due_date_idx on public.crm_tasks(due_date);
create index if not exists crm_tasks_status_idx on public.crm_tasks(status);

-- صلاحيات النظام الحالي المبني على تسجيل دخول مخصص.
alter table public.crm_tasks enable row level security;
do $$
declare p record;
begin
  for p in
    select policyname from pg_policies
    where schemaname='public' and tablename='crm_tasks'
  loop
    execute format('drop policy if exists %I on public.crm_tasks', p.policyname);
  end loop;
end $$;
create policy tasneef_crm_tasks_current_system_access
on public.crm_tasks for all to anon, authenticated
using (true) with check (true);
grant select, insert, update, delete on public.crm_tasks to anon, authenticated;

commit;

-- إجبار PostgREST على تحديث schema cache فوراً.
notify pgrst, 'reload schema';

-- تحقق نهائي: يجب أن يظهر customer_id في النتيجة.
select column_name, data_type, is_nullable
from information_schema.columns
where table_schema='public' and table_name='crm_tasks'
order by ordinal_position;
