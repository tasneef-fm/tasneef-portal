-- V453 - إضافة بداية ونهاية المشروع + دعم منع التكرار بدون حذف بيانات
alter table if exists public.projects add column if not exists project_start_date date;
alter table if exists public.projects add column if not exists project_end_date date;

-- فهارس مساعدة للتوزيع والبحث السريع
create index if not exists idx_projects_status_v453 on public.projects(status);
create index if not exists idx_projects_dates_v453 on public.projects(project_start_date, project_end_date);
create index if not exists idx_monthly_distribution_unique_lookup_v453 on public.monthly_distribution(month_key, project_id, worker_employee_code);

-- لا يوجد DELETE أو DROP. البيانات القديمة تبقى كما هي.
