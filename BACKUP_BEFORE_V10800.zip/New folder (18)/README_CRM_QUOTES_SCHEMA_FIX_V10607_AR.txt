إصلاح CRM V10607

سبب الخطأ:
كان جدول crm_quotes من نسخة قديمة ولا يحتوي على customer_id، بينما ملف V10606 حاول قراءة q.customer_id قبل إضافته.

التنفيذ:
شغّل فقط الملف:
supabase_crm_quotes_schema_fix_v10607.sql

الإصلاح يضيف حقول عروض السعر الناقصة، يربط النسخ القديمة عبر opportunity_id عند توفره، ثم يحدّث last_quote_id وlast_quote_value بأمان، ويعيد تحميل Schema Cache.
