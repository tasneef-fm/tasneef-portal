تقرير إصلاح الرواتب V464 — نفس النسخة المعتمدة

أسباب المشكلات التي عولجت:
1) تكرار الموظف: مصدر الموظفين كان يختار جدولًا واحدًا ثم يبني الصفوف من سجلات التوزيع/الحضور بمعرفات بديلة. تم دمج مصادر الموظفين وتوحيد aliases ثم إنشاء سجل واحد لكل معرف موظف أساسي.
2) المشرف الخاطئ: كان اختيار المشرف يعتمد على عدد سجلات التوزيع، لا عدد الأيام. أصبح الاختيار للمشرف صاحب أكبر مدة متقاطعة مع فترة الشهر.
3) اختفاء المشرفين والفنيين والحراس: كان المصدر الأساسي workers فقط، وكان وجود توزيع عمليًا سبب الظهور. أضيف دمج workers وemployees وemployees_master_v386 وsalary_employee_profiles وapp_users، مع تصنيف المسمى الفعلي وإظهار الفئات غير المرتبطة بتوزيع.
4) المعرفات التقنية داخل الخانات: أضيف فلتر human يمنع UUID/JWT/JSON ورسائل SQL وDebug من الظهور، ولا يعرض project_id كاسم مشروع.
5) مكان العمل: أصبح الربط project_id -> projects.id -> project name، والزيارة اليومية تعرض اسم المشرف، والفني يعرض فريق الصيانة عند عدم وجود موقع.
6) أيام يوليو: نهاية الشهر تحسب برمجيًا، ويوليو 2026 ينتهي في 2026-07-31.
7) التعديل: أضيف زر تعديل لكل صف مع سبب إلزامي، وإعادة احتساب بعد الحفظ، ومحاولة تسجيل القيمة السابقة والجديدة في payroll_audit_logs.

مصادر البيانات التي تتم تجربتها:
- الموظفون: workers, employees, employees_master_v386, salary_employee_profiles, app_users
- المشاريع: projects
- المشرفون: app_users, users
- التوزيعات: worker_project_assignments, monthly_distribution, monthly_distribution_view
- الحضور: attendance
- التسجيلات: daily_records, daily_registrations, time_logs
- الرواتب المحفوظة: monthly_salaries
- التعديلات: payroll_adjustments, worker_borrowings

الدوال المعدلة:
- consolidateEmployees
- employeeCategory
- getUnifiedPayrollData
- mainSupervisor
- calcLocation
- buildEntry
- groupRows
- rowHtml
- edit / saveEdit

التشخيص:
window.__tasneefPayrollDiagnostics
ويشمل allEmployees, uniqueEmployees, workers, guards, supervisors, technicians, operations, assignments, uniqueEmployeeIds, finalPayrollRows, duplicateRowsRemoved, attendanceRecords.

الاختبارات المحلية:
- فحص تركيب JavaScript بواسطة node --check: ناجح.
- التحقق من كاش admin.html: v=464.
- لا يمكن إعطاء عدد موظفي يوليو الفعلي أو تأكيد أسماء المشرفين من قاعدة Supabase دون تشغيل النسخة على قاعدة النظام الحية. الأعداد تظهر بعد الرفع في Console ضمن التشخيص.
