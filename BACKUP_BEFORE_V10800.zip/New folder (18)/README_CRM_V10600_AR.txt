قسم CRM الموحد V10600
1) شغّل ملف supabase_crm_unified_v10600.sql مرة واحدة في Supabase SQL Editor.
2) ارفع جميع ملفات هذه النسخة كما هي، ولا تخلطها مع نسخة أقدم.
3) افتح لوحة الإدارة ثم اختر CRM المبيعات.
4) الوحدة مرتبطة مباشرة بجدول projects عند التحويل للتشغيل وتمنع التحويل المكرر عبر operation_project_id وcrm_operation_handover.
5) لا توجد نسخة CRM قديمة داخل الحزمة؛ الملف canonical الوحيد هو tasneef_crm_unified_v10600.js.
