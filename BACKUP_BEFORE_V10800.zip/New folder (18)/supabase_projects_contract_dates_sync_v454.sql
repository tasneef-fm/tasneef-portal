-- V454 إصلاح تواريخ العقود والمشاريع بدون حذف أي بيانات
alter table public.projects add column if not exists project_start_date date;
alter table public.projects add column if not exists project_end_date date;
alter table public.projects add column if not exists contract_start date;
alter table public.projects add column if not exists contract_end date;
alter table public.projects add column if not exists start_date date;
alter table public.projects add column if not exists end_date date;

-- توحيد الحقول: إذا عدلت التاريخ من النظام الموحد يأخذ الأولوية، وإلا نستخدم القديم.
update public.projects
set
  contract_start = coalesce(project_start_date, contract_start, start_date),
  contract_end   = coalesce(project_end_date, contract_end, end_date),
  project_start_date = coalesce(project_start_date, contract_start, start_date),
  project_end_date   = coalesce(project_end_date, contract_end, end_date),
  start_date = coalesce(start_date, project_start_date, contract_start),
  end_date   = coalesce(end_date, project_end_date, contract_end)
where true;

create index if not exists idx_projects_contract_end_v454 on public.projects(contract_end);
create index if not exists idx_projects_project_end_v454 on public.projects(project_end_date);
