-- V458: مزامنة حالات العامل/المشرف/المشروع ودعم النقل الذكي بدون حذف بيانات
alter table if exists public.projects add column if not exists is_active boolean;
alter table if exists public.projects add column if not exists active boolean;
alter table if exists public.projects add column if not exists state text;
alter table if exists public.projects add column if not exists status text;

alter table if exists public.workers add column if not exists employee_code text;
alter table if exists public.workers add column if not exists status text;
alter table if exists public.workers add column if not exists state text;
alter table if exists public.workers add column if not exists is_active boolean;
alter table if exists public.workers add column if not exists active boolean;

alter table if exists public.employees_master_v386 add column if not exists employee_code text;
alter table if exists public.employees_master_v386 add column if not exists status text;
alter table if exists public.employees_master_v386 add column if not exists state text;
alter table if exists public.employees_master_v386 add column if not exists is_active boolean;
alter table if exists public.employees_master_v386 add column if not exists active boolean;

alter table if exists public.monthly_distribution add column if not exists status text;
alter table if exists public.monthly_distribution add column if not exists supervisor_employee_code text;
alter table if exists public.monthly_distribution add column if not exists supervisor_name text;
alter table if exists public.monthly_distribution add column if not exists worker_employee_code text;
alter table if exists public.monthly_distribution add column if not exists worker_name text;
alter table if exists public.monthly_distribution add column if not exists updated_at timestamptz;

create index if not exists idx_projects_active_status_v458 on public.projects(status,state,is_active,active);
create index if not exists idx_workers_employee_code_v458 on public.workers(employee_code);
create index if not exists idx_workers_status_v458 on public.workers(status,state,is_active,active);
create index if not exists idx_employees_master_code_v458 on public.employees_master_v386(employee_code);
create index if not exists idx_employees_master_status_v458 on public.employees_master_v386(status,state,is_active,active);
create index if not exists idx_monthly_distribution_sup_v458 on public.monthly_distribution(supervisor_employee_code, month_key);
create index if not exists idx_monthly_distribution_worker_v458 on public.monthly_distribution(worker_employee_code, month_key);
