نسخة V10610

تم إصلاح خطأ customer_name دون الحاجة لإضافة أعمدة جديدة في Supabase.
اسم العميل يُحفظ في contact_person ورقم الهاتف في mobile، وهي الأعمدة الأصلية الموجودة.
تم حذف الاعتماد على customer_name وcustomer_phone وstatus_changed_by وcreated_by في المهام.
بقية أقسام النظام لم يتم تعديلها.
