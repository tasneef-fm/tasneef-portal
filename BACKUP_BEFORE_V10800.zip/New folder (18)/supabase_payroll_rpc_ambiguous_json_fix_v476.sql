-- V476 hotfix: qualify JSON payload aliases in joined CTEs; fixes column reference "j" is ambiguous
-- V474: مصدر الرواتب الوحيد من السيرفر. لا دمج أو fallback داخل الواجهة.
create or replace function public.get_unified_payroll_from_server(p_month text)
returns jsonb
language plpgsql
security invoker
set search_path = public
as $$
#variable_conflict use_column
declare
  v_start date;
  v_end date;
  v_result jsonb;
  v_duplicates integer;
begin
  if p_month is null or p_month !~ '^\d{4}-\d{2}$' then
    raise exception 'Invalid payroll month: %', p_month;
  end if;

  v_start := (p_month || '-01')::date;
  v_end := (v_start + interval '1 month - 1 day')::date;

  with
  employee_source as (
    select to_jsonb(e) as j
    from public.employees_master_v386 e
  ),
  employees_all as (
    select
      coalesce(nullif(j->>'employee_id',''), nullif(j->>'worker_id',''), nullif(j->>'staff_id',''), nullif(j->>'person_id',''), nullif(j->>'id','')) as canonical_employee_id,
      array_remove(array[
        nullif(j->>'id',''), nullif(j->>'employee_id',''), nullif(j->>'worker_id',''), nullif(j->>'staff_id',''), nullif(j->>'person_id',''),
        nullif(j->>'employee_code',''), nullif(j->>'worker_code',''), nullif(j->>'employee_ts_id',''), nullif(j->>'code','')
      ], null) as aliases,
      j
    from employee_source
  ),
  employees as (
    select *
    from employees_all
    where canonical_employee_id is not null
      and coalesce(lower(j->>'is_active'),'false') = 'true'
      and coalesce(lower(j->>'status'),'active') not in ('inactive','stopped','terminated','disabled','موقوف','متوقف','منتهي')
      and coalesce(lower(j->>'is_deleted'),'false') <> 'true'
  ),
  stopped_employees as (
    select count(*)::int n from employees_all
    where canonical_employee_id is not null
      and not (
        coalesce(lower(j->>'is_active'),'false') = 'true'
        and coalesce(lower(j->>'status'),'active') not in ('inactive','stopped','terminated','disabled','موقوف','متوقف','منتهي')
      )
  ),
  project_source as (
    select to_jsonb(p) j from public.projects p
  ),
  projects as (
    select
      coalesce(nullif(j->>'id',''),nullif(j->>'project_id','')) project_id,
      coalesce(nullif(j->>'name',''),nullif(j->>'project_name',''),nullif(j->>'title',''),'مشروع') project_name,
      coalesce(nullif(j->>'operation_type',''),nullif(j->>'project_type',''),'') operation_type,
      coalesce(nullif(j->>'required_daily_minutes','')::numeric,540) required_daily_minutes,
      coalesce(nullif(j->>'friday_minutes','')::numeric,0) friday_minutes,
      j
    from project_source
    where coalesce(lower(j->>'is_active'),'false')='true'
      and coalesce(lower(j->>'status'),'active') not in ('inactive','stopped','terminated','disabled','موقوف','متوقف','منتهي')
  ),
  distribution_source as (
    select to_jsonb(d) j from public.monthly_distribution d
  ),
  assignments_raw as (
    select
      coalesce(nullif(j->>'worker_employee_code',''),nullif(j->>'employee_id',''),nullif(j->>'worker_id',''),nullif(j->>'staff_id',''),nullif(j->>'person_id','')) worker_ref,
      coalesce(nullif(j->>'supervisor_employee_code',''),nullif(j->>'supervisor_id','')) supervisor_ref,
      coalesce(nullif(j->>'project_id',''),nullif(j->>'project_code','')) project_ref,
      greatest(coalesce(nullif(j->>'start_date','')::date,v_start),v_start) assignment_start,
      least(coalesce(nullif(j->>'end_date','')::date,v_end),v_end) assignment_end,
      j
    from distribution_source
    where (
      j->>'month_key' = p_month
      or (
        coalesce(nullif(j->>'start_date','')::date,v_start) <= v_end
        and coalesce(nullif(j->>'end_date','')::date,v_end) >= v_start
      )
    )
      and coalesce(lower(j->>'status'),'active') not in ('deleted','cancelled','ملغي','محذوف')
  ),
  assignments_linked as (
    select distinct on (e.canonical_employee_id, ar.project_ref, ar.supervisor_ref, ar.assignment_start, ar.assignment_end)
      e.canonical_employee_id,
      ar.supervisor_ref,
      ar.project_ref,
      ar.assignment_start,
      ar.assignment_end,
      greatest((ar.assignment_end-ar.assignment_start)+1,0)::int overlap_days,
      ar.j
    from assignments_raw ar
    join employees e on ar.worker_ref = any(e.aliases)
    where ar.assignment_start <= ar.assignment_end
    order by e.canonical_employee_id, ar.project_ref, ar.supervisor_ref, ar.assignment_start, ar.assignment_end
  ),
  supervisors as (
    select
      canonical_employee_id supervisor_id,
      coalesce(nullif(j->>'app_name',''),nullif(j->>'display_name',''),nullif(j->>'name',''),nullif(j->>'full_name',''),nullif(j->>'employee_name',''),'مشرف') supervisor_name,
      aliases,
      j
    from employees
    where lower(coalesce(j->>'job_title',j->>'position',j->>'role',j->>'employee_type','')) like '%مشرف%'
       or lower(coalesce(j->>'job_title',j->>'position',j->>'role',j->>'employee_type','')) like '%supervisor%'
  ),
  stopped_supervisor_refs as (
    select count(*)::int n
    from assignments_linked a
    where a.supervisor_ref is not null
      and not exists(select 1 from supervisors s where a.supervisor_ref=any(s.aliases))
  ),
  assignments_enriched as (
    select
      a.canonical_employee_id,
      s.supervisor_id,
      s.supervisor_name,
      p.project_id,
      p.project_name,
      p.operation_type,
      p.required_daily_minutes,
      p.friday_minutes,
      a.assignment_start,
      a.assignment_end,
      a.overlap_days
    from assignments_linked a
    left join supervisors s on a.supervisor_ref=any(s.aliases)
    left join projects p on a.project_ref=p.project_id
    where a.project_ref is null or p.project_id is not null
  ),
  supervisor_days as (
    select ae.canonical_employee_id, ae.supervisor_id, max(ae.supervisor_name) as supervisor_name,
           sum(ae.overlap_days)::int as supervisor_days, max(ae.assignment_start) as latest_start
    from assignments_enriched ae
    where ae.supervisor_id is not null
    group by ae.canonical_employee_id, ae.supervisor_id
  ),
  primary_supervisor as (
    select ranked.canonical_employee_id, ranked.supervisor_id, ranked.supervisor_name, ranked.supervisor_days
    from (
      select sd.*, row_number() over(partition by canonical_employee_id order by supervisor_days desc, latest_start desc, supervisor_id) rn
      from supervisor_days sd
    ) ranked where ranked.rn=1
  ),
  attendance_source as (
    select to_jsonb(a) j from public.attendance a
  ),
  attendance_raw as (
    select
      coalesce(nullif(j->>'employee_id',''),nullif(j->>'worker_id',''),nullif(j->>'staff_id',''),nullif(j->>'person_id',''),nullif(j->>'user_id','')) employee_ref,
      coalesce(nullif(j->>'attendance_date','')::date,nullif(j->>'date','')::date,(nullif(j->>'created_at',''))::timestamptz::date) attendance_date,
      coalesce(nullif(j->>'check_in',''),nullif(j->>'in_time',''),nullif(j->>'start_time',''),nullif(j->>'login_time','')) check_in,
      coalesce(nullif(j->>'check_out',''),nullif(j->>'out_time',''),nullif(j->>'end_time',''),nullif(j->>'logout_time','')) check_out,
      j
    from attendance_source
  ),
  attendance_linked as (
    select e.canonical_employee_id, ar.attendance_date,
           min(ar.check_in) check_in, max(ar.check_out) check_out
    from attendance_raw ar
    join employees e on ar.employee_ref=any(e.aliases)
    where ar.attendance_date between v_start and v_end
      and ar.check_in is not null
      and coalesce(lower(ar.j->>'status'),'present') not in ('cancelled','rejected','failed','ملغي','مرفوض','غير معتمد')
      and coalesce(lower(ar.j->>'is_cancelled'),'false') <> 'true'
      and coalesce(lower(ar.j->>'is_deleted'),'false') <> 'true'
      and coalesce(lower(ar.j->>'is_approved'),'true') = 'true'
    group by e.canonical_employee_id, ar.attendance_date
  ),
  attendance_agg as (
    select al.canonical_employee_id, min(al.attendance_date) as first_attendance_date,
           count(*)::int as present_days,
           jsonb_agg(jsonb_build_object('date',al.attendance_date,'check_in',al.check_in,'check_out',al.check_out) order by al.attendance_date) as attendance_days
    from attendance_linked al group by al.canonical_employee_id
  ),
  service_dates as (
    select e.canonical_employee_id,
      greatest(v_start,
        coalesce(nullif(e.j->>'work_start_date','')::date,nullif(e.j->>'hire_date','')::date,nullif(e.j->>'joining_date','')::date,v_start),
        coalesce((select min(a.assignment_start) from assignments_enriched a where a.canonical_employee_id=e.canonical_employee_id),v_start),
        coalesce(at.first_attendance_date,v_start)
      ) service_start,
      least(v_end,coalesce(nullif(e.j->>'work_end_date','')::date,nullif(e.j->>'termination_date','')::date,nullif(e.j->>'stop_date','')::date,v_end)) service_end
    from employees e left join attendance_agg at using(canonical_employee_id)
  ),
  required_calendar as (
    select sd.canonical_employee_id, g.d::date work_date,
      case
        when extract(isodow from g.d)=5 then coalesce((
          select max(a.friday_minutes) from assignments_enriched a
          where a.canonical_employee_id=sd.canonical_employee_id and g.d::date between a.assignment_start and a.assignment_end
        ),0)
        else coalesce((
          select max(a.required_daily_minutes) from assignments_enriched a
          where a.canonical_employee_id=sd.canonical_employee_id and g.d::date between a.assignment_start and a.assignment_end
        ),540)
      end required_minutes
    from service_dates sd
    cross join lateral generate_series(sd.service_start,sd.service_end,interval '1 day') g(d)
    where sd.service_start<=sd.service_end
  ),
  required_agg as (
    select rc.canonical_employee_id,
      count(*) filter(where rc.required_minutes>0)::int as required_work_days,
      coalesce(sum(rc.required_minutes),0)::numeric as required_minutes
    from required_calendar rc group by rc.canonical_employee_id
  ),
  adjustment_source as (
    select to_jsonb(pa) j from public.payroll_adjustments pa
    where pa.effective_date between v_start and v_end and coalesce(pa.is_deleted,false)=false
  ),
  adjustments as (
    select e.canonical_employee_id,
      coalesce(sum((x.j->>'amount')::numeric) filter(where lower(x.j->>'adjustment_type') in ('allowance','بدل','بدلات')),0) allowances,
      coalesce(sum((x.j->>'amount')::numeric) filter(where lower(x.j->>'adjustment_type') in ('commission','bonus','حافز','عمولة')),0) commissions,
      coalesce(sum((x.j->>'amount')::numeric) filter(where lower(x.j->>'adjustment_type') in ('advance','سلفة')),0) advances,
      coalesce(sum((x.j->>'amount')::numeric) filter(where lower(x.j->>'adjustment_type') in ('deduction','خصم','جزاء')),0) deductions
    from adjustment_source x
    join employees e on coalesce(nullif(x.j->>'employee_id',''),nullif(x.j->>'worker_id',''))=any(e.aliases)
    where coalesce(lower(x.j->>'status'),'approved') in ('approved','معتمد')
    group by e.canonical_employee_id
  ),
  assignment_json as (
    select canonical_employee_id,
      jsonb_agg(jsonb_build_object(
        'project_id',project_id,'project_name',project_name,'supervisor_id',supervisor_id,'supervisor_name',supervisor_name,
        'start',assignment_start,'end',assignment_end,'days',overlap_days,'operation_type',operation_type
      ) order by assignment_start) assignment_details,
      array_agg(distinct project_id) filter(where project_id is not null) project_ids,
      array_agg(distinct project_name) filter(where project_name is not null) project_names,
      count(distinct supervisor_id) filter(where supervisor_id is not null)>1 multiple_supervisors
    from assignments_enriched group by canonical_employee_id
  ),
  payroll_rows as (
    select
      e.canonical_employee_id,
      e.canonical_employee_id worker_id,
      coalesce(nullif(e.j->>'employee_code',''),nullif(e.j->>'worker_code',''),nullif(e.j->>'employee_ts_id',''),nullif(e.j->>'code',''),e.canonical_employee_id) employee_code,
      p_month AS "month",
      coalesce(nullif(e.j->>'iqama_name',''),nullif(e.j->>'residency_name',''),nullif(e.j->>'official_name',''),nullif(e.j->>'full_name',''),nullif(e.j->>'name',''),'موظف') residency_name,
      coalesce(nullif(e.j->>'app_name',''),nullif(e.j->>'display_name',''),nullif(e.j->>'name',''),nullif(e.j->>'full_name',''),'موظف') worker_name,
      coalesce(nullif(e.j->>'iqama_number',''),nullif(e.j->>'residency_number',''),nullif(e.j->>'national_id',''),'') iqama_number,
      coalesce(nullif(e.j->>'job_title',''),nullif(e.j->>'position',''),nullif(e.j->>'employee_type',''),nullif(e.j->>'job_type',''),nullif(e.j->>'role',''),'عامل') job_title,
      ps.supervisor_id,
      coalesce(ps.supervisor_name,'دون مشرف نشط') supervisor_name,
      case
        when coalesce(array_length(aj.project_names,1),0)>1 then 'متعدد'
        when coalesce(array_length(aj.project_names,1),0)=1 then
          case when exists(select 1 from assignments_enriched ae where ae.canonical_employee_id=e.canonical_employee_id and lower(ae.operation_type) in ('daily_visit','زيارة يومية'))
               then coalesce(ps.supervisor_name,'دون مشرف نشط') else aj.project_names[1] end
        when lower(coalesce(e.j->>'job_title',e.j->>'position','')) like '%فني%' then 'فريق الصيانة'
        else 'دون توزيع'
      end work_location,
      coalesce(to_jsonb(aj.project_ids),'[]'::jsonb) project_ids,
      coalesce(to_jsonb(aj.project_names),'[]'::jsonb) project_names,
      coalesce(aj.assignment_details,'[]'::jsonb) assignment_details,
      coalesce(aj.multiple_supervisors,false) multiple_supervisors,
      sd.service_start,
      at.first_attendance_date,
      sd.service_end,
      (sd.service_end-sd.service_start+1)::int month_days,
      (sd.service_end-sd.service_start+1)::int work_days,
      coalesce(ra.required_work_days,0) required_work_days,
      coalesce(at.present_days,0) present_days,
      greatest(coalesce(ra.required_work_days,0)-coalesce(at.present_days,0),0)::int absent_days,
      (sd.service_end-sd.service_start+1)::int due_days,
      coalesce(ra.required_minutes,0) required_minutes,
      0::numeric actual_minutes,
      coalesce(nullif(e.j->>'basic_salary','')::numeric,nullif(e.j->>'base_salary','')::numeric,nullif(e.j->>'salary','')::numeric,0) base_salary,
      coalesce(nullif(e.j->>'allowances','')::numeric,nullif(e.j->>'allowance','')::numeric,0)+coalesce(ad.allowances,0) allowances,
      coalesce(ad.commissions,0) commissions,
      coalesce(ad.advances,0) advances,
      coalesce(ad.deductions,0) other_deductions,
      0::numeric rounding,
      coalesce(at.attendance_days,'[]'::jsonb) details
    from employees e
    left join primary_supervisor ps using(canonical_employee_id)
    left join assignment_json aj using(canonical_employee_id)
    left join attendance_agg at using(canonical_employee_id)
    left join service_dates sd using(canonical_employee_id)
    left join required_agg ra using(canonical_employee_id)
    left join adjustments ad using(canonical_employee_id)
  ),
  final_rows as (
    select pr.*,
      (pr.base_salary+pr.allowances) gross_salary,
      ((pr.base_salary+pr.allowances)/30.0*pr.due_days) period_salary,
      case when pr.first_attendance_date is null then 0 else (pr.base_salary/30.0*pr.absent_days) end absence_deduction,
      (pr.other_deductions + case when pr.first_attendance_date is null then 0 else (pr.base_salary/30.0*pr.absent_days) end) deductions,
      (((pr.base_salary+pr.allowances)/30.0*pr.due_days)+pr.commissions+pr.rounding-pr.other_deductions-pr.advances-
        case when pr.first_attendance_date is null then 0 else (pr.base_salary/30.0*pr.absent_days) end) net_salary,
      case when pr.first_attendance_date is null then 'يحتاج مراجعة' when pr.base_salary=0 then 'يحتاج مراجعة' else 'مسودة' end status,
      case when pr.first_attendance_date is null then jsonb_build_array('الحضور غير مكتمل')
           when pr.base_salary=0 then jsonb_build_array('الراتب الأساسي غير مسجل') else '[]'::jsonb end issues,
      ''::text notes
    from payroll_rows pr
  ),
  duplicate_check as (
    select fr.canonical_employee_id,count(*) as n from final_rows fr group by fr.canonical_employee_id having count(*)>1
  ),
  supervisor_counts as (
    select coalesce(fr.supervisor_id,'none') as supervisor_id, max(fr.supervisor_name) as supervisor_name,
           count(distinct fr.canonical_employee_id)::int as payroll_workers
    from final_rows fr group by coalesce(fr.supervisor_id,'none')
  ),
  diagnostics as (
    select jsonb_build_object(
      'period_start',v_start,'period_end',v_end,
      'raw_employee_records',(select count(*) from employee_source),
      'raw_assignments',(select count(*) from assignments_raw),
      'raw_attendance_records',(select count(*) from attendance_raw ar_diag where ar_diag.attendance_date between v_start and v_end),
      'canonical_employee_ids',(select count(*) from employees),
      'duplicate_ids_found',(select count(*) from duplicate_check),
      'stopped_employees_removed',(select se.n from stopped_employees se),
      'stopped_supervisors_removed',(select ssr.n from stopped_supervisor_refs ssr),
      'final_payroll_rows',(select count(*) from final_rows),
      'supervisor_counts',coalesce((select jsonb_agg(to_jsonb(sc)) from supervisor_counts sc),'[]'::jsonb)
    ) j
  )
  select jsonb_build_object(
    'rows',coalesce((select jsonb_agg(to_jsonb(fr) order by fr.supervisor_name,fr.job_title,fr.employee_code) from final_rows fr),'[]'::jsonb),
    'projects',coalesce((select jsonb_agg(jsonb_build_object('id',pr.project_id,'name',pr.project_name,'operation_type',pr.operation_type)) from projects pr),'[]'::jsonb),
    'diagnostics',(select d.j from diagnostics d),
    'incomplete',false
  ) into v_result;

  v_duplicates := coalesce((v_result->'diagnostics'->>'duplicate_ids_found')::int,0);
  if v_duplicates <> 0 then
    raise exception 'Duplicate payroll employees detected';
  end if;
  if coalesce((v_result->'diagnostics'->>'final_payroll_rows')::int,0)
     <> coalesce((v_result->'diagnostics'->>'canonical_employee_ids')::int,0) then
    raise exception 'Payroll row count does not match canonical employees';
  end if;

  return v_result;
end;
$$;

grant execute on function public.get_unified_payroll_from_server(text) to anon, authenticated;
