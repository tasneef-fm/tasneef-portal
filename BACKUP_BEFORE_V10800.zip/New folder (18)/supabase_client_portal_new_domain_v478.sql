-- Tasneef V478: migrate all saved client portal links to the new GitHub Pages root
-- Run once in Supabase SQL Editor after GitHub Pages is enabled for tasneef-fm.github.io

UPDATE public.projects
SET client_portal_url = 'https://tasneef-fm.github.io/client-report.html?project_id=' || id::text,
    client_portal_short_url = NULL,
    client_portal_updated_at = now()
WHERE client_portal_url IS NULL
   OR client_portal_url LIKE '%welbadane1235-svg.github.io%'
   OR client_portal_url LIKE '%/tasneef-portal/%'
   OR client_portal_url NOT LIKE 'https://tasneef-fm.github.io/client-report.html%';
