-- V451 تسريع قسم الرواتب بدون حذف بيانات
CREATE INDEX IF NOT EXISTS idx_monthly_distribution_month_status_v451
ON public.monthly_distribution (month_key, status);

CREATE INDEX IF NOT EXISTS idx_monthly_distribution_worker_month_v451
ON public.monthly_distribution (worker_employee_code, month_key);

CREATE INDEX IF NOT EXISTS idx_monthly_distribution_supervisor_month_v451
ON public.monthly_distribution (supervisor_employee_code, month_key);

CREATE INDEX IF NOT EXISTS idx_attendance_date_worker_v451
ON public.attendance (attendance_date, worker_employee_code);

CREATE INDEX IF NOT EXISTS idx_monthly_salaries_month_entity_v451
ON public.monthly_salaries (salary_month, entity_type, entity_id);
