-- Tasneef V445 - Fix worker_borrowings RLS for browser app
-- يحل خطأ: new row violates row-level security policy for table "worker_borrowings"
-- آمن: لا يحذف أي بيانات.

CREATE TABLE IF NOT EXISTS public.worker_borrowings (
  id BIGSERIAL PRIMARY KEY,
  month_key TEXT NOT NULL,
  worker_employee_code TEXT NOT NULL,
  worker_name TEXT,
  worker_display_name TEXT,
  original_supervisor_employee_code TEXT,
  original_supervisor_name TEXT,
  borrowing_supervisor_employee_code TEXT NOT NULL,
  borrowing_supervisor_name TEXT,
  project_id TEXT,
  project_name TEXT,
  start_at TIMESTAMP WITHOUT TIME ZONE NOT NULL,
  end_at TIMESTAMP WITHOUT TIME ZONE NOT NULL,
  status TEXT DEFAULT 'active',
  notes TEXT,
  created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now()
);

ALTER TABLE public.worker_borrowings ADD COLUMN IF NOT EXISTS month_key TEXT;
ALTER TABLE public.worker_borrowings ADD COLUMN IF NOT EXISTS worker_employee_code TEXT;
ALTER TABLE public.worker_borrowings ADD COLUMN IF NOT EXISTS worker_name TEXT;
ALTER TABLE public.worker_borrowings ADD COLUMN IF NOT EXISTS worker_display_name TEXT;
ALTER TABLE public.worker_borrowings ADD COLUMN IF NOT EXISTS original_supervisor_employee_code TEXT;
ALTER TABLE public.worker_borrowings ADD COLUMN IF NOT EXISTS original_supervisor_name TEXT;
ALTER TABLE public.worker_borrowings ADD COLUMN IF NOT EXISTS borrowing_supervisor_employee_code TEXT;
ALTER TABLE public.worker_borrowings ADD COLUMN IF NOT EXISTS borrowing_supervisor_name TEXT;
ALTER TABLE public.worker_borrowings ADD COLUMN IF NOT EXISTS project_id TEXT;
ALTER TABLE public.worker_borrowings ADD COLUMN IF NOT EXISTS project_name TEXT;
ALTER TABLE public.worker_borrowings ADD COLUMN IF NOT EXISTS start_at TIMESTAMP WITHOUT TIME ZONE;
ALTER TABLE public.worker_borrowings ADD COLUMN IF NOT EXISTS end_at TIMESTAMP WITHOUT TIME ZONE;
ALTER TABLE public.worker_borrowings ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'active';
ALTER TABLE public.worker_borrowings ADD COLUMN IF NOT EXISTS notes TEXT;
ALTER TABLE public.worker_borrowings ADD COLUMN IF NOT EXISTS created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now();
ALTER TABLE public.worker_borrowings ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now();

CREATE INDEX IF NOT EXISTS idx_worker_borrowings_month ON public.worker_borrowings(month_key);
CREATE INDEX IF NOT EXISTS idx_worker_borrowings_worker ON public.worker_borrowings(worker_employee_code);
CREATE INDEX IF NOT EXISTS idx_worker_borrowings_time ON public.worker_borrowings(start_at, end_at);
CREATE INDEX IF NOT EXISTS idx_worker_borrowings_status ON public.worker_borrowings(status);

-- حل صلاحيات Supabase للواجهة الحالية التي تستخدم anon key.
-- نترك RLS مفعلة ونضيف سياسات واضحة بدل تعطيلها.
ALTER TABLE public.worker_borrowings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS worker_borrowings_select_anon ON public.worker_borrowings;
DROP POLICY IF EXISTS worker_borrowings_insert_anon ON public.worker_borrowings;
DROP POLICY IF EXISTS worker_borrowings_update_anon ON public.worker_borrowings;
DROP POLICY IF EXISTS worker_borrowings_delete_anon ON public.worker_borrowings;
DROP POLICY IF EXISTS worker_borrowings_select_authenticated ON public.worker_borrowings;
DROP POLICY IF EXISTS worker_borrowings_insert_authenticated ON public.worker_borrowings;
DROP POLICY IF EXISTS worker_borrowings_update_authenticated ON public.worker_borrowings;
DROP POLICY IF EXISTS worker_borrowings_delete_authenticated ON public.worker_borrowings;

CREATE POLICY worker_borrowings_select_anon
ON public.worker_borrowings
FOR SELECT
TO anon
USING (true);

CREATE POLICY worker_borrowings_insert_anon
ON public.worker_borrowings
FOR INSERT
TO anon
WITH CHECK (true);

CREATE POLICY worker_borrowings_update_anon
ON public.worker_borrowings
FOR UPDATE
TO anon
USING (true)
WITH CHECK (true);

CREATE POLICY worker_borrowings_delete_anon
ON public.worker_borrowings
FOR DELETE
TO anon
USING (true);

CREATE POLICY worker_borrowings_select_authenticated
ON public.worker_borrowings
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY worker_borrowings_insert_authenticated
ON public.worker_borrowings
FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY worker_borrowings_update_authenticated
ON public.worker_borrowings
FOR UPDATE
TO authenticated
USING (true)
WITH CHECK (true);

CREATE POLICY worker_borrowings_delete_authenticated
ON public.worker_borrowings
FOR DELETE
TO authenticated
USING (true);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.worker_borrowings TO anon, authenticated;
GRANT USAGE, SELECT ON SEQUENCE public.worker_borrowings_id_seq TO anon, authenticated;
