-- V450 إعادة بناء قسم الرواتب من الصفر بدون حذف أي بيانات
-- المصدر: monthly_distribution + employees_master_v386/workers + attendance

CREATE TABLE IF NOT EXISTS public.monthly_salaries (
  id BIGSERIAL PRIMARY KEY,
  salary_month DATE NOT NULL,
  entity_type TEXT NOT NULL DEFAULT 'unified_distribution_v450',
  entity_id BIGINT NOT NULL,
  employee_ts_id TEXT,
  employee_code TEXT,
  residency_name TEXT,
  iqama_no TEXT,
  employee_name TEXT,
  work_location TEXT,
  project_name TEXT,
  supervisor_name TEXT,
  job_title TEXT,
  start_date DATE,
  end_date DATE,
  work_days NUMERIC DEFAULT 0,
  absent_days NUMERIC DEFAULT 0,
  payable_days NUMERIC DEFAULT 0,
  basic_salary NUMERIC DEFAULT 0,
  allowance NUMERIC DEFAULT 0,
  gross_salary NUMERIC DEFAULT 0,
  salary_by_days NUMERIC DEFAULT 0,
  commission NUMERIC DEFAULT 0,
  deductions NUMERIC DEFAULT 0,
  rounding NUMERIC DEFAULT 0,
  advance_deduction NUMERIC DEFAULT 0,
  net_salary NUMERIC DEFAULT 0,
  notes TEXT,
  is_approved BOOLEAN DEFAULT FALSE,
  approved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS employee_ts_id TEXT;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS employee_code TEXT;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS residency_name TEXT;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS iqama_no TEXT;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS employee_name TEXT;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS work_location TEXT;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS project_name TEXT;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS supervisor_name TEXT;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS job_title TEXT;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS start_date DATE;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS end_date DATE;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS work_days NUMERIC DEFAULT 0;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS absent_days NUMERIC DEFAULT 0;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS payable_days NUMERIC DEFAULT 0;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS basic_salary NUMERIC DEFAULT 0;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS allowance NUMERIC DEFAULT 0;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS gross_salary NUMERIC DEFAULT 0;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS salary_by_days NUMERIC DEFAULT 0;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS commission NUMERIC DEFAULT 0;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS deductions NUMERIC DEFAULT 0;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS rounding NUMERIC DEFAULT 0;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS advance_deduction NUMERIC DEFAULT 0;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS net_salary NUMERIC DEFAULT 0;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS notes TEXT;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS is_approved BOOLEAN DEFAULT FALSE;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS approved_at TIMESTAMPTZ;
ALTER TABLE public.monthly_salaries ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT now();

CREATE UNIQUE INDEX IF NOT EXISTS ux_monthly_salaries_month_type_entity
ON public.monthly_salaries (salary_month, entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_monthly_salaries_month ON public.monthly_salaries (salary_month);
CREATE INDEX IF NOT EXISTS idx_monthly_salaries_employee_ts ON public.monthly_salaries (employee_ts_id);
CREATE INDEX IF NOT EXISTS idx_monthly_distribution_salary_month ON public.monthly_distribution (month_key);
CREATE INDEX IF NOT EXISTS idx_monthly_distribution_salary_worker ON public.monthly_distribution (worker_employee_code);
CREATE INDEX IF NOT EXISTS idx_monthly_distribution_salary_supervisor ON public.monthly_distribution (supervisor_employee_code);
CREATE INDEX IF NOT EXISTS idx_attendance_salary_date ON public.attendance (attendance_date);
