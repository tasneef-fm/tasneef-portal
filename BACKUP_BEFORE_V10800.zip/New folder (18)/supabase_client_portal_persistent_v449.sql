-- V449: تثبيت رابط العميل داخل جدول المشاريع حتى لا يختفي بعد التحديث أو تغيير الجهاز
ALTER TABLE public.projects
  ADD COLUMN IF NOT EXISTS client_portal_token text,
  ADD COLUMN IF NOT EXISTS client_portal_url text,
  ADD COLUMN IF NOT EXISTS client_portal_short_url text,
  ADD COLUMN IF NOT EXISTS client_portal_updated_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_projects_client_portal_token_v449
  ON public.projects (client_portal_token);

GRANT SELECT, UPDATE ON public.projects TO anon, authenticated;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname='public' AND tablename='projects' AND policyname='projects_client_portal_select_v449'
  ) THEN
    CREATE POLICY projects_client_portal_select_v449
    ON public.projects FOR SELECT
    TO anon, authenticated
    USING (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname='public' AND tablename='projects' AND policyname='projects_client_portal_update_v449'
  ) THEN
    CREATE POLICY projects_client_portal_update_v449
    ON public.projects FOR UPDATE
    TO anon, authenticated
    USING (true)
    WITH CHECK (true);
  END IF;
END $$;
