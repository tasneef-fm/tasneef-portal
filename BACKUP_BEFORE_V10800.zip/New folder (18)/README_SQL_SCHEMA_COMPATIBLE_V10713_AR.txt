تصحيح V10713 لخطأ SQL 42703

الخطأ السابق:
column x.supervisor_id does not exist

السبب:
جدول monthly_distribution في قاعدة البيانات الحالية لا يحتوي عمود supervisor_id فعليًا، بينما ملف V10712 كان يشير إليه مباشرة داخل الدالة والفهرس.

الإصلاح:
- الإبقاء على أسماء RPC المستخدمة في الواجهة كما هي: get_supervisor_workers_summary_v10712.
- قراءة هوية المشرف من صف التوزيع عبر to_jsonb، مع دعم supervisor_employee_code وsupervisor_name والحقول البديلة إذا كانت موجودة.
- عدم إنشاء فهرس supervisor_id إذا لم يكن العمود موجودًا.
- إنشاء الفهارس المتوافقة فقط بعد فحص information_schema.
- عدم حذف أو تعديل أي أوردر أو عامل أو توزيع أو حضور.

التشغيل:
شغّل الملف supabase_emergency_orders_workers_fix_v10713.sql كاملًا في Supabase SQL Editor.
بما أن المحاولة السابقة كانت داخل BEGIN/COMMIT وفشلت قبل COMMIT، أعد تشغيل الملف كاملًا من البداية.
