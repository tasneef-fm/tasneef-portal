-- V456 - توحيد حالة المشاريع بين النظام الموحد والعقود
-- آمن: لا يحذف بيانات، فقط يضيف أعمدة مفقودة ويوحد عرض الحالة.

ALTER TABLE public.projects ADD COLUMN IF NOT EXISTS state text;
ALTER TABLE public.projects ADD COLUMN IF NOT EXISTS is_active boolean;
ALTER TABLE public.projects ADD COLUMN IF NOT EXISTS active boolean;

-- املأ الحقول الفارغة فقط من الحالة الحالية
UPDATE public.projects
SET
  state = COALESCE(NULLIF(state,''), NULLIF(status,''), CASE WHEN COALESCE(is_active, active, true) THEN 'active' ELSE 'inactive' END),
  is_active = COALESCE(is_active, active, CASE WHEN lower(COALESCE(status,state,'')) IN ('inactive','stopped','disabled','deleted','archived') THEN false ELSE true END),
  active = COALESCE(active, is_active, CASE WHEN lower(COALESCE(status,state,'')) IN ('inactive','stopped','disabled','deleted','archived') THEN false ELSE true END)
WHERE state IS NULL OR state='' OR is_active IS NULL OR active IS NULL;

CREATE INDEX IF NOT EXISTS idx_projects_status_v456 ON public.projects(status);
CREATE INDEX IF NOT EXISTS idx_projects_state_v456 ON public.projects(state);
CREATE INDEX IF NOT EXISTS idx_projects_active_v456 ON public.projects(is_active);
