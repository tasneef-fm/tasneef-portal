إصلاح CRM V10606

السبب:
جدول crm_customers القديم لم يكن يحتوي على last_quote_id وlast_quote_value، بينما حفظ عرض السعر يحدّث هذين الحقلين.

التنفيذ:
1) نفّذ supabase_crm_quote_customer_schema_fix_v10606.sql فقط في Supabase SQL Editor.
2) ارفع admin.html وtasneef_crm_unified_v10600.js المحدثين.
3) نفّذ تحديثًا قويًا للصفحة، ثم جرّب إرسال عرض السعر.

الإصلاح يحافظ على البيانات السابقة ويستكمل آخر عرض لكل عميل عند توفره.
