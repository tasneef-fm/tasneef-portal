-- V465 حل جذري عام لنقل أي مشرف إلى مشرف بديل، مع نقل كل السجلات القديمة والجديدة والتكتات.
-- يشغّل مرة واحدة في Supabase.
-- بعده من الشاشة عند إيقاف أي مشرف تختار المشرف البديل ويتم النقل تلقائياً.
-- ملاحظة: لا يحذف أي بيانات؛ فقط يغير الربط من المشرف القديم إلى البديل ويوقف القديم.

create table if not exists public.supervisor_transfer_mappings (
  id bigserial primary key,
  old_code text,
  old_name text,
  old_user_id text,
  new_code text,
  new_name text,
  new_user_id text,
  transfer_all_history boolean default true,
  transferred_at timestamptz default now(),
  created_at timestamptz default now()
);

alter table public.supervisor_transfer_mappings enable row level security;
drop policy if exists supervisor_transfer_mappings_all_v465 on public.supervisor_transfer_mappings;
create policy supervisor_transfer_mappings_all_v465 on public.supervisor_transfer_mappings for all using (true) with check (true);
grant all on public.supervisor_transfer_mappings to anon, authenticated;
grant usage, select on sequence public.supervisor_transfer_mappings_id_seq to anon, authenticated;

create or replace function public.tasneef_transfer_supervisor_any_v465(
  p_old_code text default null,
  p_new_code text default null,
  p_old_name text default null,
  p_new_name text default null,
  p_old_user_id text default null,
  p_new_user_id text default null,
  p_from_month text default null,
  p_from_date date default current_date,
  p_transfer_all_history boolean default true
)
returns table(
  project_rows integer,
  distribution_rows integer,
  time_log_rows integer,
  attendance_rows integer,
  daily_rows integer,
  ticket_rows integer,
  old_hidden_rows integer,
  resolved_old text,
  resolved_new text,
  affected_projects integer
)
language plpgsql
security definer
set search_path=public
as $$
declare
  v_old_code text := nullif(trim(coalesce(p_old_code,'')),'');
  v_new_code text := nullif(trim(coalesce(p_new_code,'')),'');
  v_old_name text := nullif(trim(coalesce(p_old_name,'')),'');
  v_new_name text := nullif(trim(coalesce(p_new_name,'')),'');
  v_old_user text := nullif(trim(coalesce(p_old_user_id,'')),'');
  v_new_user text := nullif(trim(coalesce(p_new_user_id,'')),'');
  v_month text := coalesce(nullif(p_from_month,''),to_char(current_date,'YYYY-MM'));
  v_date date := coalesce(p_from_date,current_date);
  v_project_ids text[] := array[]::text[];
  v_more_ids text[] := array[]::text[];
  v_set text;
  v_where text;
  r jsonb;
  rc int;
  t text;
  has_updated boolean;
  has_project boolean;
  date_col text;
  col_type text;

  -- أعمدة محتملة في الجداول القديمة والجديدة
  code_cols text[] := array['supervisor_employee_code','supervisor_code','current_supervisor_code','app_supervisor_code','assigned_supervisor_code'];
  name_cols text[] := array['supervisor_name','current_supervisor_name','app_supervisor_name','assigned_supervisor_name','supervisor','supervisor_full_name'];
  user_cols text[] := array['supervisor_id','current_supervisor_id','app_supervisor_id','assigned_supervisor_id','assigned_to','assigned_to_id'];
  ccol text; ncol text; ucol text;

  function_exists boolean;
begin
  project_rows := 0; distribution_rows := 0; time_log_rows := 0; attendance_rows := 0; daily_rows := 0; ticket_rows := 0; old_hidden_rows := 0; affected_projects := 0;

  -- حل الكود والاسم من جدول الموظفين الموحد
  if to_regclass('public.employees_master_v386') is not null then
    for r in execute 'select to_jsonb(x) from public.employees_master_v386 x' loop
      if v_old_code is null and (trim(coalesce(r->>'app_name',''))=coalesce(v_old_name,'') or trim(coalesce(r->>'employee_name',''))=coalesce(v_old_name,'') or trim(coalesce(r->>'name',''))=coalesce(v_old_name,'')) then
        v_old_code := nullif(coalesce(r->>'employee_code',r->>'code',r->>'id'),'');
      end if;
      if v_new_code is null and (trim(coalesce(r->>'app_name',''))=coalesce(v_new_name,'') or trim(coalesce(r->>'employee_name',''))=coalesce(v_new_name,'') or trim(coalesce(r->>'name',''))=coalesce(v_new_name,'')) then
        v_new_code := nullif(coalesce(r->>'employee_code',r->>'code',r->>'id'),'');
      end if;
      if v_old_name is null and v_old_code is not null and lower(coalesce(r->>'employee_code',r->>'code',r->>'id',''))=lower(v_old_code) then
        v_old_name := coalesce(nullif(r->>'app_name',''),nullif(r->>'employee_name',''),nullif(r->>'name',''),v_old_code);
      end if;
      if v_new_name is null and v_new_code is not null and lower(coalesce(r->>'employee_code',r->>'code',r->>'id',''))=lower(v_new_code) then
        v_new_name := coalesce(nullif(r->>'app_name',''),nullif(r->>'employee_name',''),nullif(r->>'name',''),v_new_code);
      end if;
    end loop;
  end if;

  -- حل الكود والاسم من workers
  if to_regclass('public.workers') is not null then
    for r in execute 'select to_jsonb(x) from public.workers x' loop
      if v_old_code is null and (trim(coalesce(r->>'name',''))=coalesce(v_old_name,'') or trim(coalesce(r->>'full_name',''))=coalesce(v_old_name,'') or trim(coalesce(r->>'app_name',''))=coalesce(v_old_name,'')) then
        v_old_code := nullif(coalesce(r->>'employee_code',r->>'worker_code',r->>'code',r->>'id'),'');
      end if;
      if v_new_code is null and (trim(coalesce(r->>'name',''))=coalesce(v_new_name,'') or trim(coalesce(r->>'full_name',''))=coalesce(v_new_name,'') or trim(coalesce(r->>'app_name',''))=coalesce(v_new_name,'')) then
        v_new_code := nullif(coalesce(r->>'employee_code',r->>'worker_code',r->>'code',r->>'id'),'');
      end if;
      if v_old_name is null and v_old_code is not null and lower(coalesce(r->>'employee_code',r->>'worker_code',r->>'code',r->>'id',''))=lower(v_old_code) then
        v_old_name := coalesce(nullif(r->>'name',''),nullif(r->>'full_name',''),nullif(r->>'app_name',''),v_old_code);
      end if;
      if v_new_name is null and v_new_code is not null and lower(coalesce(r->>'employee_code',r->>'worker_code',r->>'code',r->>'id',''))=lower(v_new_code) then
        v_new_name := coalesce(nullif(r->>'name',''),nullif(r->>'full_name',''),nullif(r->>'app_name',''),v_new_code);
      end if;
    end loop;
  end if;

  -- حل حساب المشرف من app_users
  if to_regclass('public.app_users') is not null then
    for r in execute 'select to_jsonb(x) from public.app_users x' loop
      if v_old_user is null and (
        lower(coalesce(r->>'id',''))=lower(coalesce(v_old_code,'')) or lower(coalesce(r->>'id',''))=lower(coalesce(v_old_user,'')) or
        lower(coalesce(r->>'employee_code',''))=lower(coalesce(v_old_code,'')) or lower(coalesce(r->>'worker_code',''))=lower(coalesce(v_old_code,'')) or
        lower(coalesce(r->>'username',''))=lower(coalesce(v_old_code,'')) or
        trim(coalesce(r->>'full_name',''))=coalesce(v_old_name,'') or trim(coalesce(r->>'name',''))=coalesce(v_old_name,'') or
        (v_old_name is not null and lower(coalesce(r->>'full_name','')) like '%'||lower(v_old_name)||'%')
      ) then v_old_user := r->>'id'; end if;
      if v_new_user is null and (
        lower(coalesce(r->>'id',''))=lower(coalesce(v_new_code,'')) or lower(coalesce(r->>'id',''))=lower(coalesce(v_new_user,'')) or
        lower(coalesce(r->>'employee_code',''))=lower(coalesce(v_new_code,'')) or lower(coalesce(r->>'worker_code',''))=lower(coalesce(v_new_code,'')) or
        lower(coalesce(r->>'username',''))=lower(coalesce(v_new_code,'')) or
        trim(coalesce(r->>'full_name',''))=coalesce(v_new_name,'') or trim(coalesce(r->>'name',''))=coalesce(v_new_name,'') or
        (v_new_name is not null and lower(coalesce(r->>'full_name','')) like '%'||lower(v_new_name)||'%')
      ) then v_new_user := r->>'id'; end if;
    end loop;
  end if;

  if coalesce(v_old_code,v_old_name,v_old_user) is null then raise exception 'لم يتم التعرف على المشرف القديم. أرسل الكود أو الاسم أو user_id.'; end if;
  if coalesce(v_new_code,v_new_name,v_new_user) is null then raise exception 'لم يتم التعرف على المشرف البديل. أرسل الكود أو الاسم أو user_id.'; end if;

  resolved_old := concat_ws(' | ',v_old_code,v_old_name,v_old_user);
  resolved_new := concat_ws(' | ',v_new_code,v_new_name,v_new_user);

  -- حفظ خريطة النقل حتى تفيد الفلاتر مستقبلاً
  insert into public.supervisor_transfer_mappings(old_code,old_name,old_user_id,new_code,new_name,new_user_id,transfer_all_history)
  values(v_old_code,v_old_name,v_old_user,v_new_code,v_new_name,v_new_user,coalesce(p_transfer_all_history,true));

  -- قالب WHERE مرن للمشرف القديم: كود/اسم/حساب، مع مطابقة جزئية للاسم
  -- اجمع المشاريع من projects
  if to_regclass('public.projects') is not null then
    v_where := 'false';
    if v_old_code is not null then foreach ccol in array code_cols loop v_where := v_where || format(' or lower(coalesce(to_jsonb(x)->>%L,''''))=lower(%L)',ccol,v_old_code); end loop; end if;
    if v_old_name is not null then foreach ncol in array name_cols loop v_where := v_where || format(' or lower(trim(coalesce(to_jsonb(x)->>%L,'''')))=lower(%L) or lower(coalesce(to_jsonb(x)->>%L,'''')) like %L',ncol,v_old_name,ncol,'%'||lower(v_old_name)||'%'); end loop; end if;
    if v_old_user is not null then foreach ucol in array user_cols loop v_where := v_where || format(' or coalesce(to_jsonb(x)->>%L,'''')=%L',ucol,v_old_user); end loop; end if;
    execute format('select coalesce(array_agg(distinct to_jsonb(x)->>''id''),array[]::text[]) from public.projects x where %s',v_where) into v_project_ids;
  end if;

  -- اجمع المشاريع من جميع الجداول التي قد تحتوي سجلات المشرف القديم
  foreach t in array array['monthly_distribution','time_logs','attendance','daily_records','tickets'] loop
    if to_regclass('public.'||t) is not null and exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name='project_id') then
      v_where := 'false';
      if v_old_code is not null then foreach ccol in array code_cols loop v_where := v_where || format(' or lower(coalesce(to_jsonb(x)->>%L,''''))=lower(%L)',ccol,v_old_code); end loop; end if;
      if v_old_name is not null then foreach ncol in array name_cols loop v_where := v_where || format(' or lower(trim(coalesce(to_jsonb(x)->>%L,'''')))=lower(%L) or lower(coalesce(to_jsonb(x)->>%L,'''')) like %L',ncol,v_old_name,ncol,'%'||lower(v_old_name)||'%'); end loop; end if;
      if v_old_user is not null then foreach ucol in array user_cols loop v_where := v_where || format(' or coalesce(to_jsonb(x)->>%L,'''')=%L',ucol,v_old_user); end loop; end if;
      execute format('select coalesce(array_agg(distinct to_jsonb(x)->>''project_id''),array[]::text[]) from public.%I x where %s',t,v_where) into v_more_ids;
      v_project_ids := array(select distinct x from unnest(coalesce(v_project_ids,array[]::text[]) || coalesce(v_more_ids,array[]::text[])) as x where x is not null and x <> '');
    end if;
  end loop;

  affected_projects := coalesce(array_length(v_project_ids,1),0);

  -- دالة داخلية ضمنية لبناء SET لكل جدول حسب الأعمدة الموجودة
  -- تحديث projects
  if to_regclass('public.projects') is not null then
    v_set := '';
    select exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='updated_at') into has_updated;
    foreach ccol in array code_cols loop if exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name=ccol) then v_set := v_set || format('%I=%L,',ccol,v_new_code); end if; end loop;
    foreach ncol in array name_cols loop if exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name=ncol) then v_set := v_set || format('%I=%L,',ncol,v_new_name); end if; end loop;
    if v_new_user is not null then
      foreach ucol in array user_cols loop
        select data_type into col_type from information_schema.columns where table_schema='public' and table_name='projects' and column_name=ucol limit 1;
        if col_type is not null then
          if col_type in ('integer','bigint','smallint','numeric') and v_new_user ~ '^\d+$' then v_set := v_set || format('%I=%s,',ucol,v_new_user);
          elsif col_type not in ('integer','bigint','smallint','numeric') then v_set := v_set || format('%I=%L,',ucol,v_new_user); end if;
        end if;
      end loop;
    end if;
    if has_updated then v_set := v_set || 'updated_at=now(),'; end if;
    v_set := trim(trailing ',' from v_set);
    if v_set <> '' then
      v_where := 'false';
      if affected_projects > 0 then v_where := v_where || ' or to_jsonb(x)->>''id'' = any($1)'; end if;
      if v_old_code is not null then foreach ccol in array code_cols loop v_where := v_where || format(' or lower(coalesce(to_jsonb(x)->>%L,''''))=lower(%L)',ccol,v_old_code); end loop; end if;
      if v_old_name is not null then foreach ncol in array name_cols loop v_where := v_where || format(' or lower(trim(coalesce(to_jsonb(x)->>%L,'''')))=lower(%L) or lower(coalesce(to_jsonb(x)->>%L,'''')) like %L',ncol,v_old_name,ncol,'%'||lower(v_old_name)||'%'); end loop; end if;
      if v_old_user is not null then foreach ucol in array user_cols loop v_where := v_where || format(' or coalesce(to_jsonb(x)->>%L,'''')=%L',ucol,v_old_user); end loop; end if;
      if affected_projects > 0 then execute format('update public.projects x set %s where %s',v_set,v_where) using v_project_ids; else execute format('update public.projects x set %s where %s',v_set,v_where); end if;
      get diagnostics project_rows = row_count;
    end if;
  end if;

  -- تحديث كل الجداول: التوزيع والسجلات والتكتات - كل التاريخ افتراضياً
  foreach t in array array['monthly_distribution','time_logs','attendance','daily_records','tickets'] loop
    if to_regclass('public.'||t) is not null then
      v_set := '';
      select exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name='updated_at') into has_updated;
      select exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name='project_id') into has_project;

      foreach ccol in array code_cols loop if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name=ccol) then v_set := v_set || format('%I=%L,',ccol,v_new_code); end if; end loop;
      foreach ncol in array name_cols loop if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name=ncol) then v_set := v_set || format('%I=%L,',ncol,v_new_name); end if; end loop;
      if v_new_user is not null then
        foreach ucol in array user_cols loop
          select data_type into col_type from information_schema.columns where table_schema='public' and table_name=t and column_name=ucol limit 1;
          if col_type is not null then
            if col_type in ('integer','bigint','smallint','numeric') and v_new_user ~ '^\d+$' then v_set := v_set || format('%I=%s,',ucol,v_new_user);
            elsif col_type not in ('integer','bigint','smallint','numeric') then v_set := v_set || format('%I=%L,',ucol,v_new_user); end if;
          end if;
        end loop;
      end if;
      if has_updated then v_set := v_set || 'updated_at=now(),'; end if;
      v_set := trim(trailing ',' from v_set);

      if v_set <> '' then
        v_where := 'false';
        if has_project and affected_projects > 0 then v_where := v_where || ' or to_jsonb(x)->>''project_id'' = any($1)'; end if;
        if v_old_code is not null then foreach ccol in array code_cols loop v_where := v_where || format(' or lower(coalesce(to_jsonb(x)->>%L,''''))=lower(%L)',ccol,v_old_code); end loop; end if;
        if v_old_name is not null then foreach ncol in array name_cols loop v_where := v_where || format(' or lower(trim(coalesce(to_jsonb(x)->>%L,'''')))=lower(%L) or lower(coalesce(to_jsonb(x)->>%L,'''')) like %L',ncol,v_old_name,ncol,'%'||lower(v_old_name)||'%'); end loop; end if;
        if v_old_user is not null then foreach ucol in array user_cols loop v_where := v_where || format(' or coalesce(to_jsonb(x)->>%L,'''')=%L',ucol,v_old_user); end loop; end if;

        if not coalesce(p_transfer_all_history,true) then
          date_col := null;
          foreach date_col in array array['log_date','attendance_date','record_date','created_at','date'] loop
            if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name=date_col) then exit; end if;
          end loop;
          if date_col is not null then v_where := '('||v_where||') and (to_jsonb(x)->>'||quote_literal(date_col)||')::date >= '||quote_literal(v_date); end if;
        end if;

        if has_project and affected_projects > 0 then execute format('update public.%I x set %s where %s',t,v_set,v_where) using v_project_ids; else execute format('update public.%I x set %s where %s',t,v_set,v_where); end if;
        get diagnostics rc = row_count;
        if t='monthly_distribution' then distribution_rows := rc; end if;
        if t='time_logs' then time_log_rows := rc; end if;
        if t='attendance' then attendance_rows := rc; end if;
        if t='daily_records' then daily_rows := rc; end if;
        if t='tickets' then ticket_rows := rc; end if;
      end if;
    end if;
  end loop;

  -- إخفاء/إيقاف المشرف القديم من الفلاتر وحساب المشرفين
  if to_regclass('public.app_users') is not null then
    v_set := '';
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='app_users' and column_name='is_active') then v_set := v_set || 'is_active=false,'; end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='app_users' and column_name='active') then v_set := v_set || 'active=false,'; end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='app_users' and column_name='status') then v_set := v_set || 'status=''inactive'','; end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='app_users' and column_name='active_status') then v_set := v_set || 'active_status=''inactive'','; end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='app_users' and column_name='updated_at') then v_set := v_set || 'updated_at=now(),'; end if;
    v_set := trim(trailing ',' from v_set);
    if v_set <> '' then
      v_where := 'false';
      if v_old_user is not null then v_where := v_where || format(' or to_jsonb(x)->>''id''=%L',v_old_user); end if;
      if v_old_code is not null then v_where := v_where || format(' or lower(coalesce(to_jsonb(x)->>''employee_code'',''''))=lower(%L) or lower(coalesce(to_jsonb(x)->>''username'',''''))=lower(%L)',v_old_code,v_old_code); end if;
      if v_old_name is not null then v_where := v_where || format(' or lower(trim(coalesce(to_jsonb(x)->>''full_name'','''')))=lower(%L) or lower(coalesce(to_jsonb(x)->>''full_name'','''')) like %L or lower(trim(coalesce(to_jsonb(x)->>''name'','''')))=lower(%L)',v_old_name,'%'||lower(v_old_name)||'%',v_old_name); end if;
      execute format('update public.app_users x set %s where %s',v_set,v_where);
      get diagnostics rc = row_count; old_hidden_rows := old_hidden_rows + rc;
    end if;
  end if;

  -- إيقافه في جداول العمال/الموظفين، مع تاريخ نهاية الخدمة اليوم
  foreach t in array array['employees_master_v386','workers'] loop
    if to_regclass('public.'||t) is not null then
      v_set := '';
      if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name='status') then v_set := v_set || 'status=''inactive'','; end if;
      if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name='state') then v_set := v_set || 'state=''inactive'','; end if;
      if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name='is_active') then v_set := v_set || 'is_active=false,'; end if;
      if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name='active') then v_set := v_set || 'active=false,'; end if;
      if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name='end_date') then v_set := v_set || format('end_date=%L,',current_date); end if;
      if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name='work_end_date') then v_set := v_set || format('work_end_date=%L,',current_date); end if;
      if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name='service_end_date') then v_set := v_set || format('service_end_date=%L,',current_date); end if;
      if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name='termination_date') then v_set := v_set || format('termination_date=%L,',current_date); end if;
      if exists(select 1 from information_schema.columns where table_schema='public' and table_name=t and column_name='updated_at') then v_set := v_set || 'updated_at=now(),'; end if;
      v_set := trim(trailing ',' from v_set);
      if v_set <> '' then
        v_where := 'false';
        if v_old_code is not null then v_where := v_where || format(' or lower(coalesce(to_jsonb(x)->>''employee_code'',''''))=lower(%L) or lower(coalesce(to_jsonb(x)->>''worker_code'',''''))=lower(%L) or lower(coalesce(to_jsonb(x)->>''code'',''''))=lower(%L)',v_old_code,v_old_code,v_old_code); end if;
        if v_old_name is not null then v_where := v_where || format(' or lower(trim(coalesce(to_jsonb(x)->>''name'','''')))=lower(%L) or lower(trim(coalesce(to_jsonb(x)->>''full_name'','''')))=lower(%L) or lower(trim(coalesce(to_jsonb(x)->>''app_name'','''')))=lower(%L) or lower(trim(coalesce(to_jsonb(x)->>''employee_name'','''')))=lower(%L)',v_old_name,v_old_name,v_old_name,v_old_name); end if;
        execute format('update public.%I x set %s where %s',t,v_set,v_where);
        get diagnostics rc = row_count; old_hidden_rows := old_hidden_rows + rc;
      end if;
    end if;
  end loop;

  return next;
end;
$$;

grant execute on function public.tasneef_transfer_supervisor_any_v465(text,text,text,text,text,text,text,date,boolean) to anon, authenticated;

-- فهارس مساعدة آمنة
create index if not exists idx_projects_id_text_v465 on public.projects((id::text));
create index if not exists idx_monthly_distribution_project_v465 on public.monthly_distribution((project_id::text));
create index if not exists idx_monthly_distribution_supervisor_emp_v465 on public.monthly_distribution(supervisor_employee_code) where supervisor_employee_code is not null;
create index if not exists idx_monthly_distribution_supervisor_name_v465 on public.monthly_distribution(supervisor_name) where supervisor_name is not null;
create index if not exists idx_time_logs_project_v465 on public.time_logs(project_id) where project_id is not null;
create index if not exists idx_attendance_project_v465 on public.attendance(project_id) where project_id is not null;
create index if not exists idx_tickets_project_v465 on public.tickets(project_id) where project_id is not null;
create index if not exists idx_tickets_supervisor_id_v465 on public.tickets(supervisor_id) where supervisor_id is not null;

-- تشغيل يدوي اختياري للحالة الحالية، غيّر الأسماء لو مكتوبة بطريقة مختلفة:
-- select * from public.tasneef_transfer_supervisor_any_v465(null,null,'محمود','وضاح',null,null,null,current_date,true);
