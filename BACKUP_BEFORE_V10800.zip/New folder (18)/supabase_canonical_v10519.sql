-- Tasneef V10519 CANONICAL ONLY
-- شغّل الملف كاملًا مرة واحدة. هذه هي الدوال الوحيدة المعتمدة للتذاكر والتسجيلات.

begin;

create index if not exists idx_tickets_project_created_v10519 on public.tickets(project_id,created_at desc);
create index if not exists idx_time_logs_date_supervisor_v10519 on public.time_logs(log_date,supervisor_id);

create or replace function public.tasneef_tickets_all_v10519()
returns setof public.tickets
language sql security definer set search_path=public stable
as $$
  select t.* from public.tickets t
  order by t.created_at desc nulls last,t.id desc
  limit 5000;
$$;
grant execute on function public.tasneef_tickets_all_v10519() to anon,authenticated;

create or replace function public.tasneef_client_tickets_v10519(p_project_id text)
returns setof public.tickets
language plpgsql security definer set search_path=public stable
as $$
#variable_conflict use_column
declare v_pid bigint;
begin
  v_pid := nullif(trim(p_project_id),'')::bigint;
  return query
  select t.* from public.tickets t
  where t.project_id=v_pid
  order by t.created_at desc nulls last,t.id desc
  limit 2000;
end;
$$;
grant execute on function public.tasneef_client_tickets_v10519(text) to anon,authenticated;

create or replace function public.tasneef_client_create_ticket_v10519(
  p_project_id text,
  p_title text,
  p_description text default '',
  p_type text default 'أخرى',
  p_location text default ''
)
returns setof public.tickets
language plpgsql security definer set search_path=public
as $$
declare
  v_pid bigint;
  v_id bigint;
  v_desc text;
begin
  if nullif(trim(coalesce(p_title,'')),'') is null then
    raise exception 'عنوان التذكرة مطلوب';
  end if;
  v_pid := nullif(trim(p_project_id),'')::bigint;
  if not exists(select 1 from public.projects p where p.id=v_pid) then
    raise exception 'المشروع غير موجود';
  end if;
  v_desc := concat_ws(E'\n',
    nullif(trim(coalesce(p_description,'')),''),
    case when nullif(trim(coalesce(p_location,'')),'') is not null then 'الموقع: '||trim(p_location) end,
    case when nullif(trim(coalesce(p_type,'')),'') is not null then 'النوع: '||trim(p_type) end,
    'المصدر: بوابة العميل'
  );
  insert into public.tickets(project_id,title,description,status,priority,created_at,updated_at)
  values(v_pid,trim(p_title),v_desc,'open','normal',now(),now())
  returning id into v_id;
  begin
    update public.tickets
    set ticket_number=coalesce(nullif(ticket_number,''),'T-'||lpad(v_id::text,6,'0'))
    where id=v_id;
  exception when undefined_column then null;
  end;
  return query select t.* from public.tickets t where t.id=v_id;
end;
$$;
grant execute on function public.tasneef_client_create_ticket_v10519(text,text,text,text,text) to anon,authenticated;

create or replace function public.tasneef_daily_logs_visible_v10519(p_from date,p_to date,p_supervisor_id bigint default null)
returns setof public.time_logs
language sql security definer set search_path=public stable
as $$
  select l.* from public.time_logs l
  where coalesce(l.log_date,(l.check_in at time zone 'Asia/Riyadh')::date,(l.created_at at time zone 'Asia/Riyadh')::date) between p_from and p_to
    and (p_supervisor_id is null or l.supervisor_id=p_supervisor_id or l.user_id=p_supervisor_id)
  order by coalesce(l.check_in,l.created_at) desc nulls last,l.id desc
  limit 5000;
$$;
grant execute on function public.tasneef_daily_logs_visible_v10519(date,date,bigint) to anon,authenticated;

commit;
notify pgrst,'reload schema';


-- ===== V10700 Unified RBAC schema (run once in Supabase SQL editor) =====
create table if not exists public.roles (id bigserial primary key, role_key text unique not null, name text not null, description text, is_system boolean default false, is_active boolean default true, created_at timestamptz default now());
create table if not exists public.permissions (id bigserial primary key, permission_key text unique not null, module text not null, resource text, action text not null, description text, is_sensitive boolean default false, created_at timestamptz default now());
create table if not exists public.role_permissions (id bigserial primary key, role_id bigint references public.roles(id) on delete cascade, permission_id bigint references public.permissions(id) on delete cascade, allowed boolean default true, scope_type text default 'all', unique(role_id,permission_id));
create table if not exists public.user_permissions (id bigserial primary key, user_id bigint references public.app_users(id) on delete cascade, permission_id bigint references public.permissions(id) on delete cascade, allowed boolean default true, scope_type text, valid_from timestamptz, valid_until timestamptz, granted_by bigint, created_at timestamptz default now(), unique(user_id,permission_id));
create table if not exists public.user_permission_denials (id bigserial primary key, user_id bigint references public.app_users(id) on delete cascade, permission_id bigint references public.permissions(id) on delete cascade, reason text, denied_by bigint, created_at timestamptz default now(), unique(user_id,permission_id));
create table if not exists public.user_scopes (id bigserial primary key, user_id bigint references public.app_users(id) on delete cascade, scope_type text not null, scope_value jsonb default '{}'::jsonb, created_by bigint, created_at timestamptz default now());
create table if not exists public.user_projects (id bigserial primary key, user_id bigint references public.app_users(id) on delete cascade, project_id bigint references public.projects(id) on delete cascade, is_active boolean default true, granted_by bigint, created_at timestamptz default now(), unique(user_id,project_id));
create table if not exists public.user_departments (id bigserial primary key, name text unique not null, code text unique, is_active boolean default true, created_at timestamptz default now());
create table if not exists public.user_sessions (id uuid primary key default gen_random_uuid(), user_id bigint references public.app_users(id) on delete cascade, device text, browser text, ip_address inet, location_text text, signed_in_at timestamptz default now(), last_activity_at timestamptz default now(), ended_at timestamptz, ended_by bigint, is_active boolean default true);
create table if not exists public.approval_requests (id bigserial primary key, module text not null, action text not null, record_id text, requested_by bigint, current_level integer default 1, status text default 'pending', old_value jsonb, new_value jsonb, notes text, created_at timestamptz default now(), resolved_at timestamptz);
create table if not exists public.approval_steps (id bigserial primary key, request_id bigint references public.approval_requests(id) on delete cascade, level integer not null, approver_role text, approver_id bigint, decision text, notes text, decided_at timestamptz);
create table if not exists public.audit_logs (id bigserial primary key, user_id bigint, action text not null, module text, record_id text, old_value jsonb, new_value jsonb, device text, session_id uuid, reason text, result text, created_at timestamptz default now());
create table if not exists public.login_attempts (id bigserial primary key, username text, user_id bigint, success boolean default false, ip_address inet, device text, failure_reason text, created_at timestamptz default now());
create table if not exists public.security_notifications (id bigserial primary key, user_id bigint, type text, title text, body text, is_read boolean default false, created_at timestamptz default now());
create table if not exists public.permission_templates (id bigserial primary key, name text unique not null, role_key text, permissions jsonb default '{}'::jsonb, scope jsonb default '{}'::jsonb, is_active boolean default true, created_at timestamptz default now());
alter table public.app_users add column if not exists email text;
alter table public.app_users add column if not exists phone text;
alter table public.app_users add column if not exists job_title text;
alter table public.app_users add column if not exists department_id bigint;
alter table public.app_users add column if not exists role_key text;
alter table public.app_users add column if not exists manager_id bigint;
alter table public.app_users add column if not exists status text default 'active';
alter table public.app_users add column if not exists valid_from date;
alter table public.app_users add column if not exists valid_until date;
alter table public.app_users add column if not exists scope_type text default 'all';
alter table public.app_users add column if not exists allowed_project_ids jsonb default '[]'::jsonb;
alter table public.app_users add column if not exists permission_denials jsonb default '{}'::jsonb;
alter table public.app_users add column if not exists force_password_change boolean default false;
alter table public.app_users add column if not exists mfa_required boolean default false;
alter table public.app_users add column if not exists login_attempt_limit integer default 5;
alter table public.app_users add column if not exists session_timeout_minutes integer default 480;
alter table public.app_users add column if not exists last_login_at timestamptz;
alter table public.app_users add column if not exists last_activity_at timestamptz;
alter table public.app_users add column if not exists notes text;
alter table public.app_users add column if not exists created_by bigint;
alter table public.app_users add column if not exists updated_at timestamptz default now();
create or replace function public.has_permission(p_user_id bigint,p_permission_key text,p_project_id bigint default null) returns boolean language plpgsql security definer stable as $$ declare u public.app_users%rowtype; begin select * into u from public.app_users where id=p_user_id; if not found or u.is_active is not true or coalesce(u.status,'active')<>'active' or (u.valid_until is not null and u.valid_until<current_date) then return false; end if; if coalesce(u.role_key,u.role) in ('system_admin','admin','general_manager') then return true; end if; if coalesce(u.permission_denials,'{}'::jsonb) ? p_permission_key then return false; end if; if coalesce(u.permissions,'{}'::jsonb)->>p_permission_key='true' then if p_project_id is null or coalesce(u.scope_type,'all')='all' then return true; end if; return exists(select 1 from public.user_projects up where up.user_id=p_user_id and up.project_id=p_project_id and up.is_active is true); end if; return false; end $$;
-- Important: Existing frontend uses custom app_users login, not Supabase Auth. Do not enable restrictive RLS policies until auth_user_id/JWT mapping is completed, otherwise current users will be locked out.

-- V460: جداول نتيجة الرواتب فقط؛ بيانات العامل والحضور والتوزيع تبقى في مصادرها الأصلية.
create table if not exists payroll_periods (
  id bigserial primary key, period_month date not null unique, status text not null default 'draft',
  created_by bigint, created_at timestamptz default now(), approved_by bigint, approved_at timestamptz,
  paid_by bigint, paid_at timestamptz, notes text
);
create table if not exists payroll_adjustments (
  id bigserial primary key, worker_id bigint not null, payroll_period_id bigint references payroll_periods(id),
  effective_date date not null, adjustment_type text not null, amount numeric(14,2) not null default 0,
  original_amount numeric(14,2), reason text, status text default 'draft', created_by bigint,
  created_at timestamptz default now(), approved_by bigint, approved_at timestamptz, is_deleted boolean default false
);
create table if not exists payroll_audit_logs (
  id bigserial primary key, payroll_period_id bigint, worker_id bigint, action text not null,
  old_data jsonb, new_data jsonb, reason text, user_id bigint, created_at timestamptz default now()
);
create index if not exists idx_payroll_adjustments_worker_date on payroll_adjustments(worker_id,effective_date);
create index if not exists idx_payroll_audit_period_worker on payroll_audit_logs(payroll_period_id,worker_id);

-- V474: مصدر الرواتب الوحيد من السيرفر. لا دمج أو fallback داخل الواجهة.
create or replace function public.get_unified_payroll_from_server(p_month text)
returns jsonb
language plpgsql
security invoker
set search_path = public
as $$
#variable_conflict use_column
declare
  v_start date;
  v_end date;
  v_result jsonb;
  v_duplicates integer;
begin
  if p_month is null or p_month !~ '^\d{4}-\d{2}$' then
    raise exception 'Invalid payroll month: %', p_month;
  end if;

  v_start := (p_month || '-01')::date;
  v_end := (v_start + interval '1 month - 1 day')::date;

  with
  employee_source as (
    select to_jsonb(e) as j
    from public.employees_master_v386 e
  ),
  employees_all as (
    select
      coalesce(nullif(j->>'employee_id',''), nullif(j->>'worker_id',''), nullif(j->>'staff_id',''), nullif(j->>'person_id',''), nullif(j->>'id','')) as canonical_employee_id,
      array_remove(array[
        nullif(j->>'id',''), nullif(j->>'employee_id',''), nullif(j->>'worker_id',''), nullif(j->>'staff_id',''), nullif(j->>'person_id',''),
        nullif(j->>'employee_code',''), nullif(j->>'worker_code',''), nullif(j->>'employee_ts_id',''), nullif(j->>'code','')
      ], null) as aliases,
      j
    from employee_source
  ),
  employees as (
    select *
    from employees_all
    where canonical_employee_id is not null
      and coalesce(lower(j->>'is_active'),'false') = 'true'
      and coalesce(lower(j->>'status'),'active') not in ('inactive','stopped','terminated','disabled','موقوف','متوقف','منتهي')
      and coalesce(lower(j->>'is_deleted'),'false') <> 'true'
  ),
  stopped_employees as (
    select count(*)::int n from employees_all
    where canonical_employee_id is not null
      and not (
        coalesce(lower(j->>'is_active'),'false') = 'true'
        and coalesce(lower(j->>'status'),'active') not in ('inactive','stopped','terminated','disabled','موقوف','متوقف','منتهي')
      )
  ),
  project_source as (
    select to_jsonb(p) j from public.projects p
  ),
  projects as (
    select
      coalesce(nullif(j->>'id',''),nullif(j->>'project_id','')) project_id,
      coalesce(nullif(j->>'name',''),nullif(j->>'project_name',''),nullif(j->>'title',''),'مشروع') project_name,
      coalesce(nullif(j->>'operation_type',''),nullif(j->>'project_type',''),'') operation_type,
      coalesce(nullif(j->>'required_daily_minutes','')::numeric,540) required_daily_minutes,
      coalesce(nullif(j->>'friday_minutes','')::numeric,0) friday_minutes,
      j
    from project_source
    where coalesce(lower(j->>'is_active'),'false')='true'
      and coalesce(lower(j->>'status'),'active') not in ('inactive','stopped','terminated','disabled','موقوف','متوقف','منتهي')
  ),
  distribution_source as (
    select to_jsonb(d) j from public.monthly_distribution d
  ),
  assignments_raw as (
    select
      coalesce(nullif(j->>'worker_employee_code',''),nullif(j->>'employee_id',''),nullif(j->>'worker_id',''),nullif(j->>'staff_id',''),nullif(j->>'person_id','')) worker_ref,
      coalesce(nullif(j->>'supervisor_employee_code',''),nullif(j->>'supervisor_id','')) supervisor_ref,
      coalesce(nullif(j->>'project_id',''),nullif(j->>'project_code','')) project_ref,
      greatest(coalesce(nullif(j->>'start_date','')::date,v_start),v_start) assignment_start,
      least(coalesce(nullif(j->>'end_date','')::date,v_end),v_end) assignment_end,
      j
    from distribution_source
    where (
      j->>'month_key' = p_month
      or (
        coalesce(nullif(j->>'start_date','')::date,v_start) <= v_end
        and coalesce(nullif(j->>'end_date','')::date,v_end) >= v_start
      )
    )
      and coalesce(lower(j->>'status'),'active') not in ('deleted','cancelled','ملغي','محذوف')
  ),
  assignments_linked as (
    select distinct on (e.canonical_employee_id, ar.project_ref, ar.supervisor_ref, ar.assignment_start, ar.assignment_end)
      e.canonical_employee_id,
      ar.supervisor_ref,
      ar.project_ref,
      ar.assignment_start,
      ar.assignment_end,
      greatest((ar.assignment_end-ar.assignment_start)+1,0)::int overlap_days,
      ar.j
    from assignments_raw ar
    join employees e on ar.worker_ref = any(e.aliases)
    where ar.assignment_start <= ar.assignment_end
    order by e.canonical_employee_id, ar.project_ref, ar.supervisor_ref, ar.assignment_start, ar.assignment_end
  ),
  supervisors as (
    select
      canonical_employee_id supervisor_id,
      coalesce(nullif(j->>'app_name',''),nullif(j->>'display_name',''),nullif(j->>'name',''),nullif(j->>'full_name',''),nullif(j->>'employee_name',''),'مشرف') supervisor_name,
      aliases,
      j
    from employees
    where lower(coalesce(j->>'job_title',j->>'position',j->>'role',j->>'employee_type','')) like '%مشرف%'
       or lower(coalesce(j->>'job_title',j->>'position',j->>'role',j->>'employee_type','')) like '%supervisor%'
  ),
  stopped_supervisor_refs as (
    select count(*)::int n
    from assignments_linked a
    where a.supervisor_ref is not null
      and not exists(select 1 from supervisors s where a.supervisor_ref=any(s.aliases))
  ),
  assignments_enriched as (
    select
      a.canonical_employee_id,
      s.supervisor_id,
      s.supervisor_name,
      p.project_id,
      p.project_name,
      p.operation_type,
      p.required_daily_minutes,
      p.friday_minutes,
      a.assignment_start,
      a.assignment_end,
      a.overlap_days
    from assignments_linked a
    left join supervisors s on a.supervisor_ref=any(s.aliases)
    left join projects p on a.project_ref=p.project_id
    where a.project_ref is null or p.project_id is not null
  ),
  supervisor_days as (
    select ae.canonical_employee_id, ae.supervisor_id, max(ae.supervisor_name) as supervisor_name,
           sum(ae.overlap_days)::int as supervisor_days, max(ae.assignment_start) as latest_start
    from assignments_enriched ae
    where ae.supervisor_id is not null
    group by ae.canonical_employee_id, ae.supervisor_id
  ),
  primary_supervisor as (
    select ranked.canonical_employee_id, ranked.supervisor_id, ranked.supervisor_name, ranked.supervisor_days
    from (
      select sd.*, row_number() over(partition by canonical_employee_id order by supervisor_days desc, latest_start desc, supervisor_id) rn
      from supervisor_days sd
    ) ranked where ranked.rn=1
  ),
  attendance_source as (
    select to_jsonb(a) j from public.attendance a
  ),
  attendance_raw as (
    select
      coalesce(nullif(j->>'employee_id',''),nullif(j->>'worker_id',''),nullif(j->>'staff_id',''),nullif(j->>'person_id',''),nullif(j->>'user_id','')) employee_ref,
      coalesce(nullif(j->>'attendance_date','')::date,nullif(j->>'date','')::date,(nullif(j->>'created_at',''))::timestamptz::date) attendance_date,
      coalesce(nullif(j->>'check_in',''),nullif(j->>'in_time',''),nullif(j->>'start_time',''),nullif(j->>'login_time','')) check_in,
      coalesce(nullif(j->>'check_out',''),nullif(j->>'out_time',''),nullif(j->>'end_time',''),nullif(j->>'logout_time','')) check_out,
      j
    from attendance_source
  ),
  attendance_linked as (
    select e.canonical_employee_id, ar.attendance_date,
           min(ar.check_in) check_in, max(ar.check_out) check_out
    from attendance_raw ar
    join employees e on ar.employee_ref=any(e.aliases)
    where ar.attendance_date between v_start and v_end
      and ar.check_in is not null
      and coalesce(lower(ar.j->>'status'),'present') not in ('cancelled','rejected','failed','ملغي','مرفوض','غير معتمد')
      and coalesce(lower(ar.j->>'is_cancelled'),'false') <> 'true'
      and coalesce(lower(ar.j->>'is_deleted'),'false') <> 'true'
      and coalesce(lower(ar.j->>'is_approved'),'true') = 'true'
    group by e.canonical_employee_id, ar.attendance_date
  ),
  attendance_agg as (
    select al.canonical_employee_id, min(al.attendance_date) as first_attendance_date,
           count(*)::int as present_days,
           jsonb_agg(jsonb_build_object('date',al.attendance_date,'check_in',al.check_in,'check_out',al.check_out) order by al.attendance_date) as attendance_days
    from attendance_linked al group by al.canonical_employee_id
  ),
  service_dates as (
    select e.canonical_employee_id,
      greatest(v_start,
        coalesce(nullif(e.j->>'work_start_date','')::date,nullif(e.j->>'hire_date','')::date,nullif(e.j->>'joining_date','')::date,v_start),
        coalesce((select min(a.assignment_start) from assignments_enriched a where a.canonical_employee_id=e.canonical_employee_id),v_start),
        coalesce(at.first_attendance_date,v_start)
      ) service_start,
      least(v_end,coalesce(nullif(e.j->>'work_end_date','')::date,nullif(e.j->>'termination_date','')::date,nullif(e.j->>'stop_date','')::date,v_end)) service_end
    from employees e left join attendance_agg at using(canonical_employee_id)
  ),
  required_calendar as (
    select sd.canonical_employee_id, g.d::date work_date,
      case
        when extract(isodow from g.d)=5 then coalesce((
          select max(a.friday_minutes) from assignments_enriched a
          where a.canonical_employee_id=sd.canonical_employee_id and g.d::date between a.assignment_start and a.assignment_end
        ),0)
        else coalesce((
          select max(a.required_daily_minutes) from assignments_enriched a
          where a.canonical_employee_id=sd.canonical_employee_id and g.d::date between a.assignment_start and a.assignment_end
        ),540)
      end required_minutes
    from service_dates sd
    cross join lateral generate_series(sd.service_start,sd.service_end,interval '1 day') g(d)
    where sd.service_start<=sd.service_end
  ),
  required_agg as (
    select rc.canonical_employee_id,
      count(*) filter(where rc.required_minutes>0)::int as required_work_days,
      coalesce(sum(rc.required_minutes),0)::numeric as required_minutes
    from required_calendar rc group by rc.canonical_employee_id
  ),
  adjustment_source as (
    select to_jsonb(pa) j from public.payroll_adjustments pa
    where pa.effective_date between v_start and v_end and coalesce(pa.is_deleted,false)=false
  ),
  adjustments as (
    select e.canonical_employee_id,
      coalesce(sum((x.j->>'amount')::numeric) filter(where lower(x.j->>'adjustment_type') in ('allowance','بدل','بدلات')),0) allowances,
      coalesce(sum((x.j->>'amount')::numeric) filter(where lower(x.j->>'adjustment_type') in ('commission','bonus','حافز','عمولة')),0) commissions,
      coalesce(sum((x.j->>'amount')::numeric) filter(where lower(x.j->>'adjustment_type') in ('advance','سلفة')),0) advances,
      coalesce(sum((x.j->>'amount')::numeric) filter(where lower(x.j->>'adjustment_type') in ('deduction','خصم','جزاء')),0) deductions
    from adjustment_source x
    join employees e on coalesce(nullif(x.j->>'employee_id',''),nullif(x.j->>'worker_id',''))=any(e.aliases)
    where coalesce(lower(x.j->>'status'),'approved') in ('approved','معتمد')
    group by e.canonical_employee_id
  ),
  assignment_json as (
    select canonical_employee_id,
      jsonb_agg(jsonb_build_object(
        'project_id',project_id,'project_name',project_name,'supervisor_id',supervisor_id,'supervisor_name',supervisor_name,
        'start',assignment_start,'end',assignment_end,'days',overlap_days,'operation_type',operation_type
      ) order by assignment_start) assignment_details,
      array_agg(distinct project_id) filter(where project_id is not null) project_ids,
      array_agg(distinct project_name) filter(where project_name is not null) project_names,
      count(distinct supervisor_id) filter(where supervisor_id is not null)>1 multiple_supervisors
    from assignments_enriched group by canonical_employee_id
  ),
  payroll_rows as (
    select
      e.canonical_employee_id,
      e.canonical_employee_id worker_id,
      coalesce(nullif(e.j->>'employee_code',''),nullif(e.j->>'worker_code',''),nullif(e.j->>'employee_ts_id',''),nullif(e.j->>'code',''),e.canonical_employee_id) employee_code,
      p_month AS "month",
      coalesce(nullif(e.j->>'iqama_name',''),nullif(e.j->>'residency_name',''),nullif(e.j->>'official_name',''),nullif(e.j->>'full_name',''),nullif(e.j->>'name',''),'موظف') residency_name,
      coalesce(nullif(e.j->>'app_name',''),nullif(e.j->>'display_name',''),nullif(e.j->>'name',''),nullif(e.j->>'full_name',''),'موظف') worker_name,
      coalesce(nullif(e.j->>'iqama_number',''),nullif(e.j->>'residency_number',''),nullif(e.j->>'national_id',''),'') iqama_number,
      coalesce(nullif(e.j->>'job_title',''),nullif(e.j->>'position',''),nullif(e.j->>'employee_type',''),nullif(e.j->>'job_type',''),nullif(e.j->>'role',''),'عامل') job_title,
      ps.supervisor_id,
      coalesce(ps.supervisor_name,'دون مشرف نشط') supervisor_name,
      case
        when coalesce(array_length(aj.project_names,1),0)>1 then 'متعدد'
        when coalesce(array_length(aj.project_names,1),0)=1 then
          case when exists(select 1 from assignments_enriched ae where ae.canonical_employee_id=e.canonical_employee_id and lower(ae.operation_type) in ('daily_visit','زيارة يومية'))
               then coalesce(ps.supervisor_name,'دون مشرف نشط') else aj.project_names[1] end
        when lower(coalesce(e.j->>'job_title',e.j->>'position','')) like '%فني%' then 'فريق الصيانة'
        else 'دون توزيع'
      end work_location,
      coalesce(to_jsonb(aj.project_ids),'[]'::jsonb) project_ids,
      coalesce(to_jsonb(aj.project_names),'[]'::jsonb) project_names,
      coalesce(aj.assignment_details,'[]'::jsonb) assignment_details,
      coalesce(aj.multiple_supervisors,false) multiple_supervisors,
      sd.service_start,
      at.first_attendance_date,
      sd.service_end,
      (sd.service_end-sd.service_start+1)::int month_days,
      (sd.service_end-sd.service_start+1)::int work_days,
      coalesce(ra.required_work_days,0) required_work_days,
      coalesce(at.present_days,0) present_days,
      greatest(coalesce(ra.required_work_days,0)-coalesce(at.present_days,0),0)::int absent_days,
      (sd.service_end-sd.service_start+1)::int due_days,
      coalesce(ra.required_minutes,0) required_minutes,
      0::numeric actual_minutes,
      coalesce(nullif(e.j->>'basic_salary','')::numeric,nullif(e.j->>'base_salary','')::numeric,nullif(e.j->>'salary','')::numeric,0) base_salary,
      coalesce(nullif(e.j->>'allowances','')::numeric,nullif(e.j->>'allowance','')::numeric,0)+coalesce(ad.allowances,0) allowances,
      coalesce(ad.commissions,0) commissions,
      coalesce(ad.advances,0) advances,
      coalesce(ad.deductions,0) other_deductions,
      0::numeric rounding,
      coalesce(at.attendance_days,'[]'::jsonb) details
    from employees e
    left join primary_supervisor ps using(canonical_employee_id)
    left join assignment_json aj using(canonical_employee_id)
    left join attendance_agg at using(canonical_employee_id)
    left join service_dates sd using(canonical_employee_id)
    left join required_agg ra using(canonical_employee_id)
    left join adjustments ad using(canonical_employee_id)
  ),
  final_rows as (
    select pr.*,
      (pr.base_salary+pr.allowances) gross_salary,
      ((pr.base_salary+pr.allowances)/30.0*pr.due_days) period_salary,
      case when pr.first_attendance_date is null then 0 else (pr.base_salary/30.0*pr.absent_days) end absence_deduction,
      (pr.other_deductions + case when pr.first_attendance_date is null then 0 else (pr.base_salary/30.0*pr.absent_days) end) deductions,
      (((pr.base_salary+pr.allowances)/30.0*pr.due_days)+pr.commissions+pr.rounding-pr.other_deductions-pr.advances-
        case when pr.first_attendance_date is null then 0 else (pr.base_salary/30.0*pr.absent_days) end) net_salary,
      case when pr.first_attendance_date is null then 'يحتاج مراجعة' when pr.base_salary=0 then 'يحتاج مراجعة' else 'مسودة' end status,
      case when pr.first_attendance_date is null then jsonb_build_array('الحضور غير مكتمل')
           when pr.base_salary=0 then jsonb_build_array('الراتب الأساسي غير مسجل') else '[]'::jsonb end issues,
      ''::text notes
    from payroll_rows pr
  ),
  duplicate_check as (
    select fr.canonical_employee_id,count(*) as n from final_rows fr group by fr.canonical_employee_id having count(*)>1
  ),
  supervisor_counts as (
    select coalesce(fr.supervisor_id,'none') as supervisor_id, max(fr.supervisor_name) as supervisor_name,
           count(distinct fr.canonical_employee_id)::int as payroll_workers
    from final_rows fr group by coalesce(fr.supervisor_id,'none')
  ),
  diagnostics as (
    select jsonb_build_object(
      'period_start',v_start,'period_end',v_end,
      'raw_employee_records',(select count(*) from employee_source),
      'raw_assignments',(select count(*) from assignments_raw),
      'raw_attendance_records',(select count(*) from attendance_raw ar_diag where ar_diag.attendance_date between v_start and v_end),
      'canonical_employee_ids',(select count(*) from employees),
      'duplicate_ids_found',(select count(*) from duplicate_check),
      'stopped_employees_removed',(select se.n from stopped_employees se),
      'stopped_supervisors_removed',(select ssr.n from stopped_supervisor_refs ssr),
      'final_payroll_rows',(select count(*) from final_rows),
      'supervisor_counts',coalesce((select jsonb_agg(to_jsonb(sc)) from supervisor_counts sc),'[]'::jsonb)
    ) j
  )
  select jsonb_build_object(
    'rows',coalesce((select jsonb_agg(to_jsonb(fr) order by fr.supervisor_name,fr.job_title,fr.employee_code) from final_rows fr),'[]'::jsonb),
    'projects',coalesce((select jsonb_agg(jsonb_build_object('id',pr.project_id,'name',pr.project_name,'operation_type',pr.operation_type)) from projects pr),'[]'::jsonb),
    'diagnostics',(select d.j from diagnostics d),
    'incomplete',false
  ) into v_result;

  v_duplicates := coalesce((v_result->'diagnostics'->>'duplicate_ids_found')::int,0);
  if v_duplicates <> 0 then
    raise exception 'Duplicate payroll employees detected';
  end if;
  if coalesce((v_result->'diagnostics'->>'final_payroll_rows')::int,0)
     <> coalesce((v_result->'diagnostics'->>'canonical_employee_ids')::int,0) then
    raise exception 'Payroll row count does not match canonical employees';
  end if;

  return v_result;
end;
$$;

grant execute on function public.get_unified_payroll_from_server(text) to anon, authenticated;


-- Apply V477 payroll server data fix separately: supabase_payroll_server_data_fix_v477.sql


-- ===== Payroll server V478 =====
-- V478 final payroll identity dedupe + include guards, technicians and supervisors
-- V477 fixes real server schema: active null migration logic, attendance rows without check_in, names from distribution fallback
-- V476 hotfix: qualify JSON payload aliases in joined CTEs; fixes column reference "j" is ambiguous
-- V474: مصدر الرواتب الوحيد من السيرفر. لا دمج أو fallback داخل الواجهة.
create or replace function public.get_unified_payroll_from_server(p_month text)
returns jsonb
language plpgsql
security invoker
set search_path = public
as $$
#variable_conflict use_column
declare
  v_start date;
  v_end date;
  v_result jsonb;
  v_duplicates integer;
begin
  if p_month is null or p_month !~ '^\d{4}-\d{2}$' then
    raise exception 'Invalid payroll month: %', p_month;
  end if;

  v_start := (p_month || '-01')::date;
  v_end := (v_start + interval '1 month - 1 day')::date;

  with
  employee_source as (
    select 1::int as source_priority, 'employees_master_v386'::text as source_table, to_jsonb(e) as j
    from public.employees_master_v386 e
    union all
    select 2::int, 'workers'::text, to_jsonb(w)
    from public.workers w
    union all
    select 3::int, 'app_users'::text, to_jsonb(u)
    from public.app_users u
    where lower(coalesce(to_jsonb(u)->>'role',to_jsonb(u)->>'job_title',to_jsonb(u)->>'position','')) ~ '(supervisor|technician|guard|مشرف|فني|حارس|امن|صيانة)'
  ),
  employee_normalized as (
    select
      es.source_priority, es.source_table, es.j,
      coalesce(
        case when length(regexp_replace(coalesce(es.j->>'iqama_number',es.j->>'residency_number',es.j->>'national_id',''),'\D','','g')) >= 6
             then 'iqama:'||regexp_replace(coalesce(es.j->>'iqama_number',es.j->>'residency_number',es.j->>'national_id',''),'\D','','g') end,
        case when coalesce(nullif(es.j->>'employee_code',''),nullif(es.j->>'worker_code',''),nullif(es.j->>'employee_ts_id',''),nullif(es.j->>'code','')) is not null
             then 'code:'||lower(coalesce(nullif(es.j->>'employee_code',''),nullif(es.j->>'worker_code',''),nullif(es.j->>'employee_ts_id',''),nullif(es.j->>'code',''))) end,
        'id:'||es.source_table||':'||coalesce(nullif(es.j->>'employee_id',''),nullif(es.j->>'worker_id',''),nullif(es.j->>'staff_id',''),nullif(es.j->>'person_id',''),nullif(es.j->>'id',''))
      ) as identity_key,
      array_remove(array[
        nullif(es.j->>'id',''), nullif(es.j->>'employee_id',''), nullif(es.j->>'worker_id',''), nullif(es.j->>'staff_id',''), nullif(es.j->>'person_id',''),
        nullif(es.j->>'employee_code',''), nullif(es.j->>'worker_code',''), nullif(es.j->>'employee_ts_id',''), nullif(es.j->>'code',''),
        nullif(es.j->>'username','')
      ], null) as row_aliases
    from employee_source es
    where coalesce(nullif(es.j->>'employee_id',''),nullif(es.j->>'worker_id',''),nullif(es.j->>'staff_id',''),nullif(es.j->>'person_id',''),nullif(es.j->>'id',''),nullif(es.j->>'employee_code',''),nullif(es.j->>'worker_code',''),nullif(es.j->>'employee_ts_id',''),nullif(es.j->>'code','')) is not null
  ),
  employees_all as (
    select
      en.identity_key as canonical_employee_id,
      array_agg(distinct a.alias) filter(where a.alias is not null) as aliases,
      (array_agg(en.j order by en.source_priority))[1] as j,
      count(*)::int as merged_profile_count
    from employee_normalized en
    left join lateral unnest(en.row_aliases) a(alias) on true
    group by en.identity_key
  ),
  employees as (
    select *
    from employees_all
    where canonical_employee_id is not null
      and coalesce(lower(j->>'is_active'), case when coalesce(lower(j->>'status'),'active') in ('active','نشط','working','enabled','فعال') then 'true' else 'false' end) = 'true'
      and coalesce(lower(j->>'status'),'active') not in ('inactive','stopped','terminated','disabled','موقوف','متوقف','منتهي')
      and coalesce(lower(j->>'is_deleted'),'false') <> 'true'
  ),
  stopped_employees as (
    select count(*)::int n from employees_all
    where canonical_employee_id is not null
      and not (
        coalesce(lower(j->>'is_active'),'false') = 'true'
        and coalesce(lower(j->>'status'),'active') not in ('inactive','stopped','terminated','disabled','موقوف','متوقف','منتهي')
      )
  ),
  project_source as (
    select to_jsonb(p) j from public.projects p
  ),
  projects as (
    select
      coalesce(nullif(j->>'id',''),nullif(j->>'project_id','')) project_id,
      coalesce(nullif(j->>'name',''),nullif(j->>'project_name',''),nullif(j->>'title',''),'مشروع') project_name,
      coalesce(nullif(j->>'operation_type',''),nullif(j->>'project_type',''),'') operation_type,
      coalesce(nullif(j->>'required_daily_minutes','')::numeric,540) required_daily_minutes,
      coalesce(nullif(j->>'friday_minutes','')::numeric,0) friday_minutes,
      j
    from project_source
    where coalesce(lower(j->>'is_active'),'false')='true'
      and coalesce(lower(j->>'status'),'active') not in ('inactive','stopped','terminated','disabled','موقوف','متوقف','منتهي')
  ),
  distribution_source as (
    select to_jsonb(d) j from public.monthly_distribution d
  ),
  assignments_raw as (
    select
      coalesce(nullif(j->>'worker_employee_code',''),nullif(j->>'employee_id',''),nullif(j->>'worker_id',''),nullif(j->>'staff_id',''),nullif(j->>'person_id','')) worker_ref,
      coalesce(nullif(j->>'supervisor_employee_code',''),nullif(j->>'supervisor_id','')) supervisor_ref,
      nullif(j->>'supervisor_name','') supervisor_name_raw,
      coalesce(nullif(j->>'project_id',''),nullif(j->>'project_code','')) project_ref,
      nullif(j->>'project_name','') project_name_raw,
      greatest(coalesce(nullif(j->>'start_date','')::date,v_start),v_start) assignment_start,
      least(coalesce(nullif(j->>'end_date','')::date,v_end),v_end) assignment_end,
      j
    from distribution_source
    where (
      j->>'month_key' = p_month
      or (
        coalesce(nullif(j->>'start_date','')::date,v_start) <= v_end
        and coalesce(nullif(j->>'end_date','')::date,v_end) >= v_start
      )
    )
      and coalesce(lower(j->>'status'),'active') not in ('deleted','cancelled','ملغي','محذوف')
  ),
  assignments_linked as (
    select distinct on (e.canonical_employee_id, ar.project_ref, ar.supervisor_ref, ar.assignment_start, ar.assignment_end)
      e.canonical_employee_id,
      ar.supervisor_ref, ar.supervisor_name_raw,
      ar.project_ref, ar.project_name_raw,
      ar.assignment_start,
      ar.assignment_end,
      greatest((ar.assignment_end-ar.assignment_start)+1,0)::int overlap_days,
      ar.j
    from assignments_raw ar
    join employees e on ar.worker_ref = any(e.aliases)
    where ar.assignment_start <= ar.assignment_end
    order by e.canonical_employee_id, ar.project_ref, ar.supervisor_ref, ar.assignment_start, ar.assignment_end
  ),
  supervisors as (
    select
      canonical_employee_id supervisor_id,
      coalesce(nullif(j->>'app_name',''),nullif(j->>'display_name',''),nullif(j->>'name',''),nullif(j->>'full_name',''),nullif(j->>'employee_name',''),'مشرف') supervisor_name,
      aliases,
      j
    from employees
    where lower(coalesce(j->>'job_title',j->>'position',j->>'role',j->>'employee_type','')) like '%مشرف%'
       or lower(coalesce(j->>'job_title',j->>'position',j->>'role',j->>'employee_type','')) like '%supervisor%'
  ),
  stopped_supervisor_refs as (
    select count(*)::int n
    from assignments_linked a
    where a.supervisor_ref is not null
      and not exists(select 1 from supervisors s where a.supervisor_ref=any(s.aliases))
  ),
  assignments_enriched as (
    select
      a.canonical_employee_id,
      s.supervisor_id,
      coalesce(s.supervisor_name,a.supervisor_name_raw) supervisor_name,
      coalesce(p.project_id,a.project_ref) project_id,
      coalesce(p.project_name,a.project_name_raw) project_name,
      p.operation_type,
      p.required_daily_minutes,
      p.friday_minutes,
      a.assignment_start,
      a.assignment_end,
      a.overlap_days
    from assignments_linked a
    left join supervisors s on a.supervisor_ref=any(s.aliases)
    left join projects p on a.project_ref=p.project_id
    where a.project_ref is null or p.project_id is not null or a.project_name_raw is not null
  ),
  supervisor_days as (
    select ae.canonical_employee_id, ae.supervisor_id, max(ae.supervisor_name) as supervisor_name,
           sum(ae.overlap_days)::int as supervisor_days, max(ae.assignment_start) as latest_start
    from assignments_enriched ae
    where ae.supervisor_id is not null
    group by ae.canonical_employee_id, ae.supervisor_id
  ),
  primary_supervisor as (
    select ranked.canonical_employee_id, ranked.supervisor_id, ranked.supervisor_name, ranked.supervisor_days
    from (
      select sd.*, row_number() over(partition by canonical_employee_id order by supervisor_days desc, latest_start desc, supervisor_id) rn
      from supervisor_days sd
    ) ranked where ranked.rn=1
  ),
  attendance_source as (
    select to_jsonb(a) j from public.attendance a
  ),
  attendance_raw as (
    select
      coalesce(nullif(j->>'employee_id',''),nullif(j->>'worker_id',''),nullif(j->>'staff_id',''),nullif(j->>'person_id',''),nullif(j->>'user_id','')) employee_ref,
      coalesce(nullif(j->>'attendance_date','')::date,nullif(j->>'date','')::date,(nullif(j->>'created_at',''))::timestamptz::date) attendance_date,
      coalesce(nullif(j->>'check_in',''),nullif(j->>'in_time',''),nullif(j->>'start_time',''),nullif(j->>'login_time','')) check_in,
      coalesce(nullif(j->>'check_out',''),nullif(j->>'out_time',''),nullif(j->>'end_time',''),nullif(j->>'logout_time','')) check_out,
      j
    from attendance_source
  ),
  attendance_linked as (
    select e.canonical_employee_id, ar.attendance_date,
           min(ar.check_in) check_in, max(ar.check_out) check_out
    from attendance_raw ar
    join employees e on ar.employee_ref=any(e.aliases)
    where ar.attendance_date between v_start and v_end
            and coalesce(lower(ar.j->>'status'),'present') not in ('cancelled','rejected','failed','ملغي','مرفوض','غير معتمد')
      and coalesce(lower(ar.j->>'is_cancelled'),'false') <> 'true'
      and coalesce(lower(ar.j->>'is_deleted'),'false') <> 'true'
      and coalesce(lower(ar.j->>'is_approved'),'true') = 'true'
    group by e.canonical_employee_id, ar.attendance_date
  ),
  attendance_agg as (
    select al.canonical_employee_id, min(al.attendance_date) as first_attendance_date,
           count(*)::int as present_days,
           jsonb_agg(jsonb_build_object('date',al.attendance_date,'check_in',al.check_in,'check_out',al.check_out) order by al.attendance_date) as attendance_days
    from attendance_linked al group by al.canonical_employee_id
  ),
  service_dates as (
    select e.canonical_employee_id,
      greatest(v_start,
        coalesce(nullif(e.j->>'work_start_date','')::date,nullif(e.j->>'hire_date','')::date,nullif(e.j->>'joining_date','')::date,v_start),
        coalesce((select min(a.assignment_start) from assignments_enriched a where a.canonical_employee_id=e.canonical_employee_id),v_start),
        coalesce(at.first_attendance_date,v_start)
      ) service_start,
      least(v_end,coalesce(nullif(e.j->>'work_end_date','')::date,nullif(e.j->>'termination_date','')::date,nullif(e.j->>'stop_date','')::date,v_end)) service_end
    from employees e left join attendance_agg at using(canonical_employee_id)
  ),
  required_calendar as (
    select sd.canonical_employee_id, g.d::date work_date,
      case
        when extract(isodow from g.d)=5 then coalesce((
          select max(a.friday_minutes) from assignments_enriched a
          where a.canonical_employee_id=sd.canonical_employee_id and g.d::date between a.assignment_start and a.assignment_end
        ),0)
        else coalesce((
          select max(a.required_daily_minutes) from assignments_enriched a
          where a.canonical_employee_id=sd.canonical_employee_id and g.d::date between a.assignment_start and a.assignment_end
        ),540)
      end required_minutes
    from service_dates sd
    cross join lateral generate_series(sd.service_start,sd.service_end,interval '1 day') g(d)
    where sd.service_start<=sd.service_end
  ),
  required_agg as (
    select rc.canonical_employee_id,
      count(*) filter(where rc.required_minutes>0)::int as required_work_days,
      coalesce(sum(rc.required_minutes),0)::numeric as required_minutes
    from required_calendar rc group by rc.canonical_employee_id
  ),
  adjustment_source as (
    select to_jsonb(pa) j from public.payroll_adjustments pa
    where pa.effective_date between v_start and v_end and coalesce(pa.is_deleted,false)=false
  ),
  adjustments as (
    select e.canonical_employee_id,
      coalesce(sum((x.j->>'amount')::numeric) filter(where lower(x.j->>'adjustment_type') in ('allowance','بدل','بدلات')),0) allowances,
      coalesce(sum((x.j->>'amount')::numeric) filter(where lower(x.j->>'adjustment_type') in ('commission','bonus','حافز','عمولة')),0) commissions,
      coalesce(sum((x.j->>'amount')::numeric) filter(where lower(x.j->>'adjustment_type') in ('advance','سلفة')),0) advances,
      coalesce(sum((x.j->>'amount')::numeric) filter(where lower(x.j->>'adjustment_type') in ('deduction','خصم','جزاء')),0) deductions
    from adjustment_source x
    join employees e on coalesce(nullif(x.j->>'employee_id',''),nullif(x.j->>'worker_id',''))=any(e.aliases)
    where coalesce(lower(x.j->>'status'),'approved') in ('approved','معتمد')
    group by e.canonical_employee_id
  ),
  assignment_json as (
    select canonical_employee_id,
      jsonb_agg(jsonb_build_object(
        'project_id',project_id,'project_name',project_name,'supervisor_id',supervisor_id,'supervisor_name',supervisor_name,
        'start',assignment_start,'end',assignment_end,'days',overlap_days,'operation_type',operation_type
      ) order by assignment_start) assignment_details,
      array_agg(distinct project_id) filter(where project_id is not null) project_ids,
      array_agg(distinct project_name) filter(where project_name is not null) project_names,
      count(distinct supervisor_id) filter(where supervisor_id is not null)>1 multiple_supervisors
    from assignments_enriched group by canonical_employee_id
  ),
  payroll_rows as (
    select
      e.canonical_employee_id,
      e.canonical_employee_id worker_id,
      coalesce(nullif(e.j->>'employee_code',''),nullif(e.j->>'worker_code',''),nullif(e.j->>'employee_ts_id',''),nullif(e.j->>'code',''),e.canonical_employee_id) employee_code,
      p_month AS "month",
      coalesce(nullif(e.j->>'iqama_name',''),nullif(e.j->>'residency_name',''),nullif(e.j->>'official_name',''),nullif(e.j->>'full_name',''),nullif(e.j->>'name',''),'موظف') residency_name,
      coalesce(nullif(e.j->>'app_name',''),nullif(e.j->>'display_name',''),nullif(e.j->>'name',''),nullif(e.j->>'full_name',''),'موظف') worker_name,
      coalesce(nullif(e.j->>'iqama_number',''),nullif(e.j->>'residency_number',''),nullif(e.j->>'national_id',''),'') iqama_number,
      case
        when lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'employee_type',e.j->>'job_type',e.j->>'role','')) ~ '(supervisor|مشرف)' then 'مشرف'
        when lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'employee_type',e.j->>'job_type',e.j->>'role','')) ~ '(technician|فني|صيانة)' then 'فني'
        when lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'employee_type',e.j->>'job_type',e.j->>'role','')) ~ '(guard|حارس|امن)' then 'حارس'
        else coalesce(nullif(e.j->>'job_title',''),nullif(e.j->>'position',''),nullif(e.j->>'employee_type',''),nullif(e.j->>'job_type',''),nullif(e.j->>'role',''),'عامل')
      end job_title,
      ps.supervisor_id,
      coalesce(ps.supervisor_name,'دون مشرف نشط') supervisor_name,
      case
        when coalesce(array_length(aj.project_names,1),0)>1 then 'متعدد'
        when coalesce(array_length(aj.project_names,1),0)=1 then
          case when exists(select 1 from assignments_enriched ae where ae.canonical_employee_id=e.canonical_employee_id and lower(ae.operation_type) in ('daily_visit','زيارة يومية'))
               then coalesce(ps.supervisor_name,'دون مشرف نشط') else aj.project_names[1] end
        when lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'role','')) ~ '(فني|technician|صيانة)' then 'فريق الصيانة'
        when lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'role','')) ~ '(مشرف|supervisor)' then 'إدارة التشغيل'
        when lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'role','')) ~ '(حارس|guard|امن)' then 'دون توزيع حراسة'
        else 'دون توزيع'
      end work_location,
      coalesce(to_jsonb(aj.project_ids),'[]'::jsonb) project_ids,
      coalesce(to_jsonb(aj.project_names),'[]'::jsonb) project_names,
      coalesce(aj.assignment_details,'[]'::jsonb) assignment_details,
      coalesce(aj.multiple_supervisors,false) multiple_supervisors,
      sd.service_start,
      at.first_attendance_date,
      sd.service_end,
      (sd.service_end-sd.service_start+1)::int month_days,
      (sd.service_end-sd.service_start+1)::int work_days,
      coalesce(ra.required_work_days,0) required_work_days,
      coalesce(at.present_days,0) present_days,
      greatest(coalesce(ra.required_work_days,0)-coalesce(at.present_days,0),0)::int absent_days,
      (sd.service_end-sd.service_start+1)::int due_days,
      coalesce(ra.required_minutes,0) required_minutes,
      0::numeric actual_minutes,
      coalesce(nullif(e.j->>'basic_salary','')::numeric,nullif(e.j->>'base_salary','')::numeric,nullif(e.j->>'salary','')::numeric,0) base_salary,
      coalesce(nullif(e.j->>'allowances','')::numeric,nullif(e.j->>'allowance','')::numeric,0)+coalesce(ad.allowances,0) allowances,
      coalesce(ad.commissions,0) commissions,
      coalesce(ad.advances,0) advances,
      coalesce(ad.deductions,0) other_deductions,
      0::numeric rounding,
      coalesce(at.attendance_days,'[]'::jsonb) details
    from employees e
    left join primary_supervisor ps using(canonical_employee_id)
    left join assignment_json aj using(canonical_employee_id)
    left join attendance_agg at using(canonical_employee_id)
    left join service_dates sd using(canonical_employee_id)
    left join required_agg ra using(canonical_employee_id)
    left join adjustments ad using(canonical_employee_id)
  ),
  final_rows as (
    select pr.*,
      (pr.base_salary+pr.allowances) gross_salary,
      ((pr.base_salary+pr.allowances)/30.0*pr.due_days) period_salary,
      case when pr.first_attendance_date is null then 0 else (pr.base_salary/30.0*pr.absent_days) end absence_deduction,
      (pr.other_deductions + case when pr.first_attendance_date is null then 0 else (pr.base_salary/30.0*pr.absent_days) end) deductions,
      (((pr.base_salary+pr.allowances)/30.0*pr.due_days)+pr.commissions+pr.rounding-pr.other_deductions-pr.advances-
        case when pr.first_attendance_date is null then 0 else (pr.base_salary/30.0*pr.absent_days) end) net_salary,
      case when pr.first_attendance_date is null then 'يحتاج مراجعة' when pr.base_salary=0 then 'يحتاج مراجعة' else 'مسودة' end status,
      case when pr.first_attendance_date is null then jsonb_build_array('الحضور غير مكتمل')
           when pr.base_salary=0 then jsonb_build_array('الراتب الأساسي غير مسجل') else '[]'::jsonb end issues,
      ''::text notes
    from payroll_rows pr
  ),
  duplicate_check as (
    select fr.canonical_employee_id,count(*) as n from final_rows fr group by fr.canonical_employee_id having count(*)>1
  ),
  supervisor_counts as (
    select coalesce(fr.supervisor_id,'none') as supervisor_id, max(fr.supervisor_name) as supervisor_name,
           count(distinct fr.canonical_employee_id)::int as payroll_workers
    from final_rows fr group by coalesce(fr.supervisor_id,'none')
  ),
  diagnostics as (
    select jsonb_build_object(
      'period_start',v_start,'period_end',v_end,
      'raw_employee_records',(select count(*) from employee_source),
      'raw_assignments',(select count(*) from assignments_raw),
      'raw_attendance_records',(select count(*) from attendance_raw ar_diag where ar_diag.attendance_date between v_start and v_end),
      'canonical_employee_ids',(select count(*) from employees),
      'merged_duplicate_profiles',(select coalesce(sum(greatest(merged_profile_count-1,0)),0)::int from employees_all),
      'workers_count',(select count(*) from employees e where lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'employee_type',e.j->>'job_type',e.j->>'role','عامل')) !~ '(supervisor|technician|guard|مشرف|فني|حارس|امن|صيانة)'),
      'guards_count',(select count(*) from employees e where lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'employee_type',e.j->>'job_type',e.j->>'role','')) ~ '(guard|حارس|امن)'),
      'technicians_count',(select count(*) from employees e where lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'employee_type',e.j->>'job_type',e.j->>'role','')) ~ '(technician|فني|صيانة)'),
      'supervisors_count',(select count(*) from employees e where lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'employee_type',e.j->>'job_type',e.j->>'role','')) ~ '(supervisor|مشرف)'),
      'duplicate_ids_found',(select count(*) from duplicate_check),
      'stopped_employees_removed',(select se.n from stopped_employees se),
      'stopped_supervisors_removed',(select ssr.n from stopped_supervisor_refs ssr),
      'final_payroll_rows',(select count(*) from final_rows),
      'supervisor_counts',coalesce((select jsonb_agg(to_jsonb(sc)) from supervisor_counts sc),'[]'::jsonb)
    ) j
  )
  select jsonb_build_object(
    'rows',coalesce((select jsonb_agg(to_jsonb(fr) order by fr.supervisor_name,fr.job_title,fr.employee_code) from final_rows fr),'[]'::jsonb),
    'projects',coalesce((select jsonb_agg(jsonb_build_object('id',pr.project_id,'name',pr.project_name,'operation_type',pr.operation_type)) from projects pr),'[]'::jsonb),
    'diagnostics',(select d.j from diagnostics d),
    'incomplete',false
  ) into v_result;

  v_duplicates := coalesce((v_result->'diagnostics'->>'duplicate_ids_found')::int,0);
  if v_duplicates <> 0 then
    raise exception 'Duplicate payroll employees detected';
  end if;
  if coalesce((v_result->'diagnostics'->>'final_payroll_rows')::int,0)
     <> coalesce((v_result->'diagnostics'->>'canonical_employee_ids')::int,0) then
    raise exception 'Payroll row count does not match canonical employees';
  end if;

  return v_result;
end;
$$;

grant execute on function public.get_unified_payroll_from_server(text) to anon, authenticated;


-- ===== Payroll server timeout fix V479 =====
-- V479 performance indexes for payroll server reads
create index if not exists idx_monthly_distribution_month_key_v479
  on public.monthly_distribution (month_key);
create index if not exists idx_attendance_attendance_date_v479
  on public.attendance (attendance_date);
create index if not exists idx_payroll_adjustments_effective_date_v479
  on public.payroll_adjustments (effective_date);

-- V479 payroll server timeout fix: pre-filter monthly sources, indexed reads, and set-based calendar calculation
-- V477 fixes real server schema: active null migration logic, attendance rows without check_in, names from distribution fallback
-- V476 hotfix: qualify JSON payload aliases in joined CTEs; fixes column reference "j" is ambiguous
-- V474: مصدر الرواتب الوحيد من السيرفر. لا دمج أو fallback داخل الواجهة.
create or replace function public.get_unified_payroll_from_server(p_month text)
returns jsonb
language plpgsql
security invoker
set search_path = public
set statement_timeout = '120s'
as $$
#variable_conflict use_column
declare
  v_start date;
  v_end date;
  v_result jsonb;
  v_duplicates integer;
begin
  if p_month is null or p_month !~ '^\d{4}-\d{2}$' then
    raise exception 'Invalid payroll month: %', p_month;
  end if;

  v_start := (p_month || '-01')::date;
  v_end := (v_start + interval '1 month - 1 day')::date;

  with
  employee_source as (
    select 1::int as source_priority, 'employees_master_v386'::text as source_table, to_jsonb(e) as j
    from public.employees_master_v386 e
    union all
    select 2::int, 'workers'::text, to_jsonb(w)
    from public.workers w
    union all
    select 3::int, 'app_users'::text, to_jsonb(u)
    from public.app_users u
    where lower(coalesce(to_jsonb(u)->>'role',to_jsonb(u)->>'job_title',to_jsonb(u)->>'position','')) ~ '(supervisor|technician|guard|مشرف|فني|حارس|امن|صيانة)'
  ),
  employee_normalized as (
    select
      es.source_priority, es.source_table, es.j,
      coalesce(
        case when length(regexp_replace(coalesce(es.j->>'iqama_number',es.j->>'residency_number',es.j->>'national_id',''),'\D','','g')) >= 6
             then 'iqama:'||regexp_replace(coalesce(es.j->>'iqama_number',es.j->>'residency_number',es.j->>'national_id',''),'\D','','g') end,
        case when coalesce(nullif(es.j->>'employee_code',''),nullif(es.j->>'worker_code',''),nullif(es.j->>'employee_ts_id',''),nullif(es.j->>'code','')) is not null
             then 'code:'||lower(coalesce(nullif(es.j->>'employee_code',''),nullif(es.j->>'worker_code',''),nullif(es.j->>'employee_ts_id',''),nullif(es.j->>'code',''))) end,
        'id:'||es.source_table||':'||coalesce(nullif(es.j->>'employee_id',''),nullif(es.j->>'worker_id',''),nullif(es.j->>'staff_id',''),nullif(es.j->>'person_id',''),nullif(es.j->>'id',''))
      ) as identity_key,
      array_remove(array[
        nullif(es.j->>'id',''), nullif(es.j->>'employee_id',''), nullif(es.j->>'worker_id',''), nullif(es.j->>'staff_id',''), nullif(es.j->>'person_id',''),
        nullif(es.j->>'employee_code',''), nullif(es.j->>'worker_code',''), nullif(es.j->>'employee_ts_id',''), nullif(es.j->>'code',''),
        nullif(es.j->>'username','')
      ], null) as row_aliases
    from employee_source es
    where coalesce(nullif(es.j->>'employee_id',''),nullif(es.j->>'worker_id',''),nullif(es.j->>'staff_id',''),nullif(es.j->>'person_id',''),nullif(es.j->>'id',''),nullif(es.j->>'employee_code',''),nullif(es.j->>'worker_code',''),nullif(es.j->>'employee_ts_id',''),nullif(es.j->>'code','')) is not null
  ),
  employees_all as (
    select
      en.identity_key as canonical_employee_id,
      array_agg(distinct a.alias) filter(where a.alias is not null) as aliases,
      (array_agg(en.j order by en.source_priority))[1] as j,
      count(*)::int as merged_profile_count
    from employee_normalized en
    left join lateral unnest(en.row_aliases) a(alias) on true
    group by en.identity_key
  ),
  employees as (
    select *
    from employees_all
    where canonical_employee_id is not null
      and coalesce(lower(j->>'is_active'), case when coalesce(lower(j->>'status'),'active') in ('active','نشط','working','enabled','فعال') then 'true' else 'false' end) = 'true'
      and coalesce(lower(j->>'status'),'active') not in ('inactive','stopped','terminated','disabled','موقوف','متوقف','منتهي')
      and coalesce(lower(j->>'is_deleted'),'false') <> 'true'
  ),
  stopped_employees as (
    select count(*)::int n from employees_all
    where canonical_employee_id is not null
      and not (
        coalesce(lower(j->>'is_active'),'false') = 'true'
        and coalesce(lower(j->>'status'),'active') not in ('inactive','stopped','terminated','disabled','موقوف','متوقف','منتهي')
      )
  ),
  project_source as (
    select to_jsonb(p) j from public.projects p
  ),
  projects as (
    select
      coalesce(nullif(j->>'id',''),nullif(j->>'project_id','')) project_id,
      coalesce(nullif(j->>'name',''),nullif(j->>'project_name',''),nullif(j->>'title',''),'مشروع') project_name,
      coalesce(nullif(j->>'operation_type',''),nullif(j->>'project_type',''),'') operation_type,
      coalesce(nullif(j->>'required_daily_minutes','')::numeric,540) required_daily_minutes,
      coalesce(nullif(j->>'friday_minutes','')::numeric,0) friday_minutes,
      j
    from project_source
    where coalesce(lower(j->>'is_active'),'false')='true'
      and coalesce(lower(j->>'status'),'active') not in ('inactive','stopped','terminated','disabled','موقوف','متوقف','منتهي')
  ),
  distribution_source as (
    select to_jsonb(d) j
    from public.monthly_distribution d
    where d.month_key = p_month
  ),
  assignments_raw as (
    select
      coalesce(nullif(j->>'worker_employee_code',''),nullif(j->>'employee_id',''),nullif(j->>'worker_id',''),nullif(j->>'staff_id',''),nullif(j->>'person_id','')) worker_ref,
      coalesce(nullif(j->>'supervisor_employee_code',''),nullif(j->>'supervisor_id','')) supervisor_ref,
      nullif(j->>'supervisor_name','') supervisor_name_raw,
      coalesce(nullif(j->>'project_id',''),nullif(j->>'project_code','')) project_ref,
      nullif(j->>'project_name','') project_name_raw,
      greatest(coalesce(nullif(j->>'start_date','')::date,v_start),v_start) assignment_start,
      least(coalesce(nullif(j->>'end_date','')::date,v_end),v_end) assignment_end,
      j
    from distribution_source
    where (
      j->>'month_key' = p_month
      or (
        coalesce(nullif(j->>'start_date','')::date,v_start) <= v_end
        and coalesce(nullif(j->>'end_date','')::date,v_end) >= v_start
      )
    )
      and coalesce(lower(j->>'status'),'active') not in ('deleted','cancelled','ملغي','محذوف')
  ),
  assignments_linked as (
    select distinct on (e.canonical_employee_id, ar.project_ref, ar.supervisor_ref, ar.assignment_start, ar.assignment_end)
      e.canonical_employee_id,
      ar.supervisor_ref, ar.supervisor_name_raw,
      ar.project_ref, ar.project_name_raw,
      ar.assignment_start,
      ar.assignment_end,
      greatest((ar.assignment_end-ar.assignment_start)+1,0)::int overlap_days,
      ar.j
    from assignments_raw ar
    join employees e on ar.worker_ref = any(e.aliases)
    where ar.assignment_start <= ar.assignment_end
    order by e.canonical_employee_id, ar.project_ref, ar.supervisor_ref, ar.assignment_start, ar.assignment_end
  ),
  supervisors as (
    select
      canonical_employee_id supervisor_id,
      coalesce(nullif(j->>'app_name',''),nullif(j->>'display_name',''),nullif(j->>'name',''),nullif(j->>'full_name',''),nullif(j->>'employee_name',''),'مشرف') supervisor_name,
      aliases,
      j
    from employees
    where lower(coalesce(j->>'job_title',j->>'position',j->>'role',j->>'employee_type','')) like '%مشرف%'
       or lower(coalesce(j->>'job_title',j->>'position',j->>'role',j->>'employee_type','')) like '%supervisor%'
  ),
  stopped_supervisor_refs as (
    select count(*)::int n
    from assignments_linked a
    where a.supervisor_ref is not null
      and not exists(select 1 from supervisors s where a.supervisor_ref=any(s.aliases))
  ),
  assignments_enriched as (
    select
      a.canonical_employee_id,
      s.supervisor_id,
      coalesce(s.supervisor_name,a.supervisor_name_raw) supervisor_name,
      coalesce(p.project_id,a.project_ref) project_id,
      coalesce(p.project_name,a.project_name_raw) project_name,
      p.operation_type,
      p.required_daily_minutes,
      p.friday_minutes,
      a.assignment_start,
      a.assignment_end,
      a.overlap_days
    from assignments_linked a
    left join supervisors s on a.supervisor_ref=any(s.aliases)
    left join projects p on a.project_ref=p.project_id
    where a.project_ref is null or p.project_id is not null or a.project_name_raw is not null
  ),
  supervisor_days as (
    select ae.canonical_employee_id, ae.supervisor_id, max(ae.supervisor_name) as supervisor_name,
           sum(ae.overlap_days)::int as supervisor_days, max(ae.assignment_start) as latest_start
    from assignments_enriched ae
    where ae.supervisor_id is not null
    group by ae.canonical_employee_id, ae.supervisor_id
  ),
  primary_supervisor as (
    select ranked.canonical_employee_id, ranked.supervisor_id, ranked.supervisor_name, ranked.supervisor_days
    from (
      select sd.*, row_number() over(partition by canonical_employee_id order by supervisor_days desc, latest_start desc, supervisor_id) rn
      from supervisor_days sd
    ) ranked where ranked.rn=1
  ),
  attendance_source as (
    select to_jsonb(a) j
    from public.attendance a
    where a.attendance_date >= v_start
      and a.attendance_date < (v_end + 1)
  ),
  attendance_raw as (
    select
      coalesce(nullif(j->>'employee_id',''),nullif(j->>'worker_id',''),nullif(j->>'staff_id',''),nullif(j->>'person_id',''),nullif(j->>'user_id','')) employee_ref,
      coalesce(nullif(j->>'attendance_date','')::date,nullif(j->>'date','')::date,(nullif(j->>'created_at',''))::timestamptz::date) attendance_date,
      coalesce(nullif(j->>'check_in',''),nullif(j->>'in_time',''),nullif(j->>'start_time',''),nullif(j->>'login_time','')) check_in,
      coalesce(nullif(j->>'check_out',''),nullif(j->>'out_time',''),nullif(j->>'end_time',''),nullif(j->>'logout_time','')) check_out,
      j
    from attendance_source
  ),
  attendance_linked as (
    select e.canonical_employee_id, ar.attendance_date,
           min(ar.check_in) check_in, max(ar.check_out) check_out
    from attendance_raw ar
    join employees e on ar.employee_ref=any(e.aliases)
    where ar.attendance_date between v_start and v_end
            and coalesce(lower(ar.j->>'status'),'present') not in ('cancelled','rejected','failed','ملغي','مرفوض','غير معتمد')
      and coalesce(lower(ar.j->>'is_cancelled'),'false') <> 'true'
      and coalesce(lower(ar.j->>'is_deleted'),'false') <> 'true'
      and coalesce(lower(ar.j->>'is_approved'),'true') = 'true'
    group by e.canonical_employee_id, ar.attendance_date
  ),
  attendance_agg as (
    select al.canonical_employee_id, min(al.attendance_date) as first_attendance_date,
           count(*)::int as present_days,
           jsonb_agg(jsonb_build_object('date',al.attendance_date,'check_in',al.check_in,'check_out',al.check_out) order by al.attendance_date) as attendance_days
    from attendance_linked al group by al.canonical_employee_id
  ),
  service_dates as (
    select e.canonical_employee_id,
      greatest(v_start,
        coalesce(nullif(e.j->>'work_start_date','')::date,nullif(e.j->>'hire_date','')::date,nullif(e.j->>'joining_date','')::date,v_start),
        coalesce((select min(a.assignment_start) from assignments_enriched a where a.canonical_employee_id=e.canonical_employee_id),v_start),
        coalesce(at.first_attendance_date,v_start)
      ) service_start,
      least(v_end,coalesce(nullif(e.j->>'work_end_date','')::date,nullif(e.j->>'termination_date','')::date,nullif(e.j->>'stop_date','')::date,v_end)) service_end
    from employees e left join attendance_agg at using(canonical_employee_id)
  ),
  calendar_days as (
    select sd.canonical_employee_id, g.d::date work_date
    from service_dates sd
    cross join lateral generate_series(sd.service_start,sd.service_end,interval '1 day') g(d)
    where sd.service_start<=sd.service_end
  ),
  required_calendar as (
    select
      cd.canonical_employee_id,
      cd.work_date,
      case
        when extract(isodow from cd.work_date)=5
          then coalesce(max(a.friday_minutes),0)
        else coalesce(max(a.required_daily_minutes),540)
      end required_minutes
    from calendar_days cd
    left join assignments_enriched a
      on a.canonical_employee_id=cd.canonical_employee_id
     and cd.work_date between a.assignment_start and a.assignment_end
    group by cd.canonical_employee_id, cd.work_date
  ),
  required_agg as (
    select rc.canonical_employee_id,
      count(*) filter(where rc.required_minutes>0)::int as required_work_days,
      coalesce(sum(rc.required_minutes),0)::numeric as required_minutes
    from required_calendar rc group by rc.canonical_employee_id
  ),
  adjustment_source as (
    select to_jsonb(pa) j from public.payroll_adjustments pa
    where pa.effective_date between v_start and v_end and coalesce(pa.is_deleted,false)=false
  ),
  adjustments as (
    select e.canonical_employee_id,
      coalesce(sum((x.j->>'amount')::numeric) filter(where lower(x.j->>'adjustment_type') in ('allowance','بدل','بدلات')),0) allowances,
      coalesce(sum((x.j->>'amount')::numeric) filter(where lower(x.j->>'adjustment_type') in ('commission','bonus','حافز','عمولة')),0) commissions,
      coalesce(sum((x.j->>'amount')::numeric) filter(where lower(x.j->>'adjustment_type') in ('advance','سلفة')),0) advances,
      coalesce(sum((x.j->>'amount')::numeric) filter(where lower(x.j->>'adjustment_type') in ('deduction','خصم','جزاء')),0) deductions
    from adjustment_source x
    join employees e on coalesce(nullif(x.j->>'employee_id',''),nullif(x.j->>'worker_id',''))=any(e.aliases)
    where coalesce(lower(x.j->>'status'),'approved') in ('approved','معتمد')
    group by e.canonical_employee_id
  ),
  assignment_json as (
    select canonical_employee_id,
      jsonb_agg(jsonb_build_object(
        'project_id',project_id,'project_name',project_name,'supervisor_id',supervisor_id,'supervisor_name',supervisor_name,
        'start',assignment_start,'end',assignment_end,'days',overlap_days,'operation_type',operation_type
      ) order by assignment_start) assignment_details,
      array_agg(distinct project_id) filter(where project_id is not null) project_ids,
      array_agg(distinct project_name) filter(where project_name is not null) project_names,
      count(distinct supervisor_id) filter(where supervisor_id is not null)>1 multiple_supervisors
    from assignments_enriched group by canonical_employee_id
  ),
  payroll_rows as (
    select
      e.canonical_employee_id,
      e.canonical_employee_id worker_id,
      coalesce(nullif(e.j->>'employee_code',''),nullif(e.j->>'worker_code',''),nullif(e.j->>'employee_ts_id',''),nullif(e.j->>'code',''),e.canonical_employee_id) employee_code,
      p_month AS "month",
      coalesce(nullif(e.j->>'iqama_name',''),nullif(e.j->>'residency_name',''),nullif(e.j->>'official_name',''),nullif(e.j->>'full_name',''),nullif(e.j->>'name',''),'موظف') residency_name,
      coalesce(nullif(e.j->>'app_name',''),nullif(e.j->>'display_name',''),nullif(e.j->>'name',''),nullif(e.j->>'full_name',''),'موظف') worker_name,
      coalesce(nullif(e.j->>'iqama_number',''),nullif(e.j->>'residency_number',''),nullif(e.j->>'national_id',''),'') iqama_number,
      case
        when lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'employee_type',e.j->>'job_type',e.j->>'role','')) ~ '(supervisor|مشرف)' then 'مشرف'
        when lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'employee_type',e.j->>'job_type',e.j->>'role','')) ~ '(technician|فني|صيانة)' then 'فني'
        when lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'employee_type',e.j->>'job_type',e.j->>'role','')) ~ '(guard|حارس|امن)' then 'حارس'
        else coalesce(nullif(e.j->>'job_title',''),nullif(e.j->>'position',''),nullif(e.j->>'employee_type',''),nullif(e.j->>'job_type',''),nullif(e.j->>'role',''),'عامل')
      end job_title,
      ps.supervisor_id,
      coalesce(ps.supervisor_name,'دون مشرف نشط') supervisor_name,
      case
        when coalesce(array_length(aj.project_names,1),0)>1 then 'متعدد'
        when coalesce(array_length(aj.project_names,1),0)=1 then
          case when exists(select 1 from assignments_enriched ae where ae.canonical_employee_id=e.canonical_employee_id and lower(ae.operation_type) in ('daily_visit','زيارة يومية'))
               then coalesce(ps.supervisor_name,'دون مشرف نشط') else aj.project_names[1] end
        when lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'role','')) ~ '(فني|technician|صيانة)' then 'فريق الصيانة'
        when lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'role','')) ~ '(مشرف|supervisor)' then 'إدارة التشغيل'
        when lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'role','')) ~ '(حارس|guard|امن)' then 'دون توزيع حراسة'
        else 'دون توزيع'
      end work_location,
      coalesce(to_jsonb(aj.project_ids),'[]'::jsonb) project_ids,
      coalesce(to_jsonb(aj.project_names),'[]'::jsonb) project_names,
      coalesce(aj.assignment_details,'[]'::jsonb) assignment_details,
      coalesce(aj.multiple_supervisors,false) multiple_supervisors,
      sd.service_start,
      at.first_attendance_date,
      sd.service_end,
      (sd.service_end-sd.service_start+1)::int month_days,
      (sd.service_end-sd.service_start+1)::int work_days,
      coalesce(ra.required_work_days,0) required_work_days,
      coalesce(at.present_days,0) present_days,
      greatest(coalesce(ra.required_work_days,0)-coalesce(at.present_days,0),0)::int absent_days,
      (sd.service_end-sd.service_start+1)::int due_days,
      coalesce(ra.required_minutes,0) required_minutes,
      0::numeric actual_minutes,
      coalesce(nullif(e.j->>'basic_salary','')::numeric,nullif(e.j->>'base_salary','')::numeric,nullif(e.j->>'salary','')::numeric,0) base_salary,
      coalesce(nullif(e.j->>'allowances','')::numeric,nullif(e.j->>'allowance','')::numeric,0)+coalesce(ad.allowances,0) allowances,
      coalesce(ad.commissions,0) commissions,
      coalesce(ad.advances,0) advances,
      coalesce(ad.deductions,0) other_deductions,
      0::numeric rounding,
      coalesce(at.attendance_days,'[]'::jsonb) details
    from employees e
    left join primary_supervisor ps using(canonical_employee_id)
    left join assignment_json aj using(canonical_employee_id)
    left join attendance_agg at using(canonical_employee_id)
    left join service_dates sd using(canonical_employee_id)
    left join required_agg ra using(canonical_employee_id)
    left join adjustments ad using(canonical_employee_id)
  ),
  final_rows as (
    select pr.*,
      (pr.base_salary+pr.allowances) gross_salary,
      ((pr.base_salary+pr.allowances)/30.0*pr.due_days) period_salary,
      case when pr.first_attendance_date is null then 0 else (pr.base_salary/30.0*pr.absent_days) end absence_deduction,
      (pr.other_deductions + case when pr.first_attendance_date is null then 0 else (pr.base_salary/30.0*pr.absent_days) end) deductions,
      (((pr.base_salary+pr.allowances)/30.0*pr.due_days)+pr.commissions+pr.rounding-pr.other_deductions-pr.advances-
        case when pr.first_attendance_date is null then 0 else (pr.base_salary/30.0*pr.absent_days) end) net_salary,
      case when pr.first_attendance_date is null then 'يحتاج مراجعة' when pr.base_salary=0 then 'يحتاج مراجعة' else 'مسودة' end status,
      case when pr.first_attendance_date is null then jsonb_build_array('الحضور غير مكتمل')
           when pr.base_salary=0 then jsonb_build_array('الراتب الأساسي غير مسجل') else '[]'::jsonb end issues,
      ''::text notes
    from payroll_rows pr
  ),
  duplicate_check as (
    select fr.canonical_employee_id,count(*) as n from final_rows fr group by fr.canonical_employee_id having count(*)>1
  ),
  supervisor_counts as (
    select coalesce(fr.supervisor_id,'none') as supervisor_id, max(fr.supervisor_name) as supervisor_name,
           count(distinct fr.canonical_employee_id)::int as payroll_workers
    from final_rows fr group by coalesce(fr.supervisor_id,'none')
  ),
  diagnostics as (
    select jsonb_build_object(
      'period_start',v_start,'period_end',v_end,
      'raw_employee_records',(select count(*) from employee_source),
      'raw_assignments',(select count(*) from assignments_raw),
      'raw_attendance_records',(select count(*) from attendance_raw),
      'canonical_employee_ids',(select count(*) from employees),
      'merged_duplicate_profiles',(select coalesce(sum(greatest(merged_profile_count-1,0)),0)::int from employees_all),
      'workers_count',(select count(*) from employees e where lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'employee_type',e.j->>'job_type',e.j->>'role','عامل')) !~ '(supervisor|technician|guard|مشرف|فني|حارس|امن|صيانة)'),
      'guards_count',(select count(*) from employees e where lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'employee_type',e.j->>'job_type',e.j->>'role','')) ~ '(guard|حارس|امن)'),
      'technicians_count',(select count(*) from employees e where lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'employee_type',e.j->>'job_type',e.j->>'role','')) ~ '(technician|فني|صيانة)'),
      'supervisors_count',(select count(*) from employees e where lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'employee_type',e.j->>'job_type',e.j->>'role','')) ~ '(supervisor|مشرف)'),
      'duplicate_ids_found',(select count(*) from duplicate_check),
      'stopped_employees_removed',(select se.n from stopped_employees se),
      'stopped_supervisors_removed',(select ssr.n from stopped_supervisor_refs ssr),
      'final_payroll_rows',(select count(*) from final_rows),
      'supervisor_counts',coalesce((select jsonb_agg(to_jsonb(sc)) from supervisor_counts sc),'[]'::jsonb)
    ) j
  )
  select jsonb_build_object(
    'rows',coalesce((select jsonb_agg(to_jsonb(fr) order by fr.supervisor_name,fr.job_title,fr.employee_code) from final_rows fr),'[]'::jsonb),
    'projects',coalesce((select jsonb_agg(jsonb_build_object('id',pr.project_id,'name',pr.project_name,'operation_type',pr.operation_type)) from projects pr),'[]'::jsonb),
    'diagnostics',(select d.j from diagnostics d),
    'incomplete',false
  ) into v_result;

  v_duplicates := coalesce((v_result->'diagnostics'->>'duplicate_ids_found')::int,0);
  if v_duplicates <> 0 then
    raise exception 'Duplicate payroll employees detected';
  end if;
  if coalesce((v_result->'diagnostics'->>'final_payroll_rows')::int,0)
     <> coalesce((v_result->'diagnostics'->>'canonical_employee_ids')::int,0) then
    raise exception 'Payroll row count does not match canonical employees';
  end if;

  return v_result;
end;
$$;

grant execute on function public.get_unified_payroll_from_server(text) to anon, authenticated;

-- V480 جذري: توحيد هوية الموظف، ربط التوزيع والحضور من السيرفر، ومنع الصفوف التقنية والمكررة.
create index if not exists idx_monthly_distribution_worker_month_v480
  on public.monthly_distribution (month_key, worker_employee_code);
create index if not exists idx_monthly_distribution_supervisor_month_v480
  on public.monthly_distribution (month_key, supervisor_employee_code);
create index if not exists idx_attendance_worker_date_v480
  on public.attendance (worker_id, attendance_date);

create or replace function public.get_unified_payroll_from_server(p_month text)
returns jsonb
language plpgsql
security invoker
set search_path = public
set statement_timeout = '120s'
as $$
#variable_conflict use_column
declare
  v_start date;
  v_end date;
  v_result jsonb;
  v_duplicates integer;
begin
  if p_month is null or p_month !~ '^\d{4}-\d{2}$' then
    raise exception 'Invalid payroll month: %', p_month;
  end if;

  v_start := (p_month || '-01')::date;
  v_end := (v_start + interval '1 month - 1 day')::date;

  with
  employee_source as (
    select 1::int source_priority, 'employees_master_v386'::text source_table, to_jsonb(e) j
      from public.employees_master_v386 e
    union all
    select 2::int, 'workers'::text, to_jsonb(w)
      from public.workers w
    union all
    select 3::int, 'app_users'::text, to_jsonb(u)
      from public.app_users u
     where coalesce(nullif(to_jsonb(u)->>'employee_code',''),nullif(to_jsonb(u)->>'worker_code',''),nullif(to_jsonb(u)->>'employee_ts_id','')) is not null
       and lower(coalesce(to_jsonb(u)->>'role',to_jsonb(u)->>'job_title',to_jsonb(u)->>'position','')) ~ '(supervisor|technician|guard|مشرف|فني|حارس|امن|صيانة)'
  ),
  employee_normalized as (
    select
      es.*,
      lower(coalesce(nullif(es.j->>'employee_code',''),nullif(es.j->>'worker_code',''),nullif(es.j->>'employee_ts_id',''),nullif(es.j->>'code',''))) code_key,
      regexp_replace(coalesce(es.j->>'iqama_number',es.j->>'residency_number',es.j->>'national_id',''),'\D','','g') iqama_key,
      lower(regexp_replace(translate(coalesce(es.j->>'app_name',es.j->>'display_name',es.j->>'name',es.j->>'full_name',es.j->>'worker_name',es.j->>'iqama_name',''),'أإآىة','ااايه'),'[^[:alnum:]ء-ي]+','','g')) name_key,
      array_remove(array[
        nullif(es.j->>'id',''),nullif(es.j->>'employee_id',''),nullif(es.j->>'worker_id',''),nullif(es.j->>'staff_id',''),nullif(es.j->>'person_id',''),
        nullif(es.j->>'employee_code',''),nullif(es.j->>'worker_code',''),nullif(es.j->>'employee_ts_id',''),nullif(es.j->>'code',''),nullif(es.j->>'username','')
      ],null) aliases,
      case
        when lower(coalesce(es.j->>'is_active',''))='true' then true
        when lower(coalesce(es.j->>'is_active',''))='false' then false
        when lower(coalesce(es.j->>'status',es.j->>'employee_status',es.j->>'work_status','active')) in ('inactive','stopped','terminated','disabled','موقوف','متوقف','منتهي','خارج العمل') then false
        else true
      end active_now
    from employee_source es
  ),
  employee_keyed as (
    select en.*,
      coalesce(
        case when en.code_key is not null and en.code_key<>'' then 'code:'||en.code_key end,
        case when length(en.iqama_key)>=6 then 'iqama:'||en.iqama_key end,
        case when en.name_key<>'' then 'legacy-name:'||en.name_key||':'||lower(coalesce(en.j->>'job_title',en.j->>'position',en.j->>'role','عامل')) end,
        'row:'||en.source_table||':'||coalesce(en.j->>'id',en.j->>'employee_id',en.j->>'worker_id')
      ) canonical_employee_id
    from employee_normalized en
    where coalesce(en.j->>'id',en.j->>'employee_id',en.j->>'worker_id',en.j->>'employee_code',en.j->>'worker_code',en.j->>'employee_ts_id') is not null
  ),
  employees_all as (
    select
      ek.canonical_employee_id,
      array_agg(distinct a.alias) filter(where a.alias is not null) aliases,
      (array_agg(ek.j order by ek.source_priority))[1] j,
      bool_or(ek.active_now) active_now,
      count(*)::int merged_profile_count
    from employee_keyed ek
    left join lateral unnest(ek.aliases) a(alias) on true
    group by ek.canonical_employee_id
  ),
  employees as (
    select * from employees_all
     where active_now=true
       and coalesce(lower(j->>'is_deleted'),'false')<>'true'
  ),
  projects as (
    select
      coalesce(nullif(to_jsonb(p)->>'id',''),nullif(to_jsonb(p)->>'project_id','')) project_id,
      coalesce(nullif(to_jsonb(p)->>'name',''),nullif(to_jsonb(p)->>'project_name',''),nullif(to_jsonb(p)->>'title',''),'مشروع') project_name,
      coalesce(nullif(to_jsonb(p)->>'operation_type',''),nullif(to_jsonb(p)->>'project_type',''),'') operation_type,
      coalesce(nullif(to_jsonb(p)->>'required_daily_minutes','')::numeric,540) required_daily_minutes,
      coalesce(nullif(to_jsonb(p)->>'friday_minutes','')::numeric,0) friday_minutes
    from public.projects p
    where (
      lower(coalesce(to_jsonb(p)->>'is_active',''))='true'
      or (to_jsonb(p)->>'is_active' is null and lower(coalesce(to_jsonb(p)->>'status','active')) not in ('inactive','stopped','terminated','disabled','موقوف','متوقف','منتهي'))
    )
  ),
  distribution_source as (
    select to_jsonb(d) j
    from public.monthly_distribution d
    where d.month_key=p_month
  ),
  assignments_raw as (
    select
      coalesce(nullif(j->>'worker_employee_code',''),nullif(j->>'employee_code',''),nullif(j->>'employee_id',''),nullif(j->>'worker_id','')) worker_ref,
      coalesce(nullif(j->>'supervisor_employee_code',''),nullif(j->>'supervisor_code',''),nullif(j->>'supervisor_id','')) supervisor_ref,
      nullif(j->>'supervisor_name','') supervisor_name_raw,
      coalesce(nullif(j->>'project_id',''),nullif(j->>'project_code','')) project_ref,
      nullif(j->>'project_name','') project_name_raw,
      greatest(coalesce(nullif(j->>'start_date','')::date,v_start),v_start) assignment_start,
      least(coalesce(nullif(j->>'end_date','')::date,v_end),v_end) assignment_end,
      coalesce(nullif(j->>'role_type',''),nullif(j->>'job_title','')) role_type,
      j
    from distribution_source
    where coalesce(lower(j->>'status'),'active') not in ('deleted','cancelled','inactive','stopped','ملغي','محذوف','موقوف')
  ),
  assignments_linked as (
    select distinct on (e.canonical_employee_id,ar.project_ref,ar.supervisor_ref,ar.assignment_start,ar.assignment_end)
      e.canonical_employee_id, ar.supervisor_ref, ar.supervisor_name_raw,
      ar.project_ref, ar.project_name_raw, ar.assignment_start, ar.assignment_end,
      greatest((ar.assignment_end-ar.assignment_start)+1,0)::int overlap_days, ar.role_type
    from assignments_raw ar
    join employees e on lower(ar.worker_ref)=any(select lower(x) from unnest(e.aliases) x)
    where ar.assignment_start<=ar.assignment_end
    order by e.canonical_employee_id,ar.project_ref,ar.supervisor_ref,ar.assignment_start,ar.assignment_end
  ),
  supervisor_profiles as (
    select distinct on (ar.supervisor_ref)
      ar.supervisor_ref,
      e.canonical_employee_id supervisor_id,
      coalesce(nullif(e.j->>'app_name',''),nullif(e.j->>'display_name',''),nullif(e.j->>'name',''),nullif(e.j->>'full_name',''),ar.supervisor_name_raw,'مشرف') supervisor_name
    from assignments_raw ar
    left join employees e on lower(ar.supervisor_ref)=any(select lower(x) from unnest(e.aliases) x)
    where ar.supervisor_ref is not null
    order by ar.supervisor_ref,e.canonical_employee_id
  ),
  assignments_enriched as (
    select
      a.canonical_employee_id,
      coalesce(sp.supervisor_id,'distribution-supervisor:'||a.supervisor_ref) supervisor_id,
      coalesce(sp.supervisor_name,a.supervisor_name_raw,'دون مشرف') supervisor_name,
      coalesce(p.project_id,a.project_ref) project_id,
      coalesce(p.project_name,a.project_name_raw,'تعذر ربط المشروع') project_name,
      coalesce(p.operation_type,'') operation_type,
      coalesce(p.required_daily_minutes,540) required_daily_minutes,
      coalesce(p.friday_minutes,0) friday_minutes,
      a.assignment_start,a.assignment_end,a.overlap_days,a.role_type
    from assignments_linked a
    left join supervisor_profiles sp on sp.supervisor_ref=a.supervisor_ref
    left join projects p on p.project_id=a.project_ref
  ),
  supervisor_days as (
    select canonical_employee_id,supervisor_id,max(supervisor_name) supervisor_name,
           sum(overlap_days)::int supervisor_days,max(assignment_start) latest_start
    from assignments_enriched
    group by canonical_employee_id,supervisor_id
  ),
  primary_supervisor as (
    select canonical_employee_id,supervisor_id,supervisor_name,supervisor_days
    from (
      select sd.*,row_number() over(partition by canonical_employee_id order by supervisor_days desc,latest_start desc,supervisor_id) rn
      from supervisor_days sd
    ) x where rn=1
  ),
  attendance_raw as (
    select
      coalesce(nullif(to_jsonb(a)->>'employee_id',''),nullif(to_jsonb(a)->>'worker_id',''),nullif(to_jsonb(a)->>'staff_id',''),nullif(to_jsonb(a)->>'person_id',''),nullif(to_jsonb(a)->>'user_id','')) employee_ref,
      coalesce(nullif(to_jsonb(a)->>'attendance_date','')::date,nullif(to_jsonb(a)->>'date','')::date,(nullif(to_jsonb(a)->>'created_at',''))::timestamptz::date) attendance_date,
      lower(coalesce(to_jsonb(a)->>'status',to_jsonb(a)->>'attendance_status','')) attendance_status,
      coalesce(nullif(to_jsonb(a)->>'check_in',''),nullif(to_jsonb(a)->>'in_time',''),nullif(to_jsonb(a)->>'start_time','')) check_in,
      coalesce(nullif(to_jsonb(a)->>'check_out',''),nullif(to_jsonb(a)->>'out_time',''),nullif(to_jsonb(a)->>'end_time','')) check_out,
      to_jsonb(a) j
    from public.attendance a
    where a.attendance_date>=v_start and a.attendance_date<(v_end+1)
  ),
  attendance_linked as (
    select e.canonical_employee_id,ar.attendance_date,
      bool_or(ar.attendance_status in ('present','حاضر','late','متأخر') or ar.check_in is not null) present,
      bool_or(ar.attendance_status in ('absent','غائب')) absent,
      min(ar.check_in) check_in,max(ar.check_out) check_out
    from attendance_raw ar
    join employees e on lower(ar.employee_ref)=any(select lower(x) from unnest(e.aliases) x)
    where ar.attendance_date between v_start and v_end
      and coalesce(lower(ar.j->>'is_deleted'),'false')<>'true'
      and coalesce(lower(ar.j->>'is_cancelled'),'false')<>'true'
      and coalesce(lower(ar.j->>'status'),'') not in ('cancelled','rejected','failed','ملغي','مرفوض','غير معتمد')
    group by e.canonical_employee_id,ar.attendance_date
  ),
  attendance_agg as (
    select canonical_employee_id,
      min(attendance_date) filter(where present) first_attendance_date,
      count(*) filter(where present)::int present_days,
      count(*) filter(where absent)::int explicit_absent_days,
      count(*)::int attendance_rows,
      jsonb_agg(jsonb_build_object('date',attendance_date,'present',present,'absent',absent,'check_in',check_in,'check_out',check_out) order by attendance_date) attendance_days
    from attendance_linked group by canonical_employee_id
  ),
  service_dates as (
    select e.canonical_employee_id,
      greatest(v_start,
        coalesce(nullif(e.j->>'work_start_date','')::date,nullif(e.j->>'hire_date','')::date,nullif(e.j->>'joining_date','')::date,v_start),
        coalesce((select min(a.assignment_start) from assignments_enriched a where a.canonical_employee_id=e.canonical_employee_id),v_start),
        coalesce(at.first_attendance_date,v_start)
      ) service_start,
      least(v_end,coalesce(nullif(e.j->>'work_end_date','')::date,nullif(e.j->>'termination_date','')::date,nullif(e.j->>'stop_date','')::date,v_end)) service_end
    from employees e left join attendance_agg at using(canonical_employee_id)
  ),
  assignment_json as (
    select canonical_employee_id,
      jsonb_agg(jsonb_build_object('project_id',project_id,'project_name',project_name,'supervisor_id',supervisor_id,'supervisor_name',supervisor_name,'start',assignment_start,'end',assignment_end,'days',overlap_days,'operation_type',operation_type) order by assignment_start) assignment_details,
      array_agg(distinct project_id) filter(where project_id is not null) project_ids,
      array_agg(distinct project_name) filter(where project_name is not null and project_name<>'تعذر ربط المشروع') project_names,
      count(distinct supervisor_id)>1 multiple_supervisors
    from assignments_enriched group by canonical_employee_id
  ),
  adjustments as (
    select e.canonical_employee_id,
      coalesce(sum(pa.amount) filter(where lower(pa.adjustment_type) in ('allowance','بدل','بدلات')),0) allowances,
      coalesce(sum(pa.amount) filter(where lower(pa.adjustment_type) in ('commission','bonus','حافز','عمولة')),0) commissions,
      coalesce(sum(pa.amount) filter(where lower(pa.adjustment_type) in ('advance','سلفة')),0) advances,
      coalesce(sum(pa.amount) filter(where lower(pa.adjustment_type) in ('deduction','خصم','جزاء')),0) deductions
    from public.payroll_adjustments pa
    join employees e on lower(coalesce(pa.employee_id::text,pa.worker_id::text))=any(select lower(x) from unnest(e.aliases) x)
    where pa.effective_date between v_start and v_end and coalesce(pa.is_deleted,false)=false
      and lower(coalesce(pa.status,'approved')) in ('approved','معتمد')
    group by e.canonical_employee_id
  ),
  payroll_rows as (
    select
      e.canonical_employee_id,e.canonical_employee_id worker_id,
      coalesce(nullif(e.j->>'employee_code',''),nullif(e.j->>'worker_code',''),nullif(e.j->>'employee_ts_id',''),nullif(e.j->>'code',''),'') employee_code,
      p_month "month",
      coalesce(nullif(e.j->>'iqama_name',''),nullif(e.j->>'residency_name',''),nullif(e.j->>'official_name',''),nullif(e.j->>'full_name',''),nullif(e.j->>'name',''),'موظف') residency_name,
      coalesce(nullif(e.j->>'app_name',''),nullif(e.j->>'display_name',''),nullif(e.j->>'name',''),nullif(e.j->>'full_name',''),'موظف') worker_name,
      coalesce(nullif(e.j->>'iqama_number',''),nullif(e.j->>'residency_number',''),nullif(e.j->>'national_id',''),'') iqama_number,
      case
        when lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'employee_type',e.j->>'job_type',e.j->>'role','')) ~ '(supervisor|مشرف)' then 'مشرف'
        when lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'employee_type',e.j->>'job_type',e.j->>'role','')) ~ '(technician|فني|صيانة)' then 'فني'
        when lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'employee_type',e.j->>'job_type',e.j->>'role','')) ~ '(guard|حارس|امن)' then 'حارس'
        else coalesce(nullif(e.j->>'job_title',''),nullif(e.j->>'position',''),nullif(e.j->>'employee_type',''),nullif(e.j->>'job_type',''),'عامل') end job_title,
      ps.supervisor_id,coalesce(ps.supervisor_name,'دون مشرف') supervisor_name,
      case
        when coalesce(array_length(aj.project_names,1),0)>1 then 'متعدد'
        when coalesce(array_length(aj.project_names,1),0)=1 then
          case when exists(select 1 from assignments_enriched ae where ae.canonical_employee_id=e.canonical_employee_id and lower(ae.operation_type) in ('daily_visit','زيارة يومية'))
               then coalesce(ps.supervisor_name,'دون مشرف') else aj.project_names[1] end
        when lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'role','')) ~ '(فني|technician|صيانة)' then 'فريق الصيانة'
        when lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'role','')) ~ '(مشرف|supervisor)' then 'إدارة التشغيل'
        when lower(coalesce(e.j->>'job_title',e.j->>'position',e.j->>'role','')) ~ '(حارس|guard|امن)' then 'دون توزيع حراسة'
        else 'دون توزيع' end work_location,
      coalesce(to_jsonb(aj.project_ids),'[]'::jsonb) project_ids,
      coalesce(to_jsonb(aj.project_names),'[]'::jsonb) project_names,
      coalesce(aj.assignment_details,'[]'::jsonb) assignment_details,
      coalesce(aj.multiple_supervisors,false) multiple_supervisors,
      sd.service_start,at.first_attendance_date,sd.service_end,
      least(greatest((sd.service_end-sd.service_start)+1,0),30)::int month_days,
      coalesce(at.present_days,0)::int work_days,
      coalesce(at.present_days,0)::int present_days,
      case when coalesce(at.attendance_rows,0)=0 then null else coalesce(at.explicit_absent_days,0)::int end absent_days,
      least(greatest((sd.service_end-sd.service_start)+1,0),30)::int due_days,
      0::numeric required_minutes,0::numeric actual_minutes,
      coalesce(nullif(e.j->>'basic_salary','')::numeric,nullif(e.j->>'base_salary','')::numeric,nullif(e.j->>'salary','')::numeric,0) base_salary,
      coalesce(nullif(e.j->>'allowances','')::numeric,nullif(e.j->>'allowance','')::numeric,0)+coalesce(ad.allowances,0) allowances,
      coalesce(ad.commissions,0) commissions,coalesce(ad.advances,0) advances,coalesce(ad.deductions,0) other_deductions,
      0::numeric rounding,coalesce(at.attendance_days,'[]'::jsonb) details,
      e.merged_profile_count
    from employees e
    left join primary_supervisor ps using(canonical_employee_id)
    left join assignment_json aj using(canonical_employee_id)
    left join attendance_agg at using(canonical_employee_id)
    left join service_dates sd using(canonical_employee_id)
    left join adjustments ad using(canonical_employee_id)
  ),
  final_rows as (
    select pr.*,
      (pr.base_salary+pr.allowances) gross_salary,
      ((pr.base_salary+pr.allowances)/30.0*pr.due_days) period_salary,
      case when pr.absent_days is null then 0 else (pr.base_salary/30.0*pr.absent_days) end absence_deduction,
      (pr.other_deductions+case when pr.absent_days is null then 0 else (pr.base_salary/30.0*pr.absent_days) end) deductions,
      (((pr.base_salary+pr.allowances)/30.0*pr.due_days)+pr.commissions+pr.rounding-pr.other_deductions-pr.advances-
        case when pr.absent_days is null then 0 else (pr.base_salary/30.0*pr.absent_days) end) net_salary,
      case when pr.absent_days is null then 'يحتاج مراجعة' when pr.base_salary=0 then 'يحتاج مراجعة' else 'مسودة' end status,
      case when pr.absent_days is null then jsonb_build_array('تعذر احتساب الغياب: لا توجد بيانات حضور')
           when pr.base_salary=0 then jsonb_build_array('الراتب الأساسي غير مسجل') else '[]'::jsonb end issues,
      ''::text notes
    from payroll_rows pr
  ),
  duplicate_check as (
    select canonical_employee_id,count(*) n from final_rows group by canonical_employee_id having count(*)>1
  ),
  supervisor_counts as (
    select coalesce(supervisor_id,'none') supervisor_id,max(supervisor_name) supervisor_name,count(distinct canonical_employee_id)::int payroll_workers
    from final_rows group by coalesce(supervisor_id,'none')
  ),
  diagnostics as (
    select jsonb_build_object(
      'period_start',v_start,'period_end',v_end,
      'raw_employee_records',(select count(*) from employee_source),
      'raw_assignments',(select count(*) from assignments_raw),
      'raw_attendance_records',(select count(*) from attendance_raw),
      'canonical_employee_ids',(select count(*) from employees),
      'duplicateRowsRemoved',(select coalesce(sum(greatest(merged_profile_count-1,0)),0)::int from employees_all),
      'merged_duplicate_profiles',(select coalesce(sum(greatest(merged_profile_count-1,0)),0)::int from employees_all),
      'duplicate_ids_found',(select count(*) from duplicate_check),
      'final_payroll_rows',(select count(*) from final_rows),
      'workers_count',(select count(*) from final_rows where job_title not in ('مشرف','فني','حارس')),
      'guards_count',(select count(*) from final_rows where job_title='حارس'),
      'technicians_count',(select count(*) from final_rows where job_title='فني'),
      'supervisors_count',(select count(*) from final_rows where job_title='مشرف'),
      'without_supervisor_count',(select count(*) from final_rows where supervisor_id is null),
      'supervisor_counts',coalesce((select jsonb_agg(to_jsonb(sc)) from supervisor_counts sc),'[]'::jsonb)
    ) j
  )
  select jsonb_build_object(
    'rows',coalesce((select jsonb_agg(to_jsonb(fr) order by fr.supervisor_name,fr.job_title,fr.employee_code,fr.worker_name) from final_rows fr),'[]'::jsonb),
    'projects',coalesce((select jsonb_agg(jsonb_build_object('id',project_id,'name',project_name,'operation_type',operation_type)) from projects),'[]'::jsonb),
    'diagnostics',(select j from diagnostics),
    'incomplete',false
  ) into v_result;

  v_duplicates:=coalesce((v_result->'diagnostics'->>'duplicate_ids_found')::int,0);
  if v_duplicates<>0 then
    raise exception 'Duplicate payroll employees detected';
  end if;
  if coalesce((v_result->'diagnostics'->>'final_payroll_rows')::int,0)<>coalesce((v_result->'diagnostics'->>'canonical_employee_ids')::int,0) then
    raise exception 'Payroll row count does not match canonical employees';
  end if;
  return v_result;
end;
$$;

grant execute on function public.get_unified_payroll_from_server(text) to anon,authenticated;

-- V10607 CRM quote compatibility.
-- For existing databases, run supabase_crm_quotes_schema_fix_v10607.sql.
alter table if exists public.crm_quotes add column if not exists customer_id uuid;
alter table if exists public.crm_quotes add column if not exists total_with_tax numeric(14,2);
alter table if exists public.crm_quotes add column if not exists created_at timestamptz default now();
alter table if exists public.crm_quote_versions add column if not exists customer_id uuid;
notify pgrst, 'reload schema';
