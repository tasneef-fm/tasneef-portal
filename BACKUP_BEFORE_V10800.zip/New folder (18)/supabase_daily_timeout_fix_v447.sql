-- V447 إصلاح بطء التسجيلات اليومية ومنع timeout
-- آمن: لا يحذف أي بيانات، يضيف فهارس فقط

create index if not exists idx_time_logs_log_date_v447 on public.time_logs (log_date);
create index if not exists idx_time_logs_log_date_supervisor_v447 on public.time_logs (log_date, supervisor_id);
create index if not exists idx_time_logs_log_date_project_v447 on public.time_logs (log_date, project_id);
create index if not exists idx_time_logs_check_in_v447 on public.time_logs (check_in);
create index if not exists idx_time_logs_created_at_v447 on public.time_logs (created_at);

create index if not exists idx_monthly_distribution_month_project_v447 on public.monthly_distribution (month_key, project_id);
create index if not exists idx_monthly_distribution_month_supervisor_v447 on public.monthly_distribution (month_key, supervisor_employee_code);
create index if not exists idx_monthly_distribution_month_worker_v447 on public.monthly_distribution (month_key, worker_employee_code);

create index if not exists idx_attendance_date_worker_v447 on public.attendance (attendance_date, worker_employee_code);
create index if not exists idx_attendance_date_identity_v447 on public.attendance (attendance_date, worker_identity);
