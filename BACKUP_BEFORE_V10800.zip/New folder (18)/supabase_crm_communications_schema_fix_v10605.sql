-- Tasneef CRM V10605
-- إصلاح توافق جدول crm_communications مع نموذج تسجيل التواصل الحالي.
-- نفّذ هذا الملف مرة واحدة في Supabase SQL Editor.

begin;

create table if not exists public.crm_communications (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid,
  communication_type text not null,
  result text,
  other_result text,
  notes text,
  employee_id uuid,
  employee_name text,
  communication_date date,
  communication_time time,
  communication_at timestamptz default now(),
  next_followup_date date,
  next_followup_time time,
  followup_employee_name text,
  created_at timestamptz default now()
);

alter table public.crm_communications add column if not exists customer_id uuid;
alter table public.crm_communications add column if not exists communication_type text;
alter table public.crm_communications add column if not exists result text;
alter table public.crm_communications add column if not exists other_result text;
alter table public.crm_communications add column if not exists notes text;
alter table public.crm_communications add column if not exists employee_id uuid;
alter table public.crm_communications add column if not exists employee_name text;
alter table public.crm_communications add column if not exists communication_date date;
alter table public.crm_communications add column if not exists communication_time time;
alter table public.crm_communications add column if not exists communication_at timestamptz default now();
alter table public.crm_communications add column if not exists next_followup_date date;
alter table public.crm_communications add column if not exists next_followup_time time;
alter table public.crm_communications add column if not exists followup_employee_name text;
alter table public.crm_communications add column if not exists created_at timestamptz default now();

-- استكمال التاريخ والوقت للسجلات السابقة من communication_at.
update public.crm_communications
set communication_date = coalesce(communication_date, communication_at::date),
    communication_time = coalesce(communication_time, communication_at::time)
where communication_at is not null
  and (communication_date is null or communication_time is null);

-- مفتاح الربط مع العميل دون إيقاف التنفيذ بسبب بيانات قديمة.
do $$
begin
  if to_regclass('public.crm_customers') is not null
     and not exists (
       select 1 from pg_constraint
       where conrelid='public.crm_communications'::regclass
         and conname='crm_communications_customer_id_fkey'
     ) then
    begin
      alter table public.crm_communications
        add constraint crm_communications_customer_id_fkey
        foreign key (customer_id) references public.crm_customers(id)
        on delete cascade not valid;
    exception when others then
      raise notice 'تعذر إضافة FK الآن: %', sqlerrm;
    end;
  end if;
end $$;

create index if not exists crm_communications_customer_id_idx on public.crm_communications(customer_id);
create index if not exists crm_communications_at_idx on public.crm_communications(communication_at desc);

-- توافق الصلاحيات مع تسجيل الدخول المخصص الحالي.
alter table public.crm_communications enable row level security;
do $$
declare p record;
begin
  for p in
    select policyname from pg_policies
    where schemaname='public' and tablename='crm_communications'
  loop
    execute format('drop policy if exists %I on public.crm_communications', p.policyname);
  end loop;
end $$;
create policy tasneef_crm_communications_current_system_access
on public.crm_communications for all to anon, authenticated
using (true) with check (true);
grant select, insert, update, delete on public.crm_communications to anon, authenticated;

commit;

notify pgrst, 'reload schema';

select column_name, data_type, is_nullable
from information_schema.columns
where table_schema='public' and table_name='crm_communications'
order by ordinal_position;
