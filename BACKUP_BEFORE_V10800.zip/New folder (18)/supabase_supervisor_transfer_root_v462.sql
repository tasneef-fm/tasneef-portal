-- V462 إصلاح جذري فعلي لنقل مشرف إلى مشرف آخر
-- الفكرة: لا نعتمد على العمال فقط. نحدد المشاريع المتأثرة ثم ننقل المشاريع نفسها + التوزيع + السجلات الحالية/المستقبلية حسب project_id.
-- السجلات القديمة قبل تاريخ النقل لا تتغير.

create or replace function public.tasneef_transfer_supervisor_root_v462(
  p_old_code text default null,
  p_new_code text default null,
  p_old_name text default null,
  p_new_name text default null,
  p_old_user_id text default null,
  p_new_user_id text default null,
  p_from_month text default null,
  p_from_date date default current_date
)
returns table(
  distribution_rows integer,
  project_rows integer,
  time_log_rows integer,
  attendance_rows integer,
  daily_rows integer,
  resolved_old text,
  resolved_new text,
  affected_projects integer
)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_old_code text := nullif(trim(coalesce(p_old_code,'')),'');
  v_new_code text := nullif(trim(coalesce(p_new_code,'')),'');
  v_old_name text := nullif(trim(coalesce(p_old_name,'')),'');
  v_new_name text := nullif(trim(coalesce(p_new_name,'')),'');
  v_old_user text := nullif(trim(coalesce(p_old_user_id,'')),'');
  v_new_user text := nullif(trim(coalesce(p_new_user_id,'')),'');
  v_month text := coalesce(nullif(p_from_month,''), to_char(current_date,'YYYY-MM'));
  v_date date := coalesce(p_from_date,current_date);
  v_project_ids text[] := array[]::text[];
  v_more text[] := array[]::text[];
  v_set text;
  v_sql text;
  v_cond text;
  v_date_filter text;
  rc int;
  j jsonb;
  has_updated_at boolean;
begin
  distribution_rows := 0; project_rows := 0; time_log_rows := 0; attendance_rows := 0; daily_rows := 0; affected_projects := 0;

  -- حل الكود والاسم من جداول العمال بدون الاعتماد على أعمدة ثابتة
  if to_regclass('public.employees_master_v386') is not null then
    for j in execute 'select to_jsonb(t) from public.employees_master_v386 t' loop
      if v_new_code is null and (
        lower(coalesce(j->>'employee_code',''))=lower(coalesce(p_new_code,'')) or
        coalesce(j->>'app_name','')=coalesce(v_new_name,'') or coalesce(j->>'employee_name','')=coalesce(v_new_name,'')
      ) then v_new_code := nullif(j->>'employee_code',''); end if;
      if v_new_name is null and v_new_code is not null and lower(coalesce(j->>'employee_code',''))=lower(v_new_code) then
        v_new_name := coalesce(nullif(j->>'app_name',''), nullif(j->>'employee_name',''), v_new_code);
      end if;
      if v_old_code is null and (
        lower(coalesce(j->>'employee_code',''))=lower(coalesce(p_old_code,'')) or
        coalesce(j->>'app_name','')=coalesce(v_old_name,'') or coalesce(j->>'employee_name','')=coalesce(v_old_name,'')
      ) then v_old_code := nullif(j->>'employee_code',''); end if;
      if v_old_name is null and v_old_code is not null and lower(coalesce(j->>'employee_code',''))=lower(v_old_code) then
        v_old_name := coalesce(nullif(j->>'app_name',''), nullif(j->>'employee_name',''), v_old_code);
      end if;
    end loop;
  end if;

  if to_regclass('public.workers') is not null then
    for j in execute 'select to_jsonb(t) from public.workers t' loop
      if v_new_code is null and (
        lower(coalesce(j->>'employee_code',''))=lower(coalesce(p_new_code,'')) or
        coalesce(j->>'name','')=coalesce(v_new_name,'') or coalesce(j->>'full_name','')=coalesce(v_new_name,'')
      ) then v_new_code := coalesce(nullif(j->>'employee_code',''), nullif(j->>'id','')); end if;
      if v_new_name is null and v_new_code is not null and (lower(coalesce(j->>'employee_code',''))=lower(v_new_code) or lower(coalesce(j->>'id',''))=lower(v_new_code)) then
        v_new_name := coalesce(nullif(j->>'name',''), nullif(j->>'full_name',''), v_new_code);
      end if;
      if v_old_code is null and (
        lower(coalesce(j->>'employee_code',''))=lower(coalesce(p_old_code,'')) or
        coalesce(j->>'name','')=coalesce(v_old_name,'') or coalesce(j->>'full_name','')=coalesce(v_old_name,'')
      ) then v_old_code := coalesce(nullif(j->>'employee_code',''), nullif(j->>'id','')); end if;
      if v_old_name is null and v_old_code is not null and (lower(coalesce(j->>'employee_code',''))=lower(v_old_code) or lower(coalesce(j->>'id',''))=lower(v_old_code)) then
        v_old_name := coalesce(nullif(j->>'name',''), nullif(j->>'full_name',''), v_old_code);
      end if;
    end loop;
  end if;

  -- حل حساب المستخدم من app_users. هذا مهم جدًا لأن صفحة المشرف تعتمد غالبًا على id الحساب.
  if to_regclass('public.app_users') is not null then
    if v_new_user is null then
      for j in execute 'select to_jsonb(t) from public.app_users t' loop
        if lower(coalesce(j->>'username',''))=lower(coalesce(v_new_code,'')) or
           lower(coalesce(j->>'employee_code',''))=lower(coalesce(v_new_code,'')) or
           coalesce(j->>'full_name','')=coalesce(v_new_name,'') or
           coalesce(j->>'name','')=coalesce(v_new_name,'') or
           coalesce(j->>'email','')=coalesce(v_new_name,'') then
          v_new_user := j->>'id'; exit;
        end if;
      end loop;
    end if;
    if v_old_user is null then
      for j in execute 'select to_jsonb(t) from public.app_users t' loop
        if lower(coalesce(j->>'username',''))=lower(coalesce(v_old_code,'')) or
           lower(coalesce(j->>'employee_code',''))=lower(coalesce(v_old_code,'')) or
           coalesce(j->>'full_name','')=coalesce(v_old_name,'') or
           coalesce(j->>'name','')=coalesce(v_old_name,'') or
           coalesce(j->>'email','')=coalesce(v_old_name,'') then
          v_old_user := j->>'id'; exit;
        end if;
      end loop;
    end if;
  end if;

  resolved_old := concat_ws(' | ', coalesce(v_old_code,''), coalesce(v_old_name,''), coalesce(v_old_user,''));
  resolved_new := concat_ws(' | ', coalesce(v_new_code,''), coalesce(v_new_name,''), coalesce(v_new_user,''));

  if coalesce(v_new_code,v_new_name,v_new_user) is null then
    raise exception 'لم يتم التعرف على المشرف البديل. اكتب الاسم أو الكود كما هو في النظام.';
  end if;

  -- 1) جمع المشاريع المتأثرة من جدول projects بناءً على المشرف القديم.
  if to_regclass('public.projects') is not null then
    v_cond := 'false';
    if v_old_code is not null then
      v_cond := v_cond || format(' or j->>''supervisor_employee_code''=%L or j->>''supervisor_code''=%L or j->>''current_supervisor_code''=%L or j->>''app_supervisor_code''=%L', v_old_code,v_old_code,v_old_code,v_old_code);
    end if;
    if v_old_name is not null then
      v_cond := v_cond || format(' or j->>''supervisor_name''=%L or j->>''current_supervisor_name''=%L or j->>''app_supervisor_name''=%L', v_old_name,v_old_name,v_old_name);
    end if;
    if v_old_user is not null then
      v_cond := v_cond || format(' or j->>''supervisor_id''=%L or j->>''current_supervisor_id''=%L or j->>''app_supervisor_id''=%L', v_old_user,v_old_user,v_old_user);
    end if;
    execute format('select coalesce(array_agg(distinct id), array[]::text[]) from (select id::text id, to_jsonb(t) j from public.projects t) q where %s', v_cond) into v_project_ids;
  end if;

  -- 2) إضافة المشاريع من التوزيع الحالي/القادم، سواء ما زال تحت القديم أو صار تحت الجديد.
  if to_regclass('public.monthly_distribution') is not null then
    v_cond := 'false';
    if v_old_code is not null then v_cond := v_cond || format(' or j->>''supervisor_employee_code''=%L or j->>''supervisor_code''=%L', v_old_code,v_old_code); end if;
    if v_old_name is not null then v_cond := v_cond || format(' or j->>''supervisor_name''=%L', v_old_name); end if;
    if v_old_user is not null then v_cond := v_cond || format(' or j->>''supervisor_id''=%L', v_old_user); end if;
    if v_new_code is not null then v_cond := v_cond || format(' or j->>''supervisor_employee_code''=%L or j->>''supervisor_code''=%L', v_new_code,v_new_code); end if;
    if v_new_name is not null then v_cond := v_cond || format(' or j->>''supervisor_name''=%L', v_new_name); end if;
    if v_new_user is not null then v_cond := v_cond || format(' or j->>''supervisor_id''=%L', v_new_user); end if;
    execute format('select coalesce(array_agg(distinct j->>''project_id''), array[]::text[]) from (select to_jsonb(t) j from public.monthly_distribution t) q where coalesce(j->>''month_key'','''') >= %L and (%s) and coalesce(j->>''project_id'','''')<>''''', v_month, v_cond) into v_more;
    v_project_ids := (select coalesce(array_agg(distinct x), array[]::text[]) from unnest(coalesce(v_project_ids,array[]::text[]) || coalesce(v_more,array[]::text[])) as x where x is not null and x <> '');
  end if;

  affected_projects := coalesce(array_length(v_project_ids,1),0);

  -- تحديث جدول معين إذا فيه project_id وتاريخ اختياري
  -- monthly_distribution
  if affected_projects > 0 and to_regclass('public.monthly_distribution') is not null then
    v_set := '';
    select exists(select 1 from information_schema.columns where table_schema='public' and table_name='monthly_distribution' and column_name='updated_at') into has_updated_at;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='monthly_distribution' and column_name='supervisor_employee_code') then v_set := v_set || format('supervisor_employee_code=%L,', v_new_code); end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='monthly_distribution' and column_name='supervisor_code') then v_set := v_set || format('supervisor_code=%L,', v_new_code); end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='monthly_distribution' and column_name='supervisor_name') then v_set := v_set || format('supervisor_name=%L,', v_new_name); end if;
    if v_new_user is not null and exists(select 1 from information_schema.columns where table_schema='public' and table_name='monthly_distribution' and column_name='supervisor_id') then v_set := v_set || format('supervisor_id=%L,', v_new_user); end if;
    if has_updated_at then v_set := v_set || 'updated_at=now(),'; end if;
    v_set := trim(trailing ',' from v_set);
    if v_set <> '' then
      execute format('update public.monthly_distribution set %s where project_id::text = any(%L::text[]) and coalesce(month_key,'''') >= %L', v_set, v_project_ids, v_month);
      get diagnostics rc = row_count; distribution_rows := rc;
    end if;
  end if;

  -- projects
  if affected_projects > 0 and to_regclass('public.projects') is not null then
    v_set := '';
    select exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='updated_at') into has_updated_at;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='supervisor_employee_code') then v_set := v_set || format('supervisor_employee_code=%L,', v_new_code); end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='supervisor_code') then v_set := v_set || format('supervisor_code=%L,', v_new_code); end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='current_supervisor_code') then v_set := v_set || format('current_supervisor_code=%L,', v_new_code); end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='app_supervisor_code') then v_set := v_set || format('app_supervisor_code=%L,', v_new_code); end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='supervisor_name') then v_set := v_set || format('supervisor_name=%L,', v_new_name); end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='current_supervisor_name') then v_set := v_set || format('current_supervisor_name=%L,', v_new_name); end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='app_supervisor_name') then v_set := v_set || format('app_supervisor_name=%L,', v_new_name); end if;
    if v_new_user is not null and exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='supervisor_id') then v_set := v_set || format('supervisor_id=%L,', v_new_user); end if;
    if v_new_user is not null and exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='current_supervisor_id') then v_set := v_set || format('current_supervisor_id=%L,', v_new_user); end if;
    if v_new_user is not null and exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='app_supervisor_id') then v_set := v_set || format('app_supervisor_id=%L,', v_new_user); end if;
    if has_updated_at then v_set := v_set || 'updated_at=now(),'; end if;
    v_set := trim(trailing ',' from v_set);
    if v_set <> '' then
      execute format('update public.projects set %s where id::text = any(%L::text[])', v_set, v_project_ids);
      get diagnostics rc = row_count; project_rows := rc;
    end if;
  end if;

  -- time_logs حسب project_id من تاريخ النقل وما بعده
  if affected_projects > 0 and to_regclass('public.time_logs') is not null and exists(select 1 from information_schema.columns where table_schema='public' and table_name='time_logs' and column_name='project_id') then
    v_set := '';
    select exists(select 1 from information_schema.columns where table_schema='public' and table_name='time_logs' and column_name='updated_at') into has_updated_at;
    if v_new_user is not null and exists(select 1 from information_schema.columns where table_schema='public' and table_name='time_logs' and column_name='supervisor_id') then v_set := v_set || format('supervisor_id=%L,', v_new_user); end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='time_logs' and column_name='supervisor_employee_code') then v_set := v_set || format('supervisor_employee_code=%L,', v_new_code); end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='time_logs' and column_name='supervisor_name') then v_set := v_set || format('supervisor_name=%L,', v_new_name); end if;
    if has_updated_at then v_set := v_set || 'updated_at=now(),'; end if;
    v_set := trim(trailing ',' from v_set);
    v_date_filter := '';
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='time_logs' and column_name='log_date') then v_date_filter := format(' and log_date >= %L::date', v_date); end if;
    if v_set <> '' then
      execute format('update public.time_logs set %s where project_id::text = any(%L::text[])%s', v_set, v_project_ids, v_date_filter);
      get diagnostics rc = row_count; time_log_rows := rc;
    end if;
  end if;

  -- attendance حسب project_id
  if affected_projects > 0 and to_regclass('public.attendance') is not null and exists(select 1 from information_schema.columns where table_schema='public' and table_name='attendance' and column_name='project_id') then
    v_set := '';
    select exists(select 1 from information_schema.columns where table_schema='public' and table_name='attendance' and column_name='updated_at') into has_updated_at;
    if v_new_user is not null and exists(select 1 from information_schema.columns where table_schema='public' and table_name='attendance' and column_name='supervisor_id') then v_set := v_set || format('supervisor_id=%L,', v_new_user); end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='attendance' and column_name='supervisor_employee_code') then v_set := v_set || format('supervisor_employee_code=%L,', v_new_code); end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='attendance' and column_name='supervisor_name') then v_set := v_set || format('supervisor_name=%L,', v_new_name); end if;
    if has_updated_at then v_set := v_set || 'updated_at=now(),'; end if;
    v_set := trim(trailing ',' from v_set);
    if v_set <> '' then
      execute format('update public.attendance set %s where project_id::text = any(%L::text[]) and attendance_date >= %L::date', v_set, v_project_ids, v_date);
      get diagnostics rc = row_count; attendance_rows := rc;
    end if;
  end if;

  -- daily_records حسب project_id
  if affected_projects > 0 and to_regclass('public.daily_records') is not null and exists(select 1 from information_schema.columns where table_schema='public' and table_name='daily_records' and column_name='project_id') then
    v_set := '';
    select exists(select 1 from information_schema.columns where table_schema='public' and table_name='daily_records' and column_name='updated_at') into has_updated_at;
    if v_new_user is not null and exists(select 1 from information_schema.columns where table_schema='public' and table_name='daily_records' and column_name='supervisor_id') then v_set := v_set || format('supervisor_id=%L,', v_new_user); end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='daily_records' and column_name='supervisor_employee_code') then v_set := v_set || format('supervisor_employee_code=%L,', v_new_code); end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='daily_records' and column_name='supervisor_name') then v_set := v_set || format('supervisor_name=%L,', v_new_name); end if;
    if has_updated_at then v_set := v_set || 'updated_at=now(),'; end if;
    v_set := trim(trailing ',' from v_set);
    if v_set <> '' then
      execute format('update public.daily_records set %s where project_id::text = any(%L::text[]) and record_date >= %L::date', v_set, v_project_ids, v_date);
      get diagnostics rc = row_count; daily_rows := rc;
    end if;
  end if;

  return next;
end;
$$;

grant execute on function public.tasneef_transfer_supervisor_root_v462(text,text,text,text,text,text,text,date) to anon, authenticated;

-- إصلاح مباشر للحالة المذكورة: محمود -> وضاح
-- إن كان الاسم في النظام مختلفًا، عدل الاسم هنا فقط وشغل السطر.
select * from public.tasneef_transfer_supervisor_root_v462(
  null,
  null,
  'محمود',
  'وضاح',
  null,
  null,
  to_char(current_date,'YYYY-MM'),
  current_date
);

do $$
begin
  if to_regclass('public.projects') is not null and exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='supervisor_id') then
    create index if not exists idx_projects_sup_id_v462 on public.projects(supervisor_id);
  end if;
  if to_regclass('public.projects') is not null and exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='supervisor_name') then
    create index if not exists idx_projects_sup_name_v462 on public.projects(supervisor_name);
  end if;
  if to_regclass('public.monthly_distribution') is not null and exists(select 1 from information_schema.columns where table_schema='public' and table_name='monthly_distribution' and column_name='project_id') and exists(select 1 from information_schema.columns where table_schema='public' and table_name='monthly_distribution' and column_name='month_key') then
    create index if not exists idx_monthly_dist_project_month_v462 on public.monthly_distribution(project_id, month_key);
  end if;
  if to_regclass('public.time_logs') is not null and exists(select 1 from information_schema.columns where table_schema='public' and table_name='time_logs' and column_name='project_id') and exists(select 1 from information_schema.columns where table_schema='public' and table_name='time_logs' and column_name='log_date') then
    create index if not exists idx_time_logs_project_date_v462 on public.time_logs(project_id, log_date);
  end if;
  if to_regclass('public.attendance') is not null and exists(select 1 from information_schema.columns where table_schema='public' and table_name='attendance' and column_name='project_id') and exists(select 1 from information_schema.columns where table_schema='public' and table_name='attendance' and column_name='attendance_date') then
    create index if not exists idx_attendance_project_date_v462 on public.attendance(project_id, attendance_date);
  end if;
end $$;
