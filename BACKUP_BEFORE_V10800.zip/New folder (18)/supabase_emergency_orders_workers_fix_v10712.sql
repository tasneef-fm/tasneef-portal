-- Tasneef emergency data fix V10713 (schema-compatible; keeps RPC names V10712)
-- لا يحذف أو يعدّل أي أوردر أو عامل أو توزيع أو حضور.
BEGIN;

CREATE EXTENSION IF NOT EXISTS pg_trgm;

CREATE OR REPLACE FUNCTION public.normalize_order_number_v10712(p_value text)
RETURNS text LANGUAGE sql IMMUTABLE PARALLEL SAFE AS $$
 SELECT regexp_replace(translate(coalesce(p_value,''),'٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹','01234567890123456789'),'\s+','','g');
$$;

-- قائمة خفيفة: لا تجمع الإيصالات والمرفقات ولا تستدعي الملخص.
CREATE OR REPLACE FUNCTION public.get_orders_page_v10712(
  p_page integer DEFAULT 1,
  p_page_size integer DEFAULT 50,
  p_search text DEFAULT NULL,
  p_project text DEFAULT NULL,
  p_executor text DEFAULT NULL,
  p_sender text DEFAULT NULL,
  p_execution_status text DEFAULT NULL,
  p_payment_status text DEFAULT NULL,
  p_invoice_status text DEFAULT NULL,
  p_order_type text DEFAULT NULL,
  p_date_from date DEFAULT NULL,
  p_date_to date DEFAULT NULL,
  p_allowed_projects text[] DEFAULT NULL,
  p_export boolean DEFAULT false
)
RETURNS TABLE(rows jsonb,total bigint,page integer,page_size integer,total_pages integer)
LANGUAGE sql SECURITY INVOKER SET search_path=public AS $$
WITH base AS MATERIALIZED (
 SELECT o.order_no,o.updated_at,o.data,o.flow,
   coalesce(nullif(o.order_no,''),nullif(o.data->>'order_number',''),nullif(o.data->>'external_order_number',''),nullif(o.data->>'legacy_order_number',''),nullif(o.data->>'excel_order_number',''),nullif(o.data->>'رقم الطلب','')) canonical_order_number,
   coalesce(nullif(o.data->>'project_name',''),nullif(o.data->>'المشروع',''),nullif(o.data->>'اسم المشروع',''),nullif(o.flow->>'project_name','')) project_name,
   coalesce(nullif(o.data->>'customer_name',''),nullif(o.data->>'اسم العميل','')) customer_name,
   coalesce(nullif(o.data->>'customer_phone',''),nullif(o.data->>'رقم العميل',''),nullif(o.data->>'mobile','')) customer_phone,
   coalesce(nullif(o.data->>'executor_name',''),nullif(o.data->>'المنفذ','')) executor_name,
   coalesce(nullif(o.data->>'created_by_name',''),nullif(o.data->>'منشئ الطلب',''),nullif(o.data->>'مرسل الطلب','')) sender_name,
   coalesce(nullif(o.data->>'status',''),nullif(o.data->>'حالة التنفيذ','')) execution_status,
   coalesce(nullif(o.data->>'payment_status',''),nullif(o.data->>'حالة السداد','')) payment_status,
   coalesce(nullif(o.data->>'billing_status',''),nullif(o.data->>'حالة الفوترة',''),'لم تتم') invoice_status,
   coalesce(nullif(o.data->>'order_type',''),nullif(o.data->>'نوع الطلب','')) order_type,
   CASE WHEN coalesce(o.data->>'order_date',o.data->>'تاريخ الطلب','') ~ '^\d{4}-\d{2}-\d{2}$'
        THEN coalesce(o.data->>'order_date',o.data->>'تاريخ الطلب')::date
        ELSE (o.updated_at AT TIME ZONE 'Asia/Riyadh')::date END order_date
 FROM public.orders_shared o
 WHERE (p_allowed_projects IS NULL OR coalesce(nullif(o.data->>'project_name',''),nullif(o.data->>'المشروع',''),nullif(o.data->>'اسم المشروع',''),nullif(o.flow->>'project_name','')) = ANY(p_allowed_projects))
), f AS MATERIALIZED (
 SELECT * FROM base s WHERE
 (nullif(trim(p_project),'') IS NULL OR s.project_name=p_project) AND
 (nullif(trim(p_executor),'') IS NULL OR s.executor_name=p_executor) AND
 (nullif(trim(p_sender),'') IS NULL OR s.sender_name=p_sender) AND
 (nullif(trim(p_execution_status),'') IS NULL OR s.execution_status=p_execution_status) AND
 (nullif(trim(p_payment_status),'') IS NULL OR s.payment_status=p_payment_status) AND
 (nullif(trim(p_invoice_status),'') IS NULL OR s.invoice_status=p_invoice_status) AND
 (nullif(trim(p_order_type),'') IS NULL OR s.order_type=p_order_type) AND
 (p_date_from IS NULL OR s.order_date>=p_date_from) AND (p_date_to IS NULL OR s.order_date<=p_date_to) AND
 (nullif(trim(p_search),'') IS NULL OR
   public.normalize_order_number_v10712(s.canonical_order_number) LIKE '%'||public.normalize_order_number_v10712(p_search)||'%' OR
   s.customer_name ILIKE '%'||trim(p_search)||'%' OR s.customer_phone ILIKE '%'||trim(p_search)||'%' OR
   s.project_name ILIKE '%'||trim(p_search)||'%' OR s.executor_name ILIKE '%'||trim(p_search)||'%')
), c AS (SELECT count(*)::bigint total FROM f), p AS (
 SELECT * FROM f ORDER BY updated_at DESC NULLS LAST,order_no DESC NULLS LAST
 LIMIT CASE WHEN p_export THEN 500 ELSE greatest(1,least(coalesce(p_page_size,50),100)) END
 OFFSET CASE WHEN p_export THEN (greatest(coalesce(p_page,1),1)-1)*500 ELSE (greatest(coalesce(p_page,1),1)-1)*greatest(1,least(coalesce(p_page_size,50),100)) END
)
SELECT coalesce(jsonb_agg(jsonb_build_object(
 'order_no',p.order_no,'updated_at',p.updated_at,'flow',p.flow,
 'data',jsonb_build_object(
   'رقم الطلب',p.canonical_order_number,'order_no',p.canonical_order_number,
   'اسم المشروع',coalesce(p.project_name,'مشروع غير مرتبط'),'project_name',coalesce(p.project_name,'مشروع غير مرتبط'),
   'اسم العميل',p.customer_name,'customer_name',p.customer_name,'رقم العميل',p.customer_phone,'customer_phone',p.customer_phone,
   'المنفذ',coalesce(p.executor_name,'لم يتم تعيين منفذ'),'executor_name',coalesce(p.executor_name,'لم يتم تعيين منفذ'),
   'حالة التنفيذ',p.execution_status,'status',p.execution_status,'حالة السداد',p.payment_status,'payment_status',p.payment_status,
   'حالة الفوترة',p.invoice_status,'billing_status',p.invoice_status,'نوع الطلب',p.order_type,'order_type',p.order_type,
   'السعر (شامل الضريبة)',coalesce(p.data->>'السعر (شامل الضريبة)',p.data->>'inclusive_total',p.data->>'total_with_vat'),
   'السعر قبل الضريبة',coalesce(p.data->>'السعر قبل الضريبة',p.data->>'before_vat'),
   'الضريبة 15%',coalesce(p.data->>'الضريبة 15%',p.data->>'vat_amount'),
   'التكلفة',coalesce(p.data->>'التكلفة',p.data->>'cost'),'الربح',coalesce(p.data->>'الربح',p.data->>'net_profit'),
   'تاريخ الطلب',coalesce(p.data->>'تاريخ الطلب',p.data->>'order_date'),
   'رقم الشقة',coalesce(p.data->>'رقم الشقة',p.data->>'unit_number'),
   'منشئ الطلب',p.sender_name,'created_by_name',p.sender_name
 ),'__light',true,'__has_receipt',(p.data ? '__tasneef_order_receipt_v10140' OR p.data ? 'بيانات الإيصال' OR p.data ? 'receipt')
) ORDER BY p.updated_at DESC NULLS LAST,p.order_no DESC NULLS LAST),'[]'::jsonb),
 c.total,greatest(coalesce(p_page,1),1),CASE WHEN p_export THEN 500 ELSE greatest(1,least(coalesce(p_page_size,50),100)) END,
 greatest(1,ceil(c.total::numeric/CASE WHEN p_export THEN 500 ELSE greatest(1,least(coalesce(p_page_size,50),100)) END)::int)
FROM c LEFT JOIN p ON true GROUP BY c.total;
$$;

CREATE OR REPLACE FUNCTION public.get_orders_summary_v10712(
  p_search text DEFAULT NULL,p_project text DEFAULT NULL,p_executor text DEFAULT NULL,p_sender text DEFAULT NULL,
  p_execution_status text DEFAULT NULL,p_payment_status text DEFAULT NULL,p_invoice_status text DEFAULT NULL,p_order_type text DEFAULT NULL,
  p_date_from date DEFAULT NULL,p_date_to date DEFAULT NULL,p_allowed_projects text[] DEFAULT NULL
) RETURNS jsonb LANGUAGE sql SECURITY INVOKER SET search_path=public AS $$
SELECT jsonb_build_object(
 'total_orders',count(*),
 'completed_orders',count(*) FILTER(WHERE coalesce(data->>'status',data->>'حالة التنفيذ','') ILIKE '%تم التنفيذ%'),
 'unpaid_orders',count(*) FILTER(WHERE coalesce(data->>'payment_status',data->>'حالة السداد','') ~ '(آجل|اجل|جزئي|غير مسدد|لم يتم)'),
 'total_net_profit',coalesce(sum(nullif(regexp_replace(coalesce(data->>'net_profit',data->>'الربح','0'),'[^0-9.\-]','','g'),'')::numeric),0)
) FROM public.orders_shared o
WHERE (p_allowed_projects IS NULL OR coalesce(nullif(data->>'project_name',''),nullif(data->>'المشروع',''),nullif(data->>'اسم المشروع',''))=ANY(p_allowed_projects))
AND (nullif(trim(p_project),'') IS NULL OR coalesce(data->>'project_name',data->>'المشروع',data->>'اسم المشروع')=p_project)
AND (nullif(trim(p_executor),'') IS NULL OR coalesce(data->>'executor_name',data->>'المنفذ')=p_executor)
AND (nullif(trim(p_sender),'') IS NULL OR coalesce(data->>'created_by_name',data->>'منشئ الطلب',data->>'مرسل الطلب')=p_sender)
AND (nullif(trim(p_execution_status),'') IS NULL OR coalesce(data->>'status',data->>'حالة التنفيذ')=p_execution_status)
AND (nullif(trim(p_payment_status),'') IS NULL OR coalesce(data->>'payment_status',data->>'حالة السداد')=p_payment_status)
AND (nullif(trim(p_invoice_status),'') IS NULL OR coalesce(data->>'billing_status',data->>'حالة الفوترة','لم تتم')=p_invoice_status)
AND (nullif(trim(p_order_type),'') IS NULL OR coalesce(data->>'order_type',data->>'نوع الطلب')=p_order_type)
AND (p_date_from IS NULL OR (updated_at AT TIME ZONE 'Asia/Riyadh')::date>=p_date_from)
AND (p_date_to IS NULL OR (updated_at AT TIME ZONE 'Asia/Riyadh')::date<=p_date_to)
AND (nullif(trim(p_search),'') IS NULL OR public.normalize_order_number_v10712(coalesce(order_no,data->>'order_number',data->>'رقم الطلب')) LIKE '%'||public.normalize_order_number_v10712(p_search)||'%' OR coalesce(data->>'customer_name',data->>'اسم العميل','') ILIKE '%'||trim(p_search)||'%');
$$;

-- مصدر موحد وخفيف لعمال المشرف من monthly_distribution.
-- متوافق مع قواعد البيانات التي لا تحتوي عمود supervisor_id فعليًا؛
-- تتم قراءة الحقول عبر to_jsonb حتى لا يفشل إنشاء الدالة عند اختلاف المخطط.
CREATE OR REPLACE FUNCTION public.get_supervisor_workers_summary_v10712(
 p_supervisor_id text,
 p_supervisor_code text DEFAULT NULL,
 p_supervisor_name text DEFAULT NULL,
 p_month_key text DEFAULT to_char(current_date,'YYYY-MM')
) RETURNS jsonb
LANGUAGE sql
SECURITY INVOKER
SET search_path=public
AS $$
WITH d AS MATERIALIZED (
  SELECT to_jsonb(x) AS j
  FROM public.monthly_distribution x
  WHERE coalesce(to_jsonb(x)->>'month_key','') = coalesce(nullif(trim(p_month_key),''),to_char(current_date,'YYYY-MM'))
    AND lower(coalesce(to_jsonb(x)->>'status','active')) NOT IN ('ended','inactive','stopped','disabled','موقوف','متوقف','منتهي')
    AND (
      (
        nullif(trim(p_supervisor_id),'') IS NOT NULL
        AND coalesce(
          nullif(to_jsonb(x)->>'supervisor_id',''),
          nullif(to_jsonb(x)->>'app_supervisor_id',''),
          nullif(to_jsonb(x)->>'current_supervisor_id',''),
          ''
        ) = trim(p_supervisor_id)
      )
      OR (
        nullif(trim(p_supervisor_code),'') IS NOT NULL
        AND coalesce(
          nullif(to_jsonb(x)->>'supervisor_employee_code',''),
          nullif(to_jsonb(x)->>'supervisor_code',''),
          ''
        ) = trim(p_supervisor_code)
      )
      OR (
        nullif(trim(p_supervisor_name),'') IS NOT NULL
        AND lower(trim(coalesce(
          nullif(to_jsonb(x)->>'supervisor_name',''),
          nullif(to_jsonb(x)->>'supervisor',''),
          ''
        ))) = lower(trim(p_supervisor_name))
      )
    )
),
w AS MATERIALIZED (
  SELECT to_jsonb(x) AS j
  FROM public.workers x
),
expanded AS (
  SELECT
    coalesce(
      nullif(w.j->>'id',''),
      nullif(d.j->>'worker_id',''),
      nullif(d.j->>'app_worker_id',''),
      nullif(d.j->>'worker_employee_code','')
    ) AS worker_id,
    coalesce(
      nullif(w.j->>'name',''),
      nullif(w.j->>'full_name',''),
      nullif(w.j->>'worker_name',''),
      nullif(d.j->>'worker_name',''),
      'عامل غير معروف — يحتاج مراجعة'
    ) AS name,
    coalesce(
      nullif(w.j->>'employee_code',''),
      nullif(w.j->>'employee_number',''),
      nullif(w.j->>'code',''),
      nullif(d.j->>'worker_employee_code','')
    ) AS employee_number,
    CASE
      WHEN lower(coalesce(w.j->>'is_active','')) IN ('true','t','1','yes') THEN true
      WHEN lower(coalesce(w.j->>'status','')) IN ('active','working','نشط') THEN true
      ELSE false
    END AS is_active,
    nullif(d.j->>'project_id','') AS project_id,
    coalesce(nullif(d.j->>'project_name',''),nullif(d.j->>'project','')) AS project_name
  FROM d
  LEFT JOIN w ON (
    nullif(w.j->>'id','') = coalesce(nullif(d.j->>'worker_id',''),nullif(d.j->>'app_worker_id',''))
    OR nullif(coalesce(w.j->>'employee_code',w.j->>'employee_number',w.j->>'code'),'') = nullif(d.j->>'worker_employee_code','')
  )
),
active AS (
  SELECT *
  FROM expanded
  WHERE worker_id IS NOT NULL
    AND is_active = true
),
grouped AS (
  SELECT
    worker_id,
    max(name) AS name,
    max(employee_number) AS employee_number,
    true AS is_active,
    coalesce(
      jsonb_agg(DISTINCT jsonb_build_object('id',project_id,'name',project_name))
        FILTER (WHERE project_id IS NOT NULL OR project_name IS NOT NULL),
      '[]'::jsonb
    ) AS projects
  FROM active
  GROUP BY worker_id
)
SELECT jsonb_build_object(
  'workers',coalesce(
    jsonb_agg(
      jsonb_build_object(
        'worker_id',worker_id,
        'name',name,
        'employee_number',employee_number,
        'is_active',is_active,
        'projects',projects
      ) ORDER BY name
    ),
    '[]'::jsonb
  ),
  'total',count(*),
  'raw_assignments',(SELECT count(*) FROM d),
  'excluded_inactive',greatest((SELECT count(*) FROM d)-count(*),0)
)
FROM grouped;
$$;

CREATE INDEX IF NOT EXISTS idx_orders_shared_updated_order_v10712
  ON public.orders_shared(updated_at DESC,order_no DESC);
CREATE INDEX IF NOT EXISTS idx_orders_shared_order_norm_v10712
  ON public.orders_shared(public.normalize_order_number_v10712(order_no));
CREATE INDEX IF NOT EXISTS idx_orders_shared_project_expr_v10712
  ON public.orders_shared((coalesce(data->>'project_name',data->>'المشروع',data->>'اسم المشروع')));
CREATE INDEX IF NOT EXISTS idx_orders_shared_executor_expr_v10712
  ON public.orders_shared((coalesce(data->>'executor_name',data->>'المنفذ')));
CREATE INDEX IF NOT EXISTS idx_orders_shared_customer_trgm_v10712
  ON public.orders_shared USING gin ((coalesce(data->>'customer_name',data->>'اسم العميل','')) gin_trgm_ops);

-- إنشاء فهارس التوزيع والحضور فقط إذا كانت الأعمدة موجودة فعليًا.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='public' AND table_name='monthly_distribution' AND column_name='month_key'
  ) AND EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='public' AND table_name='monthly_distribution' AND column_name='supervisor_employee_code'
  ) THEN
    EXECUTE 'CREATE INDEX IF NOT EXISTS idx_monthly_distribution_sup_code_month_v10712 ON public.monthly_distribution(supervisor_employee_code,month_key)';
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='public' AND table_name='monthly_distribution' AND column_name='month_key'
  ) AND EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='public' AND table_name='monthly_distribution' AND column_name='worker_employee_code'
  ) THEN
    EXECUTE 'CREATE INDEX IF NOT EXISTS idx_monthly_distribution_worker_code_month_v10713 ON public.monthly_distribution(worker_employee_code,month_key)';
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='public' AND table_name='project_worker_visits' AND column_name='supervisor_id'
  ) AND EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='public' AND table_name='project_worker_visits' AND column_name='check_in'
  ) AND EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='public' AND table_name='project_worker_visits' AND column_name='check_out'
  ) THEN
    EXECUTE 'CREATE INDEX IF NOT EXISTS idx_project_worker_visits_sup_open_v10712 ON public.project_worker_visits(supervisor_id,check_in DESC) WHERE check_out IS NULL';
  END IF;
END
$$;
COMMIT;
NOTIFY pgrst,'reload schema';
