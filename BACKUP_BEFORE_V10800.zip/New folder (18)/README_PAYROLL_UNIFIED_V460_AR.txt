قسم الرواتب الموحد V460

الملف التنفيذي الوحيد:
- tasneef_salaries_unified_source_v440.js

ملف التثبيت داخل النظام:
- tasneef_core_salaries_tab_v440.js

ملفات قديمة موجودة للمرجع فقط وغير محملة في admin.html:
- tasneef_salaries_v10363_original_user_reference.js
- supabase_salaries_rebuild_v450.sql
- supabase_salaries_speed_v451.sql

مصادر البيانات:
workers, projects, worker_project_assignments/monthly_distribution,
attendance, daily_records/daily_registrations, monthly_salaries,
payroll_adjustments/worker_borrowings.

لا يتم إنشاء أسماء عمال أو مشروعات أو مشرفين داخل الرواتب.
مكان العمل: المشروع الدائم = اسم المشروع، والزيارة اليومية = اسم المشرف، والمختلط = متعدد.
