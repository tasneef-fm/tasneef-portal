-- Tasneef Orders Stable Restore V10713
-- يشغّل مرة واحدة في Supabase SQL Editor.
-- لا يحذف ولا يعدّل أي أوردر؛ يضيف ملخصًا خفيفًا وفهارس فقط.

BEGIN;

CREATE EXTENSION IF NOT EXISTS pg_trgm;

CREATE OR REPLACE FUNCTION public.normalize_order_number_stable_v10713(p_value text)
RETURNS text
LANGUAGE sql
IMMUTABLE
PARALLEL SAFE
AS $$
  SELECT regexp_replace(
    translate(coalesce(p_value,''), '٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹', '01234567890123456789'),
    '\s+', '', 'g'
  );
$$;

CREATE OR REPLACE FUNCTION public.get_orders_summary_stable_v10713(
  p_search text DEFAULT NULL,
  p_project text DEFAULT NULL,
  p_executor text DEFAULT NULL,
  p_sender text DEFAULT NULL,
  p_execution_status text DEFAULT NULL,
  p_payment_status text DEFAULT NULL,
  p_invoice_status text DEFAULT NULL,
  p_order_type text DEFAULT NULL,
  p_date_from date DEFAULT NULL,
  p_date_to date DEFAULT NULL,
  p_allowed_projects text[] DEFAULT NULL
)
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
WITH filtered AS (
  SELECT o.data
  FROM public.orders_shared o
  WHERE
    (
      p_allowed_projects IS NULL
      OR coalesce(
        nullif(o.data->>'project_name',''),
        nullif(o.data->>'المشروع',''),
        nullif(o.data->>'اسم المشروع',''),
        nullif(o.flow->>'project_name','')
      ) = ANY(p_allowed_projects)
    )
    AND (
      nullif(trim(p_project),'') IS NULL
      OR coalesce(o.data->>'project_name',o.data->>'المشروع',o.data->>'اسم المشروع',o.flow->>'project_name') = p_project
    )
    AND (
      nullif(trim(p_executor),'') IS NULL
      OR coalesce(o.data->>'executor_name',o.data->>'المنفذ') = p_executor
    )
    AND (
      nullif(trim(p_sender),'') IS NULL
      OR coalesce(o.data->>'created_by_name',o.data->>'منشئ الطلب',o.data->>'مرسل الطلب') = p_sender
    )
    AND (
      nullif(trim(p_execution_status),'') IS NULL
      OR coalesce(o.data->>'status',o.data->>'حالة التنفيذ') = p_execution_status
    )
    AND (
      nullif(trim(p_payment_status),'') IS NULL
      OR coalesce(o.data->>'payment_status',o.data->>'حالة السداد') = p_payment_status
    )
    AND (
      nullif(trim(p_invoice_status),'') IS NULL
      OR coalesce(o.data->>'billing_status',o.data->>'حالة الفوترة','لم تتم') = p_invoice_status
    )
    AND (
      nullif(trim(p_order_type),'') IS NULL
      OR coalesce(o.data->>'order_type',o.data->>'نوع الطلب') = p_order_type
    )
    AND (p_date_from IS NULL OR o.updated_at >= (p_date_from::timestamp AT TIME ZONE 'Asia/Riyadh'))
    AND (p_date_to IS NULL OR o.updated_at < (((p_date_to + 1)::timestamp) AT TIME ZONE 'Asia/Riyadh'))
    AND (
      nullif(trim(p_search),'') IS NULL
      OR public.normalize_order_number_stable_v10713(
        coalesce(o.order_no,o.data->>'order_number',o.data->>'external_order_number',o.data->>'legacy_order_number',o.data->>'excel_order_number',o.data->>'رقم الطلب')
      ) ILIKE '%' || public.normalize_order_number_stable_v10713(p_search) || '%'
      OR coalesce(o.data->>'customer_name',o.data->>'اسم العميل','') ILIKE '%' || trim(p_search) || '%'
      OR coalesce(o.data->>'customer_phone',o.data->>'رقم العميل',o.data->>'mobile','') ILIKE '%' || trim(p_search) || '%'
      OR coalesce(o.data->>'project_name',o.data->>'المشروع',o.data->>'اسم المشروع',o.flow->>'project_name','') ILIKE '%' || trim(p_search) || '%'
      OR coalesce(o.data->>'executor_name',o.data->>'المنفذ','') ILIKE '%' || trim(p_search) || '%'
      OR coalesce(o.data->>'order_type',o.data->>'نوع الطلب','') ILIKE '%' || trim(p_search) || '%'
    )
)
SELECT jsonb_build_object(
  'total_orders', count(*),
  'completed_orders', count(*) FILTER (
    WHERE coalesce(data->>'status',data->>'حالة التنفيذ','') ~ '(تم التنفيذ|مكتمل|منفذ)'
  ),
  'unpaid_orders', count(*) FILTER (
    WHERE coalesce(data->>'payment_status',data->>'حالة السداد','') ~ '(آجل|اجل|جزئي|غير مسدد|لم يتم)'
  ),
  'total_net_profit', coalesce(sum(
    CASE
      WHEN nullif(regexp_replace(coalesce(data->>'net_profit',data->>'الربح','0'),'[^0-9.\-]','','g'),'') ~ '^-?[0-9]+(\.[0-9]+)?$'
      THEN nullif(regexp_replace(coalesce(data->>'net_profit',data->>'الربح','0'),'[^0-9.\-]','','g'),'')::numeric
      ELSE 0
    END
  ),0)
)
FROM filtered;
$$;

-- ترتيب أول صفحة والصفحات اللاحقة.
CREATE INDEX IF NOT EXISTS idx_orders_shared_updated_order_stable_v10713
  ON public.orders_shared (updated_at DESC, order_no DESC);

-- فهارس الفلاتر الفعلية.
CREATE INDEX IF NOT EXISTS idx_orders_shared_project_stable_v10713
  ON public.orders_shared ((coalesce(data->>'project_name',data->>'المشروع',data->>'اسم المشروع',flow->>'project_name')));
CREATE INDEX IF NOT EXISTS idx_orders_shared_executor_stable_v10713
  ON public.orders_shared ((coalesce(data->>'executor_name',data->>'المنفذ')));
CREATE INDEX IF NOT EXISTS idx_orders_shared_execution_stable_v10713
  ON public.orders_shared ((coalesce(data->>'status',data->>'حالة التنفيذ')));
CREATE INDEX IF NOT EXISTS idx_orders_shared_payment_stable_v10713
  ON public.orders_shared ((coalesce(data->>'payment_status',data->>'حالة السداد')));
CREATE INDEX IF NOT EXISTS idx_orders_shared_invoice_stable_v10713
  ON public.orders_shared ((coalesce(data->>'billing_status',data->>'حالة الفوترة','لم تتم')));
CREATE INDEX IF NOT EXISTS idx_orders_shared_type_stable_v10713
  ON public.orders_shared ((coalesce(data->>'order_type',data->>'نوع الطلب')));

-- فهارس البحث النصي؛ متطابقة مع حقول البحث المستخدمة في الواجهة.
CREATE INDEX IF NOT EXISTS idx_orders_shared_order_search_stable_v10713
  ON public.orders_shared USING gin (
    public.normalize_order_number_stable_v10713(
      coalesce(order_no,data->>'order_number',data->>'external_order_number',data->>'legacy_order_number',data->>'excel_order_number',data->>'رقم الطلب')
    ) gin_trgm_ops
  );
CREATE INDEX IF NOT EXISTS idx_orders_shared_customer_search_stable_v10713
  ON public.orders_shared USING gin ((coalesce(data->>'customer_name',data->>'اسم العميل','')) gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_orders_shared_phone_search_stable_v10713
  ON public.orders_shared USING gin ((coalesce(data->>'customer_phone',data->>'رقم العميل',data->>'mobile','')) gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_orders_shared_project_search_stable_v10713
  ON public.orders_shared USING gin ((coalesce(data->>'project_name',data->>'المشروع',data->>'اسم المشروع',flow->>'project_name','')) gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_orders_shared_executor_search_stable_v10713
  ON public.orders_shared USING gin ((coalesce(data->>'executor_name',data->>'المنفذ','')) gin_trgm_ops);

GRANT EXECUTE ON FUNCTION public.get_orders_summary_stable_v10713(
  text,text,text,text,text,text,text,text,date,date,text[]
) TO anon, authenticated;

COMMIT;
NOTIFY pgrst, 'reload schema';
