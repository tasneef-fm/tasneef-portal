-- V461 حل جذري لنقل المشرف: المشاريع + التوزيع + السجلات الحالية/المستقبلية فقط
-- لا يلمس السجلات القديمة قبل تاريخ النقل.

create or replace function public.tasneef_transfer_supervisor_complete_v461(
  p_old_code text,
  p_new_code text,
  p_old_name text,
  p_new_name text,
  p_old_user_id bigint default null,
  p_new_user_id bigint default null,
  p_from_month text default null,
  p_from_date date default current_date
)
returns table(
  distribution_rows integer,
  project_rows integer,
  time_log_rows integer,
  attendance_rows integer,
  daily_rows integer
)
language plpgsql
security definer
set search_path = public
as $$
declare
  set_sql text;
  where_sql text;
  date_sql text;
  rc int;
  has_updated_at boolean;
  has_col boolean;
begin
  distribution_rows := 0;
  project_rows := 0;
  time_log_rows := 0;
  attendance_rows := 0;
  daily_rows := 0;
  p_from_month := coalesce(nullif(p_from_month,''), to_char(current_date,'YYYY-MM'));
  p_from_date := coalesce(p_from_date, current_date);

  -- monthly_distribution: نقل التوزيع من الشهر الحالي وما بعده
  if to_regclass('public.monthly_distribution') is not null then
    set_sql := '';
    where_sql := '';
    select exists(select 1 from information_schema.columns where table_schema='public' and table_name='monthly_distribution' and column_name='updated_at') into has_updated_at;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='monthly_distribution' and column_name='supervisor_employee_code') then
      set_sql := set_sql || format('supervisor_employee_code=%L,', p_new_code);
      where_sql := where_sql || format('supervisor_employee_code=%L or ', p_old_code);
    end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='monthly_distribution' and column_name='supervisor_code') then
      set_sql := set_sql || format('supervisor_code=%L,', p_new_code);
      where_sql := where_sql || format('supervisor_code=%L or ', p_old_code);
    end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='monthly_distribution' and column_name='supervisor_name') then
      set_sql := set_sql || format('supervisor_name=%L,', p_new_name);
      where_sql := where_sql || format('supervisor_name=%L or ', p_old_name);
    end if;
    if p_old_user_id is not null and p_new_user_id is not null and exists(select 1 from information_schema.columns where table_schema='public' and table_name='monthly_distribution' and column_name='supervisor_id') then
      set_sql := set_sql || format('supervisor_id=%s,', p_new_user_id);
      where_sql := where_sql || format('supervisor_id=%s or ', p_old_user_id);
    end if;
    if has_updated_at then set_sql := set_sql || 'updated_at=now(),'; end if;
    set_sql := trim(trailing ',' from set_sql);
    where_sql := regexp_replace(where_sql, ' or $', '');
    if set_sql <> '' and where_sql <> '' then
      execute format('update public.monthly_distribution set %s where (%s) and coalesce(month_key,'''') >= %L', set_sql, where_sql, p_from_month);
      get diagnostics rc = row_count; distribution_rows := distribution_rows + rc;
    end if;
  end if;

  -- projects: نقل المشروع نفسه للمشرف البديل حتى يظهر في حسابه
  if to_regclass('public.projects') is not null then
    set_sql := '';
    where_sql := '';
    select exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='updated_at') into has_updated_at;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='supervisor_employee_code') then
      set_sql := set_sql || format('supervisor_employee_code=%L,', p_new_code);
      where_sql := where_sql || format('supervisor_employee_code=%L or ', p_old_code);
    end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='supervisor_code') then
      set_sql := set_sql || format('supervisor_code=%L,', p_new_code);
      where_sql := where_sql || format('supervisor_code=%L or ', p_old_code);
    end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='current_supervisor_code') then
      set_sql := set_sql || format('current_supervisor_code=%L,', p_new_code);
      where_sql := where_sql || format('current_supervisor_code=%L or ', p_old_code);
    end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='app_supervisor_code') then
      set_sql := set_sql || format('app_supervisor_code=%L,', p_new_code);
      where_sql := where_sql || format('app_supervisor_code=%L or ', p_old_code);
    end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='supervisor_name') then
      set_sql := set_sql || format('supervisor_name=%L,', p_new_name);
      where_sql := where_sql || format('supervisor_name=%L or ', p_old_name);
    end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='current_supervisor_name') then
      set_sql := set_sql || format('current_supervisor_name=%L,', p_new_name);
      where_sql := where_sql || format('current_supervisor_name=%L or ', p_old_name);
    end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='app_supervisor_name') then
      set_sql := set_sql || format('app_supervisor_name=%L,', p_new_name);
      where_sql := where_sql || format('app_supervisor_name=%L or ', p_old_name);
    end if;
    if p_old_user_id is not null and p_new_user_id is not null and exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='supervisor_id') then
      set_sql := set_sql || format('supervisor_id=%s,', p_new_user_id);
      where_sql := where_sql || format('supervisor_id=%s or ', p_old_user_id);
    end if;
    if p_old_user_id is not null and p_new_user_id is not null and exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='current_supervisor_id') then
      set_sql := set_sql || format('current_supervisor_id=%s,', p_new_user_id);
      where_sql := where_sql || format('current_supervisor_id=%s or ', p_old_user_id);
    end if;
    if p_old_user_id is not null and p_new_user_id is not null and exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='app_supervisor_id') then
      set_sql := set_sql || format('app_supervisor_id=%s,', p_new_user_id);
      where_sql := where_sql || format('app_supervisor_id=%s or ', p_old_user_id);
    end if;
    if has_updated_at then set_sql := set_sql || 'updated_at=now(),'; end if;
    set_sql := trim(trailing ',' from set_sql);
    where_sql := regexp_replace(where_sql, ' or $', '');
    if set_sql <> '' and where_sql <> '' then
      execute format('update public.projects set %s where (%s)', set_sql, where_sql);
      get diagnostics rc = row_count; project_rows := project_rows + rc;
    end if;
  end if;

  -- time_logs: نقل السجلات اليومية من تاريخ النقل وما بعده فقط
  if to_regclass('public.time_logs') is not null then
    set_sql := '';
    where_sql := '';
    date_sql := '';
    select exists(select 1 from information_schema.columns where table_schema='public' and table_name='time_logs' and column_name='updated_at') into has_updated_at;
    if p_old_user_id is not null and p_new_user_id is not null and exists(select 1 from information_schema.columns where table_schema='public' and table_name='time_logs' and column_name='supervisor_id') then
      set_sql := set_sql || format('supervisor_id=%s,', p_new_user_id);
      where_sql := where_sql || format('supervisor_id=%s or ', p_old_user_id);
    end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='time_logs' and column_name='supervisor_employee_code') then
      set_sql := set_sql || format('supervisor_employee_code=%L,', p_new_code);
      where_sql := where_sql || format('supervisor_employee_code=%L or ', p_old_code);
    end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='time_logs' and column_name='supervisor_name') then
      set_sql := set_sql || format('supervisor_name=%L,', p_new_name);
      where_sql := where_sql || format('supervisor_name=%L or ', p_old_name);
    end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='time_logs' and column_name='log_date') then
      date_sql := format(' and log_date >= %L::date', p_from_date);
    elsif exists(select 1 from information_schema.columns where table_schema='public' and table_name='time_logs' and column_name='check_in') then
      date_sql := format(' and check_in::date >= %L::date', p_from_date);
    end if;
    if has_updated_at then set_sql := set_sql || 'updated_at=now(),'; end if;
    set_sql := trim(trailing ',' from set_sql);
    where_sql := regexp_replace(where_sql, ' or $', '');
    if set_sql <> '' and where_sql <> '' then
      execute format('update public.time_logs set %s where (%s)%s', set_sql, where_sql, date_sql);
      get diagnostics rc = row_count; time_log_rows := time_log_rows + rc;
    end if;
  end if;

  -- attendance: الحضور الحالي/المستقبلي فقط
  if to_regclass('public.attendance') is not null then
    set_sql := '';
    where_sql := '';
    date_sql := '';
    select exists(select 1 from information_schema.columns where table_schema='public' and table_name='attendance' and column_name='updated_at') into has_updated_at;
    if p_old_user_id is not null and p_new_user_id is not null and exists(select 1 from information_schema.columns where table_schema='public' and table_name='attendance' and column_name='supervisor_id') then
      set_sql := set_sql || format('supervisor_id=%s,', p_new_user_id);
      where_sql := where_sql || format('supervisor_id=%s or ', p_old_user_id);
    end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='attendance' and column_name='supervisor_employee_code') then
      set_sql := set_sql || format('supervisor_employee_code=%L,', p_new_code);
      where_sql := where_sql || format('supervisor_employee_code=%L or ', p_old_code);
    end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='attendance' and column_name='supervisor_name') then
      set_sql := set_sql || format('supervisor_name=%L,', p_new_name);
      where_sql := where_sql || format('supervisor_name=%L or ', p_old_name);
    end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='attendance' and column_name='attendance_date') then
      date_sql := format(' and attendance_date >= %L::date', p_from_date);
    end if;
    if has_updated_at then set_sql := set_sql || 'updated_at=now(),'; end if;
    set_sql := trim(trailing ',' from set_sql);
    where_sql := regexp_replace(where_sql, ' or $', '');
    if set_sql <> '' and where_sql <> '' then
      execute format('update public.attendance set %s where (%s)%s', set_sql, where_sql, date_sql);
      get diagnostics rc = row_count; attendance_rows := attendance_rows + rc;
    end if;
  end if;

  -- daily_records إن وجد
  if to_regclass('public.daily_records') is not null then
    set_sql := '';
    where_sql := '';
    date_sql := '';
    select exists(select 1 from information_schema.columns where table_schema='public' and table_name='daily_records' and column_name='updated_at') into has_updated_at;
    if p_old_user_id is not null and p_new_user_id is not null and exists(select 1 from information_schema.columns where table_schema='public' and table_name='daily_records' and column_name='supervisor_id') then
      set_sql := set_sql || format('supervisor_id=%s,', p_new_user_id);
      where_sql := where_sql || format('supervisor_id=%s or ', p_old_user_id);
    end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='daily_records' and column_name='supervisor_employee_code') then
      set_sql := set_sql || format('supervisor_employee_code=%L,', p_new_code);
      where_sql := where_sql || format('supervisor_employee_code=%L or ', p_old_code);
    end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='daily_records' and column_name='supervisor_name') then
      set_sql := set_sql || format('supervisor_name=%L,', p_new_name);
      where_sql := where_sql || format('supervisor_name=%L or ', p_old_name);
    end if;
    if exists(select 1 from information_schema.columns where table_schema='public' and table_name='daily_records' and column_name='record_date') then
      date_sql := format(' and record_date >= %L::date', p_from_date);
    end if;
    if has_updated_at then set_sql := set_sql || 'updated_at=now(),'; end if;
    set_sql := trim(trailing ',' from set_sql);
    where_sql := regexp_replace(where_sql, ' or $', '');
    if set_sql <> '' and where_sql <> '' then
      execute format('update public.daily_records set %s where (%s)%s', set_sql, where_sql, date_sql);
      get diagnostics rc = row_count; daily_rows := daily_rows + rc;
    end if;
  end if;

  return next;
end;
$$;

grant execute on function public.tasneef_transfer_supervisor_complete_v461(text,text,text,text,bigint,bigint,text,date) to anon, authenticated;

-- فهارس تساعد صفحات المشرف والتسجيلات
create index if not exists idx_projects_supervisor_id_v461 on public.projects(supervisor_id);
create index if not exists idx_projects_supervisor_code_v461 on public.projects(supervisor_employee_code) where supervisor_employee_code is not null;
create index if not exists idx_monthly_distribution_sup_month_v461 on public.monthly_distribution(supervisor_employee_code, month_key);
create index if not exists idx_time_logs_sup_date_v461 on public.time_logs(supervisor_id, log_date);
